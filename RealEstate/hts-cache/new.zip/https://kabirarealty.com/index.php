<!doctype html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="real estate, property, property search, agent, apartments, booking, business, idx, housing, real estate agency, rental">
    <title>Kabira Realty - Leading Real Estate Solutions for Residential and Commercial Properties for best Real Estate, Flats, and New Projects.
</title>

    <!-- Favicon -->
  <meta name="description" content=" Kabira Realty- One of the top developers of real estate in India, Kabira Realty offers a broad variety of residential and commercial properties. Kabira Realty offers luxury and premium real estate homes for sale in desirable locales. Make reservations today!" />
    <!-- Favicon -->
    <link rel="shortcut icon" href="/image/icon.png">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sen:wght@400;700&amp;display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,300;0,400;0,500;0,700;1,400&amp;display=swap" rel="stylesheet">

    <!-- Required style of the theme -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/webfonts/flaticon/flaticon.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="assets/css/layerslider.css">
    <link rel="stylesheet" href="assets/css/template.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/colors/color.css">
    <link rel="stylesheet" href="assets/css/loader.css">
    
    <style>
        .exp_text{
            font-size:22px;
        }
        #srch{ width:100%; }
        
        .owl-carousel .owl-dots {
             display:none !important;
        }
        @media screen and (max-width: 767px) {
             .exp_text{
                font-size:14px;
                font-weight: 500;
            }
            #srch{ width:100%; }
            
        }
       
    </style>
</head>

<body>

    <div id="page_wrapper">
        
        <style>
.top-header .footer-widget a{
    color: white;
  
}
</style>
        <header class="transparent-header nav-on-banner fixed-bg-dark">
           <div class="top-header xs-mx-none">
                <div class="container">
                    	                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                             <div class="footer-widget media-widget">
                            <a href="https://www.facebook.com/profile.php?id=61554608451548"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/KabiraRealty"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/company/kabira-realty/"><i class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.youtube.com/@KabiraRealty"><i class="fab fa-youtube"></i></a>
                            <a href="https://www.instagram.com/kabirarealty/"><i class="fab fa-instagram"></i></a>
                        </div>
                        </div>
                        <div class="col-lg-9 col-md-6">
                           
                            <ul class="top-contact list-color-white">
                                <li><a href="tel:    8383809575"><i class="fa fa-phone" aria-hidden="true"></i> +91-    8383809575 <img src="assets/main/india.png" alt=""></a></li>
                            </ul>
                        </div>
                    </div>
                                    </div>
            </div>
            <div class="main-nav py-2 xs-p-0">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <nav class="navbar navbar-expand-lg nav-white nav-primary-hover nav-line-active">
                                <a class="navbar-brand" href="index.php"><img class="nav-logo" src="/image/logo.png" alt="Image not found !"></a>
                              
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon flaticon-menu flat-small text-primary"></span>
                                  </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav ms-auto">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">About Us</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="about/">Mr.Pradeep Kabira</a></li>
                                                <li><a class="dropdown-item" href="kabira/">About Kabira Realty</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Builders</a>
                                            <ul class="dropdown-menu">
											                                                <li><a class="dropdown-item" href="builder/?seo=fairfox-realty">Fairfox Realty </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=kw-group">K.W Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=mrproview">Mr.Proview</a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=jyoti-supertech">Jyoti Super-Tech</a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=sarvottam-group">Sarvottam Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=himalaya-group">Himalaya Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=grand-plaza">Grand Plaza </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=rise-group">Rise Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=i-s-buildtech">I. & S. Buildtech </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=world-infracons">World Infracons </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=sg-group">SG Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=golden-gate">Golden Gate</a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=atharv-group">Atharv Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=irish-group">Irish Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=avs-group">AVS Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=kabira-group">Kabira Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=ssr-group">SSR Group </a></li>
                                                                                                <li><a class="dropdown-item" href="builder/?seo=harit-group">Harit Group </a></li>
                                                                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Projects</a>
                                            <ul class="dropdown-menu">
										                                                <li><a class="dropdown-item" href="property/?seo=residental">Residential</a></li>
												                                                <li><a class="dropdown-item" href="property/?seo=commercial">Commercial</a></li>
												                                                <li><a class="dropdown-item" href="property/?seo=resale">Resale</a></li>
												                                                <li><a class="dropdown-item" href="property/?seo=plots">Plots</a></li>
												                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Media</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="gallery/">Gallery</a></li>
                                                <li><a class="dropdown-item" href="blog/">Blogs</a></li>
                                                <li><a class="dropdown-item" href="event/">Events</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Careers</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="career/">Careers</a></li>
                                                <li><a class="dropdown-item" href="associate/">Associate</a></li>
                                                <li><a class="dropdown-item" href="franchisee/">Franchisee</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact/">Contact Us</a>
                                        </li>

                                    </ul>
                                    <!-- <a href="#" class="btn btn-white add-listing-btn">+ Create Listing</a> -->
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
       
        <!--============== Search Banner Start ==============-->
        <div class="full-row p-0" id="banner">
            <div class="overlay-wcs"></div>
            <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
                <source src="assets/main/back.mp4" type="video/mp4">
            </video>
            <div class="container">
                <div class="row justify-content-md-center py-5">
                    <div class="col-md-10">
                        <div class="banner-search sm-p-0" style="padding-top: 170px; padding-bottom: 190px;">
                          
                            <h1 class="text-center mx-auto text-white">Find The Best
                                <span class="txt-rotate" data-period="2000" data-rotate='[  "FLAT", "APARTMENT","VILLA","PLOT","OFFICE" ]'></span>
                            </h1>
                            <!-- <span class="d-table mx-auto text-white font-medium mb-4">We have listed over 100000+ property in our database</span> -->
                            <form action="search-property/" class="banner-search-form p-2" method="GET">
                                <div class="row" style="justify-content:center;">
                                    <div class="col-md-10">
                                        <div class="row">
                                        <!---div class="col-lg-2 col-5 my-2 ">
                                        <select class="form-control" name="city_search">
											<option>Select City</option>
											     			
											<option value="1">Delhi</option>
														
											<option value="3">Noida</option>
														
											<option value="6">Ghaziabad</option>
														
											<option value="9">Gurugram</option>
														
											<option value="11">Meerut </option>
														
											<option value="12">Vrindavan</option>
														
											<option value="13">Haridwar </option>
														
											<option value="14">Jaipur </option>
														
											<option value="15">Lucknow</option>
														
											<option value="17">Yamuna Expressway </option>
														
											<option value="18">Greater Noida </option>
																					</select>
                                    </div--->
                                    <div class="col-lg-10 col-12 my-2">
                                        <input type="text" class="form-control" id="srch" name="search" placeholder="Search By City, Location, Project, Builder">
                                    </div>
                                    <div class="col-lg-2 col-12 my-2 ">
                                        <button class="btn btn-primary w-100">Search</button>
                                    </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <center>
                                <ul id="tabs" id="space">
                                    										  <li><a href="property/?seo=residental">Residential</a></li>
									  									  <li><a href="property/?seo=commercial">Commercial</a></li>
									  									  <li><a href="property/?seo=resale">Resale</a></li>
									  									  <li><a href="property/?seo=plots">Plots</a></li>
									                                          
                                </ul>
                            </center>
                            <div class="row text-center" id="space">
                                <div class="col">
                                     	
                                    <div class="counter">
                                        <h2 class="timer count-title count-number" data-to="8" data-speed="5000"><span></span></h2>
                                        <p class="count-text exp_text">+ Year Experience</p>
                                    </div>
                                                                    </div>
                                <div class="col">
                                    	
                                    <div class="counter">
                                        <h2 class="timer count-title count-number" data-to="10000" data-speed="5000"></h2>
                                        <p class="count-text exp_text">+ Happy Faces</p>
                                    </div>
                                                                    </div>
                                <div class="col">
                                    	
                                    <div class="counter">
                                        <h2 class="timer count-title count-number" data-to="50" data-speed="5000"></h2>
                                        <p class="count-text exp_text">+ Developers</p>
                                    </div>
                                                                    </div>
                                <div class="col">
                                    	
                                    <div class="counter">
                                        <h2 class="timer count-title count-number" data-to="120" data-speed="5000"></h2>
                                        <p class="count-text exp_text">+ Projects</p>
                                    </div>
                                                                    </div>
                                <div class="col">
                                    	
                                    <div class="counter" style="border-right: none;">
                                        <h2 class="timer count-title count-number" data-to="600000" data-speed="5000"></h2>
                                        <p class="count-text exp_text">+ Area Sold (In sqft.)</p>
                                    </div>
                                                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--============== Search Banner End ==============-->
     			
        <div class="full-row pb-30">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <img src="image/6777istockphoto-184962061-612x612.jpg" alt="" style="border-radius:10px; height:335px; width:100%;">
                    </div>
                    <div class="col-lg-7">
                        <h2>Kabira Realty </h2>
                        <h4>The Real Estate Brand</h4>
                        <p><p>Kabira Realty india&nbsp;Private Limited is a real estate consultancy agency providing investment related services to its clients.&nbsp; The main objective of the company is to provide financial freedom to its customers by making them aware of passive income so that they can live a happy and respectable life by improving their economic and social life. Our aim is not just to sell products to our customers but to build trust and long term relationship with them.&nbsp; After all, it is the trust and satisfaction of the customers that drives us forward.</p>

<p>&nbsp;We are glad to inform that while providing services to Delhi NCR region, we are now striving to provide our services to other important cities of North India as well.</p>
</p>
                        <a href="about/" id="del">Read More</a>
                    </div>
                </div>
            </div>
        </div>
		<style>
    #Residential .testimonial-simple h3{
        line-height: 10px !important;
    } 
    #Residential .testimonial-simple p{
        color: white !important;
    }
    .spot_img{
        width:100%;
        height:432px;
    }
      @media(max-width:767px){
        .spot_img{
           width:100%;
        height:432px;
        }
      }
</style>
        <section class="mt-20" id="Residential">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div >
                            <div  >
                               <center> <h2 class="d-table">In Spotlight</h2></center>
                                <center><span class="d-table  w-sm-100 sub-title mx-auto ">Find your Best Place to Live With Us.</span></center>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="testimonial-simple">
                            <div class="text-carusel owl-carousel">
							     			
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=kw-delhi-6"><img src="image/5592IMG-20230421-WA0003.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>KW Delhi -6</h3>
											 <h3 >Rs 25 lac onwards -</h3>
											 <p style="color:white;">Rajnagar Extension Ghaziabad </p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=kw-delhi-6" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=great-northern-bazar"><img src="image/5122IMG-20230218-WA0089.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Great Northern Bazar </h3>
											 <h3 >Rs 50 lac-2 cr.</h3>
											 <p style="color:white;">Rajnagar Extension Ghaziabad </p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=great-northern-bazar" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=himalaya-city-center"><img src="image/4148IMG-20230421-WA0008.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Himalaya city center</h3>
											 <h3 >Rs 29 lac onwards -</h3>
											 <p style="color:white;">Rajnagar  Extension Ghaziabad</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=himalaya-city-center" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=sarvottam-city-centre"><img src="image/3728IMG-20230319-WA0003.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Sarvottam City Centre </h3>
											 <h3 >Rs 57 lac onwards -</h3>
											 <p style="color:white;">G.T Road Ghaziabad </p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=sarvottam-city-centre" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=grand-plaza"><img src="image/2603IMG-20230421-WA0018.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Grand Plaza </h3>
											 <h3 >Rs 50 Lac onwards -</h3>
											 <p style="color:white;">Rajnagar Extension NH-58</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=grand-plaza" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=world-business-centre"><img src="image/9350IMG-20230422-WA0012.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>World Business Centre </h3>
											 <h3 >Rs 21lac-2.5 cr.</h3>
											 <p style="color:white;">K.P-5 Greater Noida west</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=world-business-centre" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=avs-city-square"><img src="image/6582images (31).jpeg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>AVS City Square </h3>
											 <h3 >Rs 1.5 Cr.onwards -</h3>
											 <p style="color:white;">Rajnagar Extension Ghaziabad hu</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=avs-city-square" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=galactic-city"><img src="image/7610IMG-20230517-WA0001.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Galactic City </h3>
											 <h3 >Rs 35 lacs onwards -</h3>
											 <p style="color:white;">K.P-5 Greater Noida </p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=galactic-city" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=green-beauty-farms"><img src="image/6569images (38).jpeg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Green Beauty Farms </h3>
											 <h3 >Rs 57 lac onwards -</h3>
											 <p style="color:white;">Noida sector -135</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=green-beauty-farms" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=ashoka-farms"><img src="image/7349images (37).jpeg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Ashoka Farms </h3>
											 <h3 >Rs 49 lacs onwards -</h3>
											 <p style="color:white;"> Noida sector -150</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=ashoka-farms" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=the-forest-farms"><img src="image/2140IMG-20230619-WA0008.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>The Forest Farms </h3>
											 <h3 >Rs 2.5 cr.onwords-</h3>
											 <p style="color:white;">Faridabad (H.R) opposite Noida sector -151A</p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=the-forest-farms" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
											
                                <div class="item">
									<div class="yrj">
										<a href="property-detail/?seo=harit-city"><img src="image/7159IMG-20231108-WA0001.jpg" class="spot_img" style=alt=""></a>
									</div>
									<div class="content-texter">
										<div class="row" style="align-items: center;">
										<div class="col-md-12">
											<h3>Harit City </h3>
											 <h3 >Rs 21 Lacs onwards -</h3>
											 <p style="color:white;">Jewar, Next to yamuna Expressway, Near jewar Airport </p>
										</div>
										
										<div class="col-md-12 ">
											 <a href="property-detail/?seo=harit-city" class="transation ms-auto tyers" id="del" style="float:right">Details</a> 

										</div>
									   
										</div>
									</div>
								</div>
								                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<style>
    .content-texter {
        position: absolute;
        /* top: 15px; */
        left: 20px;
        width: 100%;
        bottom: 12px;
    }
    .content-texter h3{
        color: white;
        
        
    }
    .yarj:before{
        position: absolute;
    content: "";
    width: 100%;
    height: 100%;
    left: 0;
    border-radius: 13px;
    bottom: 0;
    background-color: #00000045;
}
  .tyers{
          padding: 8px 25px !important;
    text-align: center !important;
    /* font-size: 10px; */
    position: absolute !important;
    right: 35px !important;
    bottom: 10px !important;
            

} 

#Residential .testimonial-simple h3 {
    line-height: 25px !important;
}

    
    @media(max-width:767px){
        .tyers{
           padding: 4px 20px !important;
    text-align: center !important;
    font-size: 10px;
    position: absolute !important;
    right: 16px !important;
    bottom: -5px !important;
            

}.content-texter {
        position: absolute;
        /* top: 15px; */
        left: 8px !important;
        width: 100%;
        bottom: 12px;
    }
    .content-texter h3{
        color: white;
        
        
    }
#Residential .testimonial-simple img{
    height: 136px !important;
}
#Residential .testimonial-simple h3 {
    line-height: 10px !important;
}

.content-texter h3{
        color: white;
        font-size: 13px !important;
        line-height: 0px !important;
    }
    .content-texter p{
        font-size: 10px;
    }
    
    
    }
    .owl-carousel .owl-dots {
       
        display: table;
        margin: 0 auto;
        margin-top: 0px;
        margin-bottom: 10px;
    }
</style>
        <!--============== Featured Property Start ==============-->
        <div class="full-row bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div >
                            <div >
                                <center><h2 class="d-table">Trending Projects</h2></center>
<center>                                <span class="d-table  w-sm-100 sub-title mx-auto ">The Noteworthy Real Estate in India</span>
</center>
                            </div>
                            <!-- <a href="property.php" class="transation ms-auto" id="del">View All</a> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="4block-carusel nav-disable owl-carousel">
						     			
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=eon"><img src="image/7923IMG-20230420-WA0010.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=eon">EON</a></h5>
                                        <span class="listing-price">By Fairfox Realty </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Sector 140 A Noida</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 10 Lacs onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=eon" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=kw-delhi-6"><img src="image/1700IMG-20230421-WA0003.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=kw-delhi-6">KW Delhi -6</a></h5>
                                        <span class="listing-price">By K.W Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar Extension Ghaziabad </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 25 lac onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=kw-delhi-6" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=great-northern-bazar"><img src="image/2445IMG-20230421-WA0007.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=great-northern-bazar">Great Northern Bazar </a></h5>
                                        <span class="listing-price">By Mr.Proview</span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar Extension Ghaziabad </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 50 lac - 2 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=great-northern-bazar" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=organic-homes"><img src="image/6845IMG-20230528-WA0013.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Residential</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=organic-homes">Organic Homes </a></h5>
                                        <span class="listing-price">By Rise Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> NH-24 Ghaziabad, </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 50 lac - 1.5 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=organic-homes" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=the-hub"><img src="image/8755IMG-20230420-WA0005.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=the-hub">The  Hub </a></h5>
                                        <span class="listing-price">By Jyoti Super-Tech</span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar Extension </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 10 Lacs onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=the-hub" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=himalaya-city-center"><img src="image/7377IMG-20230421-WA0013.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=himalaya-city-center">Himalaya city center</a></h5>
                                        <span class="listing-price">By Mr.Proview</span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar  Extension Ghaziabad</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 29 lac onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=himalaya-city-center" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=sarvottam-city-centre"><img src="image/6312IMG-20230319-WA0003.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=sarvottam-city-centre">Sarvottam City Centre </a></h5>
                                        <span class="listing-price">By Sarvottam Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> G.T Road Ghaziabad </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 57 lac onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=sarvottam-city-centre" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=grand-plaza"><img src="image/6970IMG-20230421-WA0018.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=grand-plaza">Grand Plaza </a></h5>
                                        <span class="listing-price">By Grand Plaza </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar Extension NH-58</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 50 Lac onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=grand-plaza" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=world-business-centre"><img src="image/6076IMG-20230422-WA0012.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=world-business-centre">World Business Centre </a></h5>
                                        <span class="listing-price">By World Infracons </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> K.P-5 Greater Noida west</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 21lac - 2.5 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=world-business-centre" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=sg-shikhar"><img src="image/7635IMG-20230422-WA0018.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Residential</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=sg-shikhar">SG Shikhar </a></h5>
                                        <span class="listing-price">By SG Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Siddharth Vihar Ghaziabad </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 54 lac - 1.5 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=sg-shikhar" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=golden-gate"><img src="image/2541IMG-20230528-WA0005.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Residential</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=golden-gate">Golden Gate </a></h5>
                                        <span class="listing-price">By Golden Gate</span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> NH-24 Ghaziabad</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 50 lac - 1.5 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=golden-gate" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=irish-platinum"><img src="image/4427IMG-20230528-WA0003.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Residential</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=irish-platinum">Irish Platinum </a></h5>
                                        <span class="listing-price">By Irish Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Greater Noida West </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 50 lac - 1.5 cr.</span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=irish-platinum" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=avs-city-square"><img src="image/453020191003_104526.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=avs-city-square">AVS City Square </a></h5>
                                        <span class="listing-price">By AVS Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Rajnagar Extension Ghaziabad hu</span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 1.5 Cr.onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=avs-city-square" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=galactic-city"><img src="image/2545IMG-20230517-WA0001.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">RERA Approved  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Commercial</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=galactic-city">Galactic City </a></h5>
                                        <span class="listing-price">By Sarvottam Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> K.P-5 Greater Noida </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 35 lacs onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=galactic-city" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=harit-city"><img src="image/8441IMG-20231222-WA0007.jpg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">Freehold  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Residential</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=harit-city">Harit City </a></h5>
                                        <span class="listing-price">By Harit Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Jewar, Next to yamuna Expressway, Near jewar Airport </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 21 Lacs onwards  - </span>

                                        <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=harit-city" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
							                           
                            
                        </div>
                    </div>
                    <div class="col-12">
                        <center><a href="all-trending/" id="del">View All</a></center>
                    </div>
                </div>
            </div>
        </div>
        <!--============== Featured Property End ==============-->

        <!--============== Featured Property Start ==============-->
        <div class="full-row bg-light" id="plots">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div >
                            <div >
                               <center> <h2 class="d-table">Plots Projects</h2></center>
                                <center><span class="d-table  w-sm-100 sub-title mx-auto ">The Noteworthy Real Estate in India</span></center>

                            </div>
                            <!-- <a href="#" class="transation ms-auto" id="del">View All</a> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="4block-carusel nav-disable owl-carousel">
                            			
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=royal-green-city"><img src="image/7687ak_1280_1262961092-1560507071_700x700.jpeg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">Freehold  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Plots</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=royal-green-city">Royal Green City </a></h5>
                                        <span class="listing-price">By Atharv Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> NH-58 Duhai Meerut Road Ghaziabad </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 22 Lacs onwards  - </span>

                                       <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=royal-green-city" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=new-vrindavan-township"><img src="image/7807ak_1280_1262961092-1560507071_700x700.jpeg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">Freehold  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Plots</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=new-vrindavan-township">New Vrindavan Township </a></h5>
                                        <span class="listing-price">By SSR Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Vrindavan Mathura </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 6 lacs onwards  - </span>

                                       <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=new-vrindavan-township" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
										
                            <div class="item">
                                <div class="property-grid-2 property-block transation">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <div class="cata position-absolute">
                                            <!---<span class="sale bg-secondary text-white"></span> -->
                                        </div>
                                                                                <a href="property-detail/?seo=shree-shyam-township"><img src="image/6757images (43).jpeg" alt="Image Not Found!" style="width:100%; height:220px;"></a>
                                                                                <ul class="position-absolute quick-meta">
                                            <li><a href="#" title="Add Favourite"><i class="flaticon-like-1 flat-mini"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content py-3 px-3 bg-white">
                                        <div id="rera">
                                            <a href="#">Freehold  <i class="fa fa-check"></i></a>
                                        </div>

                                        <div class="post-meta font-small text-uppercase list-color-primary">
                                            <a href="" class="listing-ctg"><i class="fa-solid fa-building"></i><span>Plots</span></a>
                                        </div>

                                        <h5 class="mb-0"><a class="text-secondary" href="property-detail/?seo=shree-shyam-township">Shree Shyam Township </a></h5>
                                        <span class="listing-price">By SSR Group </span>
                                        <span class="mb-1 d-block font-fifteen"><i class="fas fa-map-marker-alt text-primary"></i> Tappal Near jewar International Airport </span>

                                        <span class="listing-price"><i class="fa fa-inr"> </i> 15 lac onwards  - </span>

                                       <div id="connect">
                                            <a href="tel:+91    8383809575" id="call"><i class="fa fa-phone"></i></a>
                                            <a href="property-detail/?seo=shree-shyam-township" id="del">Details</a>
                                            <a href="#" id="msg"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa fa-envelope"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
							
                        </div>
                    </div>
                    <div class="col-12" >
                        <center><a href="all-plots/" id="del">View All</a></center>
                    </div>
                     
                </div>
            </div>
        </div>
        <!--============== Featured Property End ==============-->
<style>
    #del {
    background: linear-gradient(134deg, #00c8ff 0%, #92fe9d 100%);
    padding: 10px 35px;
    border-radius: 25px;
    color: #000;
    font-weight: 600;
}
#catos .entry-wrapper img{
    height:250px;
}
#catos .entry-wrapper #listing{
    left: 30px;
}
@media(max-width:767px){
    #catos .entry-wrapper img {
    height: 150px !important;
}

}
</style>
<div class="full-row bg-light" id="catos">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="text-secondary text-center mb-5">
                            <h2 class="text-secondary mx-auto mb-2">Curated Collections</h2>
                            <span class="d-table  w-sm-100 sub-title mx-auto ">Explore prime properties based on your recommendation</span>


                            <!-- <span class="d-table w-50 w-sm-100 sub-title mx-auto text-center">Mauris primis turpis Laoreet magna felis mi amet quam enim curae. Sodales semper tempor dictum faucibus habitasse.</span> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="city-carusel nav-disable owl-carousel">
						                             <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/2958ct2.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=2" style="padding: 0 20px;" id="place-btn"><center>Luxury Projects </center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/9265ct4.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=3" style="padding: 0 20px;" id="place-btn"><center>Builder Floors </center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/6440ct5.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=5" style="padding: 0 20px;" id="place-btn"><center>Ready to move</center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/5339images (27).jpeg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=8" style="padding: 0 20px;" id="place-btn"><center>Under Construction  </center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/1791images (5).jpeg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=9" style="padding: 0 20px;" id="place-btn"><center>Farm House </center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/9728IMG-20230422-WA0017.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=11" style="padding: 0 20px;" id="place-btn"><center>2&3 BHK SET</center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/5311images (25).jpeg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=12" style="padding: 0 20px;" id="place-btn"><center>Residential Plot</center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/4493images (24).jpeg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="" href="curated/?id=13" style="padding: 0 20px;" id="place-btn"><center>Premium  Villas </center></a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--============== Featured Property Start ==============-->
        <div class="full-row py-20">
            <div class="container">
                <div class="row">
                    <div class="col mb-12">
                        <div >
                            <div >
                              <center>  <h2 class="d-table">Popular Builders</h2></center>
                                <!---<span class="d-table  w-sm-100 sub-title mx-auto ">The top leading real state developer</span>--->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="5block-carusel nav-disable owl-carousel">
						                             <div class="item">
                                <img src="image/3015IMG-20230522-WA0001.jpg" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/5013IMG-20230522-WA0002.jpg" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/2384images (33).jpeg" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/9142images.png" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/3750logo (1).png" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/3026brigade-logo_horizontal-2048px.png" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/5487ATS_LOGO.png" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/6606FAIRFOX_GOLD_LOGO.png" style="width:243px; height:107px;" alt="">
                            </div>
							                            <div class="item">
                                <img src="image/6650images (35).jpeg" style="width:243px; height:107px;" alt="">
                            </div>
							                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--============== Featured Property End ==============-->

        <!--============== Featured Property Start ==============-->
        <div class="full-row bg-light" id="place">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="text-secondary text-center mb-5">
                            <h2 class="text-secondary mx-auto mb-2">Most Popular Places</h2>
                            <span class="d-table  w-sm-100 sub-title mx-auto ">The Noteworthy Real Estate in India</span>


                            <!-- <span class="d-table w-50 w-sm-100 sub-title mx-auto text-center">Mauris primis turpis Laoreet magna felis mi amet quam enim curae. Sodales semper tempor dictum faucibus habitasse.</span> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="city-carusel nav-disable owl-carousel">
						                             <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/4089download.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Agra </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/5200download (1).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Lucknow </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/8309download (2).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Haridwar </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/3036download (3).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Gurugram </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/5539download (4).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Ghaziabad </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/6966download (5).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Noida</a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/2805download (6).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Delhi </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/5538jambu-deep-hastinapur.jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Meerut </a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/9924download (7).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Vrindavan</a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="entry-wrapper hover-img-zoom position-relative h-100">
                                    <div class="overflow-hidden transation thumbnail-img">
                                        <img src="image/8197download (8).jpg" alt="real estate template">
                                    </div>
                                    <div class="d-flex position-absolute align-items-center bottom-0 p-4 w-100" id="listing">
                                        <h5 class="transation"><a class="btn btn-white font-700 rounded-pill text-nowrap" href="#" id="place-btn">Mathura</a></h5>
                                        <!-- <span class="d-table ms-4 fs-5 font-500 text-white">57 Listing</span> -->
                                    </div>
                                </div>
                            </div>
							                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--============== Featured Property End ==============-->

        <!--============== Featured Property Start ==============-->
        <div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col mb-0">
                        <h2 class="down-line w-50 mx-auto mb-4 text-center w-sm-100">Why Choose Us ?</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="3block-carusel nav-disable owl-carousel">
						                             <div class="item">
                                <div class="text-center p-4">
                                    <div class="box-100px rounded-circle p-0 mx-auto mb-4"><img src="image/7477pay.png" style="width:100px height:100px;" alt=""></div>
                                    <h4 class="mb-3 font-400">Real Estate Consulting</h4>
                                    <p><p>Those days are now pass&eacute; when purchasing a home used to be a very arduous task and buyers had to run from pillar to post to get everything in place...</p>
</p>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="text-center p-4">
                                    <div class="box-100px rounded-circle p-0 mx-auto mb-4"><img src="image/3942home.png" style="width:100px height:100px;" alt=""></div>
                                    <h4 class="mb-3 font-400">Home Loan Consultation</h4>
                                    <p><p>Attractive home loans have made purchasing property very convenient as buyers do not have to pay everything upfront. Our expertise in impartial loan advisory services...</p>
</p>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="text-center p-4">
                                    <div class="box-100px rounded-circle p-0 mx-auto mb-4"><img src="image/1480customer-service.png" style="width:100px height:100px;" alt=""></div>
                                    <h4 class="mb-3 font-400">After Sales Assistance</h4>
                                    <p><p>Attractive home loans have made purchasing property very convenient as buyers do not have to pay everything upfront. Our expertise in impartial loan advisory services...</p>
</p>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="text-center p-4">
                                    <div class="box-100px rounded-circle p-0 mx-auto mb-4"><img src="image/5922navigation.png" style="width:100px height:100px;" alt=""></div>
                                    <h4 class="mb-3 font-400">Vastu Consultation</h4>
                                    <p><p>Attractive home loans have made purchasing property very convenient as buyers do not have to pay everything upfront. Our expertise in impartial loan advisory services...</p>
</p>
                                </div>
                            </div>
							                            <div class="item">
                                <div class="text-center p-4">
                                    <div class="box-100px rounded-circle p-0 mx-auto mb-4"><img src="image/9923balance.png" style="width:100px height:100px;" alt=""></div>
                                    <h4 class="mb-3 font-400">Legal Consultation</h4>
                                    <p><p>Attractive home loans have made purchasing property very convenient as buyers do not have to pay everything upfront. Our expertise in impartial loan advisory services...</p>
</p>
                                </div>
                            </div>
							                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--============== Featured Property End ==============-->



        <!--============== Blog Section Start ==============-->
        <div class="full-row bg-white" style="padding-bottom:50px;">
            <div class="container">
                <div class="row">
                <div class="col-lg-12">
                        <h2 class="down-line w-50 w-sm-100 mx-auto text-center mb-5">Events</h2>
                    </div>
                </div>
                <div class="owl-carousel 3block-carusel nav-disable owl-outer-20">
				                     <div class="item">
                        <div class="property-grid-5 property-block border transation-this box-shadow">
                            <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom" style="">
                            <iframe width="100%" height="220" src="https://www.youtube.com/embed/T3Oo7VaeW-E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>                            </div>
                            <div class="property_text p-3">
                                <div class="post-meta">
                                  <!---  <ul>
                                        <li>
                                            <div class="icon-text">
                                                <a href="#" class="text-dark hover-text-primary"><i class="far fa-user text-primary me-2"></i><span>BY ROBERT HAVEN</span></a>
                                            </div>
                                        </li>
                                        
                                    </ul> -->
                                </div>
                                <h4 class="mt-2"><a class="font-400 text-secondary hover-text-primary" href="event-detail/?seo=our-latest-development-projects-by-more-efficient">Our latest development projects by more efficient.</a></h4>
                                <p><p>Kabira Realty Private limited is a Real Estate Consultancy Company providing investment related s</p>

                            </div>
                            <div class="d-flex align-items-center justify-content-between post-meta mt-2 p-3 border-top">
                               
                                <div class="button-wrap text-uppercase">
                                    <a href="event-detail/?seo=our-latest-development-projects-by-more-efficient">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>
					                    
                   
                </div>
                
            </div>
        </div>

                <footer class="full-row footer-default-dark bg-footer" style="padding-bottom: 30px" style="background:black;">
            <div class="container">
            <center>                            <h3 class="widget-title mb-4">Popular Links</h3>
</center>
                <div class="row row-cols-lg-4 row-cols-md-2 row-cols-1" >
 
                <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
									                                <li><a href="state-property/?seo=delhi">Real estate in Delhi</a></li>
								                                <li><a href="state-property/?seo=noida">Real estate in Noida</a></li>
								                                <li><a href="state-property/?seo=ghaziabad">Real estate in Ghaziabad</a></li>
								                                <li><a href="state-property/?seo=gurugram">Real estate in Gurugram</a></li>
								                                <li><a href="state-property/?seo=meerut">Real estate in Meerut </a></li>
								                                <li><a href="state-property/?seo=vrindavan">Real estate in Vrindavan</a></li>
								                                <li><a href="state-property/?seo=haridwar">Real estate in Haridwar </a></li>
								                                <li><a href="state-property/?seo=jaipur">Real estate in Jaipur </a></li>
								                                <li><a href="state-property/?seo=lucknow">Real estate in Lucknow</a></li>
								                                <li><a href="state-property/?seo=yamuna-expressway">Real estate in Yamuna Expressway </a></li>
								                                <li><a href="state-property/?seo=greater-noida">Real estate in Greater Noida </a></li>
								                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                           
                            <ul>
							                            <li><a href="state-property/?seo=delhi">Flats in Delhi</a></li>
							                            <li><a href="state-property/?seo=noida">Flats in Noida</a></li>
							                            <li><a href="state-property/?seo=ghaziabad">Flats in Ghaziabad</a></li>
							                            <li><a href="state-property/?seo=gurugram">Flats in Gurugram</a></li>
							                            <li><a href="state-property/?seo=meerut">Flats in Meerut </a></li>
							                            <li><a href="state-property/?seo=vrindavan">Flats in Vrindavan</a></li>
							                            <li><a href="state-property/?seo=haridwar">Flats in Haridwar </a></li>
							                            <li><a href="state-property/?seo=jaipur">Flats in Jaipur </a></li>
							                            <li><a href="state-property/?seo=lucknow">Flats in Lucknow</a></li>
							                            <li><a href="state-property/?seo=yamuna-expressway">Flats in Yamuna Expressway </a></li>
							                            <li><a href="state-property/?seo=greater-noida">Flats in Greater Noida </a></li>
							 
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
										
			<li><a href="state-property/?seo=delhi">New Projects in Delhi</a></li>
                          
										
			<li><a href="state-property/?seo=noida">New Projects in Noida</a></li>
                          
										
			<li><a href="state-property/?seo=ghaziabad">New Projects in Ghaziabad</a></li>
                          
										
			<li><a href="state-property/?seo=gurugram">New Projects in Gurugram</a></li>
                          
										
			<li><a href="state-property/?seo=meerut">New Projects in Meerut </a></li>
                          
										
			<li><a href="state-property/?seo=vrindavan">New Projects in Vrindavan</a></li>
                          
										
			<li><a href="state-property/?seo=haridwar">New Projects in Haridwar </a></li>
                          
										
			<li><a href="state-property/?seo=jaipur">New Projects in Jaipur </a></li>
                          
										
			<li><a href="state-property/?seo=lucknow">New Projects in Lucknow</a></li>
                          
										
			<li><a href="state-property/?seo=yamuna-expressway">New Projects in Yamuna Expressway </a></li>
                          
										
			<li><a href="state-property/?seo=greater-noida">New Projects in Greater Noida </a></li>
                          
							                          
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
										
                            <li><a href="state-property/?seo=delhi">Commercial Property in  Delhi</a></li>
										
                            <li><a href="state-property/?seo=noida">Commercial Property in  Noida</a></li>
										
                            <li><a href="state-property/?seo=ghaziabad">Commercial Property in  Ghaziabad</a></li>
										
                            <li><a href="state-property/?seo=gurugram">Commercial Property in  Gurugram</a></li>
										
                            <li><a href="state-property/?seo=meerut">Commercial Property in  Meerut </a></li>
										
                            <li><a href="state-property/?seo=vrindavan">Commercial Property in  Vrindavan</a></li>
										
                            <li><a href="state-property/?seo=haridwar">Commercial Property in  Haridwar </a></li>
										
                            <li><a href="state-property/?seo=jaipur">Commercial Property in  Jaipur </a></li>
										
                            <li><a href="state-property/?seo=lucknow">Commercial Property in  Lucknow</a></li>
										
                            <li><a href="state-property/?seo=yamuna-expressway">Commercial Property in  Yamuna Expressway </a></li>
										
                            <li><a href="state-property/?seo=greater-noida">Commercial Property in  Greater Noida </a></li>
							                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget mb-4">
                            <div class="footer-logo mb-4">
											
                                <a href="index.php"><img src="image/7091logo.png" alt="Image not found!" /></a>
								                            </div>
											
                            <p class="text-white mt-5"> Kabira Realty is a company with rich experience
 in real  estate advisory that believes each real estate 
 experience should be a simple and successful execution 
 from a Dreamto Reality...</p>
                        </div>
                        <div class="footer-widget media-widget mb-4">
                            <a href="https://www.facebook.com/profile.php?id=61554608451548"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/KabiraRealty"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/company/kabira-realty/"><i class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.instagram.com/kabirarealty/"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/@KabiraRealty"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            <h3 class="widget-title mb-4">Quick Links</h3>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="hindon/">About Us</a></li>
                                <li><a href="property/">Projects</a></li>
                                <li><a href="gallery/">Gallery</a></li>
                                <li><a href="blog/">Blog</a></li>
                                <li><a href="event/">Events</a></li>
                                <li><a href="career/">Careers</a></li>
                                <li><a href="contact/">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            <h3 class="widget-title mb-4">Support Links</h3>
                            <ul>
                               			
                                <li><a href="policy/?id=1">Privacy Policy</a></li>
											
                                <li><a href="policy/?id=2">Terms & Condition</a></li>
											
                                <li><a href="policy/?id=5">FAQ</a></li>
											
                                <li><a href="policy/?id=6">Help</a></li>
								                            </ul>
                        </div>
                    </div>
			
                    <div class="col">
                        <div class="footer-widget contact-widget mb-4">
                            <h3 class="widget-title mb-4">Contact Info</h3>
                            <ul>
                                <li>Office No :- 369 Raj Nagar Extension Rd, Sehani Khurd, Ghukna, Ghaziabad, Uttar Pradesh 201003</li>
                                <li>+91-    8383809575</li>
                                <li>+91-  9716825016</li>
                                <li>info@kabirarealty.com</li>
                                <li></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--============== Footer Section End ==============-->

        <!--============== Copyright Section Start ==============-->
        <div class="copyright bg-footer text-default py-1">
            <div class="container">
                <div class="row row-cols-md-2 row-cols-1">
                    <div class="col">
                        <span class="text-white">© 2023 kabirarealty. All right reserved</span>
                    </div>
                    <div class="col">
                        <!-- <ul class="line-menu float-end list-color-gray">
                            <li><a href="#">Privacy & Policy </a></li>
                            <li>|</li>
                            <li><a href="#">Site Map</a></li>
                        </ul> -->
                    </div>
                </div>
            </div>
        </div>
        <!--============== Copyright Section End ==============-->
<div class="footer-boxtt " style="position:fixed;bottom:0; width:100%;
z-index:1000;">
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-6 col-6" style="background: #07df11 ; padding:10px 0px;">
        <center><a href="" data-bs-toggle="modal" data-bs-target="#myModal" style="color: white;"><i class="fa-fa-phone" ></i>Enquiry Now</a></center>
        </div>
        <div class="col-md-6 col-6" style="background: #2197c3;padding:10px 0px;">
           <center> <a href="tel:+91    8383809575" style="color: white;"><i class="fa fa-phone" style="padding:0px 10px;"></i> Call Now</a></center>
        </div>
        </div>  
    </div>
</div>
<style>
    .media-widget a {
    margin-right: 15px;
    font-size: 23px;
}


</style>

        <!-- Scroll to top -->
        <!-- <div class="scroll-top-vertical xs-mx-none" id="scroll">Go Top <i class="ms-2 fa-solid fa-arrow-right-long"></i></div> -->
        <!-- End Scroll To top -->

        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <a href="https://api.whatsapp.com/send?phone=+91-99999999999&text=I am Interested." class="float" target="_blank">
            <i class="fa fa-whatsapp my-float"></i>
        </a>

        <a href="https://api.whatsapp.com/send?phone=+91-99999999999&text=I am Interested." class="float1" target="_blank">
            <i class="fa fa-phone my-float1"></i>
        </a> -->

        <style>
            .float {
                position: fixed;
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 10px;
                background-color: #25d366;
                color: #FFF;
                border-radius: 50px;
                text-align: center;
                font-size: 26px;
                z-index: 100;
            }
            
            .my-float {
                margin-top: 12px;
            }
            
            .float1 {
                position: fixed;
                width: 50px;
                height: 50px;
                bottom: 80px;
                right: 10px;
                background-color: #ff0000;
                color: #FFF;
                border-radius: 50px;
                text-align: center;
                font-size: 26px;
                z-index: 100;
            }
            
            .my-float1 {
                margin-top: 12px;
            }
        </style>
  
  <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
            
                <!-- Modal Header -->
                <div class="modal-header">
                <center>  <span class="modal-title">Enquiry</span></center>
                <button type="button" class="close" data-bs-dismiss="modal">×</button>
                </div>
                
                <!-- Modal body -->
                <div class="modal-body">
                    <p class="text-intro">For any query, fill the form.</p>
                    <div class="form-div">
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Name *" required>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="E-Mail ID *" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="phone" placeholder="Mobile *" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary btn-block mybtn">Submit</button>

                            <center><p>Request a Call Back <i class="fa fa-phone"></i> +91     8383809575</p></center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <style>
    .banner-heading{
	font-family: 'Nanum Gothic', sans-serif;
	font-size: 75px;
    font-weight: 700;
    line-height: 100px;
    margin-bottom: 30px;
	color:#fff;
}
.banner-sub-heading{
	font-family: 'Nanum Gothic', sans-serif;
	font-size: 30px;
    font-weight: 300;
    line-height: 30px;
    margin-bottom: 50px;
	color:#fff;
}
.btn-warning{background-color:#eca439;}
.btn-warning:hover{background-color:#f39305;}
.mybtn{
	border-radius:0; 
	height:30px;
	margin:10px auto;
	line-height:10px;
}
.model .form-control{
	border: 2px solid #000 !important;
}
.form-check-input{
	background-color:#fff !important;
	border-radius:50% !important;
	border:2px solid #f39305 !important;
}
.modal-content{
	width:400px;
	margin:auto;
    z-index: 100000;
}

.modal-header {

    padding:0.7rem 1rem;
    border-bottom: 1px solid #e9ecef;
   border-radius:10px;
	background-color:#2197cf;
}
.modal-title{
	font-size:16px;
	font-family: 'Nanum Gothic', sans-serif;
	text-transform:uppercase;
	color:#fff;
	text-align:center;
	}
.modal-body{
	background-image:url('http://snippetimg.meditialabs.com/bgs/bg1.jpg');
	background-position:top left;
	background-size:cover;
	width:100%;
	padding: 20px;
}
body.modal-open .supreme-container{
    -webkit-filter: blur(1px);
    -moz-filter: blur(1px);
    -o-filter: blur(1px);
    -ms-filter: blur(1px);
    filter: blur(1px);
}
.text-intro{
	font-size:0.8em;
	color:#777;
	text-align:center;
}
.form-div{
	background-color:#fff;
	padding: 10px;
	border-radius: 10px;
	box-shadow:2px 2px 2px 2px rgba(215,215,215,0.5);
}
form{
	border:0 !important;
}
.form-group {
    position: relative;
    display: flex;
    border: 1px solid #000;
    margin-bottom: 15px;
    border-radius: 10px;
}

.modal-body p{
    font-weight: bold;
    font-size: 18px;
    margin: 0px !important;
}

.modal-header .close{
    background-color: transparent;
    border: none;
    font-size: 28px;
}
@media (max-width:500px){
	.modal-content{
	width:330px;
	margin:auto;
}
.banner-heading{
	font-size: 30px;
    line-height: 30px;
    margin-bottom: 20px;
}
.banner-sub-heading{
	font-size: 10px;
    font-weight: 200;
    line-height: 10px;
    margin-bottom: 40px;
}
}
@media (max-width:768px){
	.banner-text{
	padding:150px 0 150px 0;
}
	.banner-sub-heading{
	font-size: 23px;
    font-weight: 200;
    line-height: 23px;
    margin-bottom: 40px;
}

@media(max-width:600px){
    .modal-body p{
        font-weight: bold;
        font-size: 15px;
    }
}
}
  </style>

    </div>

    <!-- Javascript Files -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
    <script src="assets/js/jquery.fancybox.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/range/tmpl.js"></script>
    <script src="assets/js/range/jquery.dependClass.js"></script>
    <script src="assets/js/range/draggable.js"></script>
    <script src="assets/js/range/jquery.slider.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/mixitup.min.js"></script>
    <script src="assets/js/paraxify.js"></script>
    <script src="assets/js/custom.js"></script>

    <script>
        $('#single-property').layerSlider({
            sliderVersion: '6.5.0b2',
            type: 'popup',
            pauseOnHover: 'disabled',
            skin: 'photogallery',
            globalBGSize: 'cover',
            navStartStop: false,
            hoverBottomNav: true,
            showCircleTimer: false,
            thumbnailNavigation: 'always',
            tnContainerWidth: '100%',
            tnHeight: 70,
            popupShowOnTimeout: 1,
            popupShowOnce: false,
            popupCloseButtonStyle: 'background: rgba(0,0,0,.5); border-radius: 2px; border: 0; left: auto; right: 10px;',
            popupResetOnClose: 'disabled',
            popupDistanceLeft: 20,
            popupDistanceRight: 20,
            popupDistanceTop: 20,
            popupDistanceBottom: 20,
            popupDurationIn: 750,
            popupDelayIn: 500,
            popupTransitionIn: 'scalefromtop',
            popupTransitionOut: 'scaletobottom',
            skinsPath: 'assets/skins/'
        });

        // Statistic
        if (document.querySelector('#mychart') !== null) {
            var ctx = document.getElementById("mychart").getContext('2d');

            // Data with datasets options
            var data = {
                type: 'line',
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct"],
                datasets: [{
                    label: 'Growth',
                    fill: true,
                    backgroundColor: "#def7e0",
                    borderColor: "#17c788",
                    data: [0, 150, 450, 400, 480, 630, 580, 500, 530, 400, 430, 600, 400],
                }]
            }

            // Chart declaration with some options:
            var mychart = new Chart(ctx, {
                type: 'line',
                data: data,
            });
        }

        //Doughnut and Pie
        if (document.querySelector('#mychart-2') !== null) {
            var ctx2 = document.getElementById("mychart-2").getContext('2d');

            // Data with datasets options
            var data2 = {
                type: 'doughnut',
                labels: ['Desktop', 'Tablet', 'Mobile'],
                datasets: [{
                    data: [10, 20, 30],
                    backgroundColor: ['rgb(255, 99, 132)', 'rgb(54, 162, 235)', 'rgb(255, 205, 86)']
                }],

            };

            // For a pie chart
            var myPieChart = new Chart(ctx2, {
                type: 'pie',
                data: data2,
            });
            // And for a doughnut chart
            var myDoughnutChart = new Chart(ctx2, {
                type: 'doughnut',
                data: data2,
            });
        }
    </script>

    <script>
        var TxtRotate = function(el, toRotate, period) {
            this.toRotate = toRotate;
            this.el = el;
            this.loopNum = 0;
            this.period = parseInt(period, 10) || 2000;
            this.txt = '';
            this.tick();
            this.isDeleting = false;
        };

        TxtRotate.prototype.tick = function() {
            var i = this.loopNum % this.toRotate.length;
            var fullTxt = this.toRotate[i];

            if (this.isDeleting) {
                this.txt = fullTxt.substring(0, this.txt.length - 1);
            } else {
                this.txt = fullTxt.substring(0, this.txt.length + 1);
            }

            this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

            var that = this;
            var delta = 300 - Math.random() * 100;

            if (this.isDeleting) {
                delta /= 2;
            }

            if (!this.isDeleting && this.txt === fullTxt) {
                delta = this.period;
                this.isDeleting = true;
            } else if (this.isDeleting && this.txt === '') {
                this.isDeleting = false;
                this.loopNum++;
                delta = 500;
            }

            setTimeout(function() {
                that.tick();
            }, delta);
        };

        window.onload = function() {
            var elements = document.getElementsByClassName('txt-rotate');
            for (var i = 0; i < elements.length; i++) {
                var toRotate = elements[i].getAttribute('data-rotate');
                var period = elements[i].getAttribute('data-period');
                if (toRotate) {
                    new TxtRotate(elements[i], JSON.parse(toRotate), period);
                }
            }
            // INJECT CSS
            var css = document.createElement("style");
            css.type = "text/css";
            css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #666 }";
            document.body.appendChild(css);
        };
    </script>

    <script>
        (function($) {
            $.fn.countTo = function(options) {
                options = options || {};

                return $(this).each(function() {
                    // set options for current element
                    var settings = $.extend({}, $.fn.countTo.defaults, {
                        from: $(this).data('from'),
                        to: $(this).data('to'),
                        speed: $(this).data('speed'),
                        refreshInterval: $(this).data('refresh-interval'),
                        decimals: $(this).data('decimals')
                    }, options);

                    // how many times to update the value, and how much to increment the value on each update
                    var loops = Math.ceil(settings.speed / settings.refreshInterval),
                        increment = (settings.to - settings.from) / loops;

                    // references & variables that will change with each update
                    var self = this,
                        $self = $(this),
                        loopCount = 0,
                        value = settings.from,
                        data = $self.data('countTo') || {};

                    $self.data('countTo', data);

                    // if an existing interval can be found, clear it first
                    if (data.interval) {
                        clearInterval(data.interval);
                    }
                    data.interval = setInterval(updateTimer, settings.refreshInterval);

                    // initialize the element with the starting value
                    render(value);

                    function updateTimer() {
                        value += increment;
                        loopCount++;

                        render(value);

                        if (typeof(settings.onUpdate) == 'function') {
                            settings.onUpdate.call(self, value);
                        }

                        if (loopCount >= loops) {
                            // remove the interval
                            $self.removeData('countTo');
                            clearInterval(data.interval);
                            value = settings.to;

                            if (typeof(settings.onComplete) == 'function') {
                                settings.onComplete.call(self, value);
                            }
                        }
                    }

                    function render(value) {
                        var formattedValue = settings.formatter.call(self, value, settings);
                        $self.html(formattedValue);
                    }
                });
            };

            $.fn.countTo.defaults = {
                from: 0, // the number the element should start at
                to: 0, // the number the element should end at
                speed: 1000, // how long it should take to count between the target numbers
                refreshInterval: 100, // how often the element should be updated
                decimals: 0, // the number of decimal places to show
                formatter: formatter, // handler for formatting the value before rendering
                onUpdate: null, // callback method for every time the element is updated
                onComplete: null // callback method for when the element finishes updating
            };

            function formatter(value, settings) {
                return value.toFixed(settings.decimals);
            }
        }(jQuery));

        jQuery(function($) {
            // custom formatting example
            $('.count-number').data('countToOptions', {
                formatter: function(value, options) {
                    return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                }
            });

            // start all the timers
            $('.timer').each(count);

            function count(options) {
                var $this = $(this);
                options = $.extend({}, options || {}, $this.data('countToOptions') || {});
                $this.countTo(options);
            }
        });
    </script>
</body>

</html>