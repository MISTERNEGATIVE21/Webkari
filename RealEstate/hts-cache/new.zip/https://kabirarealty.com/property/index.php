<!doctype html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Uniland - Real Estate HTML5 Template">
    <meta name="keywords" content="real estate, property, property search, agent, apartments, booking, business, idx, housing, real estate agency, rental">
    <meta name="author" content="unicoder">
    <title>Kabira Realty</title>
    <link rel="shortcut icon" href="/image/icon.png">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sen:wght@400;700&amp;display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,300;0,400;0,500;0,700;1,400&amp;display=swap" rel="stylesheet">

    <!-- Required style of the theme -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="../assets/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/animate.min.css">
    <link rel="stylesheet" href="../assets/webfonts/flaticon/flaticon.css">
    <link rel="stylesheet" href="../assets/css/owl.css">
    <link rel="stylesheet" href="../assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="../assets/css/layerslider.css">
    <link rel="stylesheet" href="../assets/css/template.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/colors/color.css">
    <link rel="stylesheet" href="../assets/css/loader.css">

</head>

<body>

    <div id="page_wrapper" class="bg-light">

        <header class="header-style nav-on-top bg-white">
            <div class="main-nav">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <nav class="navbar navbar-expand-lg nav-secondary nav-primary-hover nav-line-active">
							 <a class="navbar-brand" href="index.php">
                               	<img class="nav-logo" src="/image/logo.png" alt="Image not found !"></a>
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon flaticon-menu flat-small text-primary"></span>
                                  </button>
                              
                                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav ms-auto">                                     
                                        <li class="nav-item">
                                            <a class="nav-link" href="../">Home</a>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">About Us</a>
                                            <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="../about/">Mr.Pradeep Kabira</a></li>
                                                <li><a class="dropdown-item" href="../kabira/">About Kabira Realty</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Builders</a>
                                            <ul class="dropdown-menu">
                                             	                                                <li><a class="dropdown-item" href="../builder/?seo=fairfox-realty">Fairfox Realty </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=kw-group">K.W Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=mrproview">Mr.Proview</a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=jyoti-supertech">Jyoti Super-Tech</a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=sarvottam-group">Sarvottam Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=himalaya-group">Himalaya Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=grand-plaza">Grand Plaza </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=rise-group">Rise Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=i-s-buildtech">I. & S. Buildtech </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=world-infracons">World Infracons </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=sg-group">SG Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=golden-gate">Golden Gate</a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=atharv-group">Atharv Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=irish-group">Irish Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=avs-group">AVS Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=kabira-group">Kabira Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=ssr-group">SSR Group </a></li>
                                                                                                <li><a class="dropdown-item" href="../builder/?seo=harit-group">Harit Group </a></li>
                                                                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Projects</a>
                                            <ul class="dropdown-menu">
                                               	                                                <li><a class="dropdown-item" href="../property/?seo=residental">Residential</a></li>
												                                                <li><a class="dropdown-item" href="../property/?seo=commercial">Commercial</a></li>
												                                                <li><a class="dropdown-item" href="../property/?seo=resale">Resale</a></li>
												                                                <li><a class="dropdown-item" href="../property/?seo=plots">Plots</a></li>
												                                            </ul>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Media</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="../gallery/">Gallery</a></li>
                                                <li><a class="dropdown-item" href="../blog/">Blogs</a></li>
                                                <li><a class="dropdown-item" href="../event/">Events</a></li>
                                            </ul>
                                        </li>
                                         <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#">Careers</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="../career/">Careers</a></li>
                                                <li><a class="dropdown-item" href="../associate/">Associate</a></li>
                                                <li><a class="dropdown-item" href="../franchisee/">Franchisee</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../contact/">Contact Us</a>
                                        </li>

                                    </ul>
                                    <!-- <a href="#" class="btn btn-white add-listing-btn">+ Create Listing</a> -->
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--============== Page title Start ==============-->

        <div class="full-row py-100" style="background: linear-gradient(134deg, #00c8ff 0%, #92fe9d 100%);">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h3 class="text-secondary text-center"></h3>
                        
                    </div>
                </div>
            </div>
        </div>
        <!--============== Page title End ==============-->

        <!--============== Property Grid View Start ==============-->
        <div class="full-row pt-30" id="p-list">
            <div class="container">
                <div class="row row-cols-xl-4 row-cols-md-2 row-cols-1">
				
                                              
                    
                </div>
                
            </div>
        </div>
        <!--============== Property Grid View End ==============-->

                <footer class="full-row footer-default-dark bg-footer" style="padding-bottom: 30px" style="background:black;">
            <div class="container">
            <center>                            <h3 class="widget-title mb-4">Popular Links</h3>
</center>
                <div class="row row-cols-lg-4 row-cols-md-2 row-cols-1" >
 
                <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
									                                <li><a href="../state-property/?seo=delhi">Real estate in Delhi</a></li>
								                                <li><a href="../state-property/?seo=noida">Real estate in Noida</a></li>
								                                <li><a href="../state-property/?seo=ghaziabad">Real estate in Ghaziabad</a></li>
								                                <li><a href="../state-property/?seo=gurugram">Real estate in Gurugram</a></li>
								                                <li><a href="../state-property/?seo=meerut">Real estate in Meerut </a></li>
								                                <li><a href="../state-property/?seo=vrindavan">Real estate in Vrindavan</a></li>
								                                <li><a href="../state-property/?seo=haridwar">Real estate in Haridwar </a></li>
								                                <li><a href="../state-property/?seo=jaipur">Real estate in Jaipur </a></li>
								                                <li><a href="../state-property/?seo=lucknow">Real estate in Lucknow</a></li>
								                                <li><a href="../state-property/?seo=yamuna-expressway">Real estate in Yamuna Expressway </a></li>
								                                <li><a href="../state-property/?seo=greater-noida">Real estate in Greater Noida </a></li>
								                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                           
                            <ul>
							                            <li><a href="../state-property/?seo=delhi">Flats in Delhi</a></li>
							                            <li><a href="../state-property/?seo=noida">Flats in Noida</a></li>
							                            <li><a href="../state-property/?seo=ghaziabad">Flats in Ghaziabad</a></li>
							                            <li><a href="../state-property/?seo=gurugram">Flats in Gurugram</a></li>
							                            <li><a href="../state-property/?seo=meerut">Flats in Meerut </a></li>
							                            <li><a href="../state-property/?seo=vrindavan">Flats in Vrindavan</a></li>
							                            <li><a href="../state-property/?seo=haridwar">Flats in Haridwar </a></li>
							                            <li><a href="../state-property/?seo=jaipur">Flats in Jaipur </a></li>
							                            <li><a href="../state-property/?seo=lucknow">Flats in Lucknow</a></li>
							                            <li><a href="../state-property/?seo=yamuna-expressway">Flats in Yamuna Expressway </a></li>
							                            <li><a href="../state-property/?seo=greater-noida">Flats in Greater Noida </a></li>
							 
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
										
			<li><a href="../state-property/?seo=delhi">New Projects in Delhi</a></li>
                          
										
			<li><a href="../state-property/?seo=noida">New Projects in Noida</a></li>
                          
										
			<li><a href="../state-property/?seo=ghaziabad">New Projects in Ghaziabad</a></li>
                          
										
			<li><a href="../state-property/?seo=gurugram">New Projects in Gurugram</a></li>
                          
										
			<li><a href="../state-property/?seo=meerut">New Projects in Meerut </a></li>
                          
										
			<li><a href="../state-property/?seo=vrindavan">New Projects in Vrindavan</a></li>
                          
										
			<li><a href="../state-property/?seo=haridwar">New Projects in Haridwar </a></li>
                          
										
			<li><a href="../state-property/?seo=jaipur">New Projects in Jaipur </a></li>
                          
										
			<li><a href="../state-property/?seo=lucknow">New Projects in Lucknow</a></li>
                          
										
			<li><a href="../state-property/?seo=yamuna-expressway">New Projects in Yamuna Expressway </a></li>
                          
										
			<li><a href="../state-property/?seo=greater-noida">New Projects in Greater Noida </a></li>
                          
							                          
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            
                            <ul>
										
                            <li><a href="../state-property/?seo=delhi">Commercial Property in  Delhi</a></li>
										
                            <li><a href="../state-property/?seo=noida">Commercial Property in  Noida</a></li>
										
                            <li><a href="../state-property/?seo=ghaziabad">Commercial Property in  Ghaziabad</a></li>
										
                            <li><a href="../state-property/?seo=gurugram">Commercial Property in  Gurugram</a></li>
										
                            <li><a href="../state-property/?seo=meerut">Commercial Property in  Meerut </a></li>
										
                            <li><a href="../state-property/?seo=vrindavan">Commercial Property in  Vrindavan</a></li>
										
                            <li><a href="../state-property/?seo=haridwar">Commercial Property in  Haridwar </a></li>
										
                            <li><a href="../state-property/?seo=jaipur">Commercial Property in  Jaipur </a></li>
										
                            <li><a href="../state-property/?seo=lucknow">Commercial Property in  Lucknow</a></li>
										
                            <li><a href="../state-property/?seo=yamuna-expressway">Commercial Property in  Yamuna Expressway </a></li>
										
                            <li><a href="../state-property/?seo=greater-noida">Commercial Property in  Greater Noida </a></li>
							                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget mb-4">
                            <div class="footer-logo mb-4">
											
                                <a href="../"><img src="../image/7091logo.png" alt="Image not found!" /></a>
								                            </div>
											
                            <p class="text-white mt-5"> Kabira Realty is a company with rich experience
 in real  estate advisory that believes each real estate 
 experience should be a simple and successful execution 
 from a Dreamto Reality...</p>
                        </div>
                        <div class="footer-widget media-widget mb-4">
                            <a href="https://www.facebook.com/profile.php?id=61554608451548"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/KabiraRealty"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/company/kabira-realty/"><i class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.instagram.com/kabirarealty/"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/@KabiraRealty"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            <h3 class="widget-title mb-4">Quick Links</h3>
                            <ul>
                                <li><a href="../">Home</a></li>
                                <li><a href="../hindon/">About Us</a></li>
                                <li><a href="../gallery/">Gallery</a></li>
                                <li><a href="../blog/">Blog</a></li>
                                <li><a href="../event/">Events</a></li>
                                <li><a href="../career/">Careers</a></li>
                                <li><a href="../contact/">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget footer-nav mb-4">
                            <h3 class="widget-title mb-4">Support Links</h3>
                            <ul>
                               			
                                <li><a href="../policy/?id=1">Privacy Policy</a></li>
											
                                <li><a href="../policy/?id=2">Terms & Condition</a></li>
											
                                <li><a href="../policy/?id=5">FAQ</a></li>
											
                                <li><a href="../policy/?id=6">Help</a></li>
								                            </ul>
                        </div>
                    </div>
			
                    <div class="col">
                        <div class="footer-widget contact-widget mb-4">
                            <h3 class="widget-title mb-4">Contact Info</h3>
                            <ul>
                                 <li>Office No :- 369 Raj Nagar Extension Rd, Sehani Khurd, Ghukna, Ghaziabad, Uttar Pradesh 201003</li>
                                <li>+91-    8383809575</li>
                                <li>+91-  9716825016</li>
                                <li>info@kabirarealty.com</li>
                                <li></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--============== Footer Section End ==============-->

        <!--============== Copyright Section Start ==============-->
        <div class="copyright bg-footer text-default py-1">
            <div class="container">
                <div class="row row-cols-md-2 row-cols-1">
                    <div class="col">
                        <span class="text-white">© 2023 kabirarealty. All right reserved</span>
                    </div>
                    <div class="col">
                        <!-- <ul class="line-menu float-end list-color-gray">
                            <li><a href="#">Privacy & Policy </a></li>
                            <li>|</li>
                            <li><a href="#">Site Map</a></li>
                        </ul> -->
                    </div>
                </div>
            </div>
        </div>
        <!--============== Copyright Section End ==============-->
<div class="footer-boxtt " style="position:fixed;bottom:0; width:100%;
z-index:1000;">
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-6 col-6" style="background: #07df11 ; padding:10px 0px;">
        <center><a href="" data-bs-toggle="modal" data-bs-target="#myModal" style="color: white;"><i class="fa-fa-phone" ></i>Enquiry Now</a></center>
        </div>
        <div class="col-md-6 col-6" style="background: #2197c3;padding:10px 0px;">
           <center> <a href="tel:+91    8383809575" style="color: white;"><i class="fa fa-phone" style="padding:0px 10px;"></i> Call Now</a></center>
        </div>
        </div>  
    </div>
</div>
<style>
    .media-widget a {
    margin-right: 15px;
    font-size: 23px;
}


</style>
        <!-- Scroll to top -->
        <!-- <div class="scroll-top-vertical xs-mx-none" id="scroll">Go Top <i class="ms-2 fa-solid fa-arrow-right-long"></i></div> -->
        <!-- End Scroll To top -->

        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <a href="https://api.whatsapp.com/send?phone=+91-99999999999&text=I am Interested." class="float" target="_blank">
            <i class="fa fa-whatsapp my-float"></i>
        </a>

        <a href="https://api.whatsapp.com/send?phone=+91-99999999999&text=I am Interested." class="float1" target="_blank">
            <i class="fa fa-phone my-float1"></i>
        </a> -->

        <style>
            .float {
                position: fixed;
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 10px;
                background-color: #25d366;
                color: #FFF;
                border-radius: 50px;
                text-align: center;
                font-size: 26px;
                z-index: 100;
            }
            
            .my-float {
                margin-top: 12px;
            }
            
            .float1 {
                position: fixed;
                width: 50px;
                height: 50px;
                bottom: 80px;
                right: 10px;
                background-color: #ff0000;
                color: #FFF;
                border-radius: 50px;
                text-align: center;
                font-size: 26px;
                z-index: 100;
            }
            
            .my-float1 {
                margin-top: 12px;
            }
        </style>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
            
                <!-- Modal Header -->
                <div class="modal-header">
                <center>  <span class="modal-title">Enquiry</span></center>
                <button type="button" class="close" data-bs-dismiss="modal">×</button>
                </div>
                
                <!-- Modal body -->
                <div class="modal-body">
                    <p class="text-intro">For any query, fill the form.</p>
                    <div class="form-div">
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Name *" required>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="E-Mail ID *" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="phone" placeholder="Mobile *" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary btn-block mybtn">Submit</button>

                            <center><p>Request a Call Back <i class="fa fa-phone"></i> +91     8383809575</p></center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <style>
    .banner-heading{
	font-family: 'Nanum Gothic', sans-serif;
	font-size: 75px;
    font-weight: 700;
    line-height: 100px;
    margin-bottom: 30px;
	color:#fff;
}
.banner-sub-heading{
	font-family: 'Nanum Gothic', sans-serif;
	font-size: 30px;
    font-weight: 300;
    line-height: 30px;
    margin-bottom: 50px;
	color:#fff;
}
.btn-warning{background-color:#eca439;}
.btn-warning:hover{background-color:#f39305;}
.mybtn{
	border-radius:0; 
	height:30px;
	margin:10px auto;
	line-height:10px;
}
.model .form-control{
	border: 2px solid #000 !important;
}
.form-check-input{
	background-color:#fff !important;
	border-radius:50% !important;
	border:2px solid #f39305 !important;
}
.modal-content{
	width:400px;
	margin:auto;
    z-index: 100000;
}

.modal-header {

    padding:0.7rem 1rem;
    border-bottom: 1px solid #e9ecef;
   border-radius:10px;
	background-color:#2197cf;
}
.modal-title{
	font-size:16px;
	font-family: 'Nanum Gothic', sans-serif;
	text-transform:uppercase;
	color:#fff;
	text-align:center;
	}
.modal-body{
	background-image:url('http://snippetimg.meditialabs.com/bgs/bg1.jpg');
	background-position:top left;
	background-size:cover;
	width:100%;
	padding: 20px;
}
body.modal-open .supreme-container{
    -webkit-filter: blur(1px);
    -moz-filter: blur(1px);
    -o-filter: blur(1px);
    -ms-filter: blur(1px);
    filter: blur(1px);
}
.text-intro{
	font-size:0.8em;
	color:#777;
	text-align:center;
}
.form-div{
	background-color:#fff;
	padding: 10px;
	border-radius: 10px;
	box-shadow:2px 2px 2px 2px rgba(215,215,215,0.5);
}
form{
	border:0 !important;
}
.form-group {
    position: relative;
    display: flex;
    border: 1px solid #000;
    margin-bottom: 15px;
    border-radius: 10px;
}

.modal-body p{
    font-weight: bold;
    font-size: 18px;
    margin: 0px !important;
}

.modal-header .close{
    background-color: transparent;
    border: none;
    font-size: 28px;
}
@media (max-width:500px){
	.modal-content{
	width:330px;
	margin:auto;
}
.banner-heading{
	font-size: 30px;
    line-height: 30px;
    margin-bottom: 20px;
}
.banner-sub-heading{
	font-size: 10px;
    font-weight: 200;
    line-height: 10px;
    margin-bottom: 40px;
}
}
@media (max-width:768px){
	.banner-text{
	padding:150px 0 150px 0;
}
	.banner-sub-heading{
	font-size: 23px;
    font-weight: 200;
    line-height: 23px;
    margin-bottom: 40px;
}

@media(max-width:600px){
    .modal-body p{
        font-weight: bold;
        font-size: 15px;
    }
}
}
  </style>

    </div>

    <!-- Javascript Files -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/bootstrap-select.min.js"></script>
    <script src="../assets/js/jquery.fancybox.min.js"></script>
    <script src="../assets/js/owl.js"></script>
    <script src="../assets/js/range/tmpl.js"></script>
    <script src="../assets/js/range/jquery.dependClass.js"></script>
    <script src="../assets/js/range/draggable.js"></script>
    <script src="../assets/js/range/jquery.slider.js"></script>
    <script src="../assets/js/wow.js"></script>
    <script src="../assets/js/mixitup.min.js"></script>
    <script src="../assets/js/paraxify.js"></script>
    <script src="../assets/js/custom.js"></script>

    <script>
        $('#single-property').layerSlider({
            sliderVersion: '6.5.0b2',
            type: 'popup',
            pauseOnHover: 'disabled',
            skin: 'photogallery',
            globalBGSize: 'cover',
            navStartStop: false,
            hoverBottomNav: true,
            showCircleTimer: false,
            thumbnailNavigation: 'always',
            tnContainerWidth: '100%',
            tnHeight: 70,
            popupShowOnTimeout: 1,
            popupShowOnce: false,
            popupCloseButtonStyle: 'background: rgba(0,0,0,.5); border-radius: 2px; border: 0; left: auto; right: 10px;',
            popupResetOnClose: 'disabled',
            popupDistanceLeft: 20,
            popupDistanceRight: 20,
            popupDistanceTop: 20,
            popupDistanceBottom: 20,
            popupDurationIn: 750,
            popupDelayIn: 500,
            popupTransitionIn: 'scalefromtop',
            popupTransitionOut: 'scaletobottom',
            skinsPath: 'assets/skins/'
        });

        // Statistic
        if (document.querySelector('#mychart') !== null) {
            var ctx = document.getElementById("mychart").getContext('2d');

            // Data with datasets options
            var data = {
                type: 'line',
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct"],
                datasets: [{
                    label: 'Growth',
                    fill: true,
                    backgroundColor: "#def7e0",
                    borderColor: "#17c788",
                    data: [0, 150, 450, 400, 480, 630, 580, 500, 530, 400, 430, 600, 400],
                }]
            }

            // Chart declaration with some options:
            var mychart = new Chart(ctx, {
                type: 'line',
                data: data,
            });
        }

        //Doughnut and Pie
        if (document.querySelector('#mychart-2') !== null) {
            var ctx2 = document.getElementById("mychart-2").getContext('2d');

            // Data with datasets options
            var data2 = {
                type: 'doughnut',
                labels: ['Desktop', 'Tablet', 'Mobile'],
                datasets: [{
                    data: [10, 20, 30],
                    backgroundColor: ['rgb(255, 99, 132)', 'rgb(54, 162, 235)', 'rgb(255, 205, 86)']
                }],

            };

            // For a pie chart
            var myPieChart = new Chart(ctx2, {
                type: 'pie',
                data: data2,
            });
            // And for a doughnut chart
            var myDoughnutChart = new Chart(ctx2, {
                type: 'doughnut',
                data: data2,
            });
        }
    </script>

    <script>
        var TxtRotate = function(el, toRotate, period) {
            this.toRotate = toRotate;
            this.el = el;
            this.loopNum = 0;
            this.period = parseInt(period, 10) || 2000;
            this.txt = '';
            this.tick();
            this.isDeleting = false;
        };

        TxtRotate.prototype.tick = function() {
            var i = this.loopNum % this.toRotate.length;
            var fullTxt = this.toRotate[i];

            if (this.isDeleting) {
                this.txt = fullTxt.substring(0, this.txt.length - 1);
            } else {
                this.txt = fullTxt.substring(0, this.txt.length + 1);
            }

            this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

            var that = this;
            var delta = 300 - Math.random() * 100;

            if (this.isDeleting) {
                delta /= 2;
            }

            if (!this.isDeleting && this.txt === fullTxt) {
                delta = this.period;
                this.isDeleting = true;
            } else if (this.isDeleting && this.txt === '') {
                this.isDeleting = false;
                this.loopNum++;
                delta = 500;
            }

            setTimeout(function() {
                that.tick();
            }, delta);
        };

        window.onload = function() {
            var elements = document.getElementsByClassName('txt-rotate');
            for (var i = 0; i < elements.length; i++) {
                var toRotate = elements[i].getAttribute('data-rotate');
                var period = elements[i].getAttribute('data-period');
                if (toRotate) {
                    new TxtRotate(elements[i], JSON.parse(toRotate), period);
                }
            }
            // INJECT CSS
            var css = document.createElement("style");
            css.type = "text/css";
            css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #666 }";
            document.body.appendChild(css);
        };
    </script>

    <script>
        (function($) {
            $.fn.countTo = function(options) {
                options = options || {};

                return $(this).each(function() {
                    // set options for current element
                    var settings = $.extend({}, $.fn.countTo.defaults, {
                        from: $(this).data('from'),
                        to: $(this).data('to'),
                        speed: $(this).data('speed'),
                        refreshInterval: $(this).data('refresh-interval'),
                        decimals: $(this).data('decimals')
                    }, options);

                    // how many times to update the value, and how much to increment the value on each update
                    var loops = Math.ceil(settings.speed / settings.refreshInterval),
                        increment = (settings.to - settings.from) / loops;

                    // references & variables that will change with each update
                    var self = this,
                        $self = $(this),
                        loopCount = 0,
                        value = settings.from,
                        data = $self.data('countTo') || {};

                    $self.data('countTo', data);

                    // if an existing interval can be found, clear it first
                    if (data.interval) {
                        clearInterval(data.interval);
                    }
                    data.interval = setInterval(updateTimer, settings.refreshInterval);

                    // initialize the element with the starting value
                    render(value);

                    function updateTimer() {
                        value += increment;
                        loopCount++;

                        render(value);

                        if (typeof(settings.onUpdate) == 'function') {
                            settings.onUpdate.call(self, value);
                        }

                        if (loopCount >= loops) {
                            // remove the interval
                            $self.removeData('countTo');
                            clearInterval(data.interval);
                            value = settings.to;

                            if (typeof(settings.onComplete) == 'function') {
                                settings.onComplete.call(self, value);
                            }
                        }
                    }

                    function render(value) {
                        var formattedValue = settings.formatter.call(self, value, settings);
                        $self.html(formattedValue);
                    }
                });
            };

            $.fn.countTo.defaults = {
                from: 0, // the number the element should start at
                to: 0, // the number the element should end at
                speed: 1000, // how long it should take to count between the target numbers
                refreshInterval: 100, // how often the element should be updated
                decimals: 0, // the number of decimal places to show
                formatter: formatter, // handler for formatting the value before rendering
                onUpdate: null, // callback method for every time the element is updated
                onComplete: null // callback method for when the element finishes updating
            };

            function formatter(value, settings) {
                return value.toFixed(settings.decimals);
            }
        }(jQuery));

        jQuery(function($) {
            // custom formatting example
            $('.count-number').data('countToOptions', {
                formatter: function(value, options) {
                    return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                }
            });

            // start all the timers
            $('.timer').each(count);

            function count(options) {
                var $this = $(this);
                options = $.extend({}, options || {}, $this.data('countToOptions') || {});
                $this.countTo(options);
            }
        });
    </script>
</body>

</html>