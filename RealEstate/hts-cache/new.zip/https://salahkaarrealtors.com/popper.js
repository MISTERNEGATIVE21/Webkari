<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://salahkaarrealtors.com/xmlrpc.php" />
	<title>Page not found &#8211; salahkaarrealtors</title>
<meta name='robots' content='max-image-preview:large' />
<link rel="alternate" type="application/rss+xml" title="salahkaarrealtors &raquo; Feed" href="https://salahkaarrealtors.com/index.php/feed/" />
<link rel="alternate" type="application/rss+xml" title="salahkaarrealtors &raquo; Comments Feed" href="https://salahkaarrealtors.com/index.php/comments/feed/" />
<style type="text/css">.brave_popup{display:none}</style><script data-no-optimize="1"> var brave_popup_data = {}; var bravepop_emailValidation=false; var brave_popup_videos = {};  var brave_popup_formData = {};var brave_popup_adminUser = false; var brave_popup_pageInfo = {"type":"notfound","pageID":"","singleType":""};  var bravepop_emailSuggestions={};</script><script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/salahkaarrealtors.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.4"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://salahkaarrealtors.com/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=1.6.35' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://salahkaarrealtors.com/wp-includes/css/dist/block-library/style.min.css?ver=6.5.4' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:#ffffffa6}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:#ffffffa6}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:#ffffffa6}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:#ffffffa6}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:#ffffffa6}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:#ffffffa6}.wp-block-video{margin:0 0 1em}.wp-block-template-part.has-background{margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://salahkaarrealtors.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='dae-download-css' href='https://salahkaarrealtors.com/wp-content/plugins/download-after-email/css/download.css?ver=1710674578' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://salahkaarrealtors.com/wp-includes/css/dashicons.min.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='dae-fa-css' href='https://salahkaarrealtors.com/wp-content/plugins/download-after-email/css/all.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap.cs-css' href='https://salahkaarrealtors.com/wp-content/plugins/download-pdf-after-submit-form/include/../css/formstyle.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-5-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/libs/fontawesome-5.8/css/fontawesome-5.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementinvader_addons_for_elementor-main-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/css/main.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementinvader_addons_for_elementor-widgets-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/css/widgets.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementinvader_addons_for_elementor-hover-animations-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/css/eli-hover.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='wdk-scroll-mobile-swipe-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/libs/wdkscrollmobileswipe/wdk-scroll-mobile-swipe.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementinvader-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader/public/css/elementinvader-public.css?ver=1.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='pafe-extension-style-free-css' href='https://salahkaarrealtors.com/wp-content/plugins/piotnet-addons-for-elementor/assets/css/minify/extension.min.css?ver=2.4.29' type='text/css' media='all' />
<link rel='stylesheet' id='rmp-menu-styles-css' href='https://salahkaarrealtors.com/wp-content/uploads/rmp-menu/css/rmp-menu.css?ver=07.17.07' type='text/css' media='all' />
<link rel='stylesheet' id='tss-css' href='https://salahkaarrealtors.com/wp-content/plugins/testimonial-slider-and-showcase/assets/css/wptestimonial.css?ver=2.3.10' type='text/css' media='all' />
<link rel='stylesheet' id='wpdirectorykit-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/css/wpdirectorykit-public.css?ver=1.3.0' type='text/css' media='all' />
<style id='wpdirectorykit-inline-css' type='text/css'>
.wdk-image:not(.media):not(.jsplaceholder){background-image: url(https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/img/placeholder.jpg);background-size: cover;background-position: center; }
</style>
<link rel='stylesheet' id='wpdirectorykit-responsive-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/css/wpdirectorykit-public-responsive.css?ver=1.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='wpdirectorykit-conflicts-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/css/wpdirectorykit-public-conflicts.css?ver=1.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://salahkaarrealtors.com/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=1.6.35' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.29.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.21.8' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://salahkaarrealtors.com/wp-content/plugins/testimonial-slider-and-showcase/assets/vendor/swiper/swiper.min.css?ver=2.3.10' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-5-css' href='https://salahkaarrealtors.com/wp-content/uploads/elementor/css/post-5.css?ver=1717596198' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://salahkaarrealtors.com/wp-content/uploads/elementor/css/global.css?ver=1717596199' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4328-css' href='https://salahkaarrealtors.com/wp-content/uploads/elementor/css/post-4328.css?ver=1717596200' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4359-css' href='https://salahkaarrealtors.com/wp-content/uploads/elementor/css/post-4359.css?ver=1717596200' type='text/css' media='all' />
<link rel='stylesheet' id='wpsms-front-css' href='https://salahkaarrealtors.com/wp-content/plugins/wp-sms/assets/css/front-styles.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='layers-parent-style-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/style.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='slick-theme-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/slick/slick-theme.css?ver=1.8' type='text/css' media='all' />
<link rel='stylesheet' id='slimselect-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/libs/slim-select/slimselect.min.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='nexproperty-animate-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/css/animate.css?ver=3.5.2' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/libs/bootstrap-4.5.3/css/bootstrap.min.css?ver=4.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='nexproperty-winter-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/css/winter.css?ver=1.2.0' type='text/css' media='all' />
<style id='nexproperty-winter-inline-css' type='text/css'>

		body #wpadminbar {
			position: fixed;
		}
	
</style>
<link rel='stylesheet' id='google-fonts-css' href='https://salahkaarrealtors.com/wp-content/fonts/4c7e235cbf8cf8012b5e2b9431958594.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='next-property-style-css' href='https://salahkaarrealtors.com/wp-content/themes/real-estate-golden/style.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='nexproperty-responsive-css' href='https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/css/responsive.css?ver=1.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='rt-team-css-css' href='https://salahkaarrealtors.com/wp-content/plugins/tlp-team/assets/css/tlpteam.css?ver=4.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='tlp-el-team-css-css' href='https://salahkaarrealtors.com/wp-content/plugins/tlp-team/assets/css/tlp-el-team.min.css?ver=4.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='qlwapp-css' href='https://salahkaarrealtors.com/wp-content/plugins/wp-whatsapp-chat/build/frontend/css/style.css?ver=7.3.9' type='text/css' media='all' />
<link rel='stylesheet' id='cf7cf-style-css' href='https://salahkaarrealtors.com/wp-content/plugins/cf7-conditional-fields/style.css?ver=2.4.12' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Montserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-regular-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><!--n2css--><script type="text/javascript" src="https://salahkaarrealtors.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/wdk-scroll-mobile-swipe.js?ver=1.1" id="wdk-scroll-mobile-swipe-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementinvader/public/js/elementinvader-public.js?ver=1.2.3" id="elementinvader-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/piotnet-addons-for-elementor/assets/js/minify/extension.min.js?ver=2.4.29" id="pafe-extension-free-js"></script>
<script type="text/javascript" id="wpdirectorykit-js-extra">
/* <![CDATA[ */
var script_parameters = {"ajax_url":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php","format_date":"MMMM D, YYYY","format_datetime":"MMMM D, YYYY h:mm a","format_date_js":"MM d, yy","format_datetime_js":"MM d, yy  ","settings_wdk_field_search_suggestion_disable":"0"};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/wpdirectorykit-public.js?ver=1.3.0" id="wpdirectorykit-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/real-estate-golden/assets/js/theme.js?ver=6.5.4" id="real-estate-golden-custom-js"></script>
<script type="text/javascript" id="wdk-dependfields-search-js-extra">
/* <![CDATA[ */
var script_dependfields_search = {"ajax_url":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php","hidden_fields":[]};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/wdk-dependfields-search.js?ver=6.5.4" id="wdk-dependfields-search-js"></script>
<link rel="https://api.w.org/" href="https://salahkaarrealtors.com/index.php/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://salahkaarrealtors.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.4" />
<meta name="cdp-version" content="1.4.6" />		<script>
			( function() {
				window.onpageshow = function( event ) {
					// Defined window.wpforms means that a form exists on a page.
					// If so and back/forward button has been clicked,
					// force reload a page to prevent the submit button state stuck.
					if ( typeof window.wpforms !== 'undefined' && event.persisted ) {
						window.location.reload();
					}
				};
			}() );
		</script>
		<meta name="generator" content="Elementor 3.21.8; features: e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
<link rel="icon" href="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-120x120.png" sizes="32x32" />
<link rel="icon" href="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-300x300.png" />
<meta name="msapplication-TileImage" content="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-300x300.png" />
			<style>
				:root {
				--qlwapp-scheme-font-family:inherit;--qlwapp-scheme-font-size:14px;--qlwapp-scheme-icon-size:60px;--qlwapp-scheme-icon-font-size:24px;--qlwapp-scheme-brand:#25d366;--qlwapp-scheme-text:#f4f8f6;--qlwapp-button-animation-name:none;				}
			</style>
			</head>

<body class="error404 wp-custom-logo wp-embed-responsive class-name ehf-header ehf-footer ehf-template-nexproperty ehf-stylesheet-real-estate-golden elementor-default elementor-kit-5">
<div id="page" class="hfeed site">

		<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
			<p class="main-title bhf-hidden" itemprop="headline"><a href="https://salahkaarrealtors.com" title="salahkaarrealtors" rel="home">salahkaarrealtors</a></p>
					<div data-elementor-type="wp-post" data-elementor-id="4328" class="elementor elementor-4328">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-9131795 elementor-hidden-tablet elementor-hidden-mobile elementor-hidden-desktop elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9131795" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-be02470" data-id="be02470" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-597d353 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="597d353" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-487cb88" data-id="487cb88" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-cbe9e0b e-grid-align-left elementor-shape-circle elementor-widget__width-initial elementor-grid-0 elementor-invisible elementor-widget elementor-widget-social-icons" data-id="cbe9e0b" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container{line-height:1;font-size:0}.elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid{display:inline-grid}.elementor-widget-social-icons .elementor-grid{grid-column-gap:var(--grid-column-gap,5px);grid-row-gap:var(--grid-row-gap,5px);grid-template-columns:var(--grid-template-columns);justify-content:var(--justify-content,center);justify-items:var(--justify-content,center)}.elementor-icon.elementor-social-icon{font-size:var(--icon-size,25px);line-height:var(--icon-size,25px);width:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em));height:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em))}.elementor-social-icon{--e-social-icon-icon-color:#fff;display:inline-flex;background-color:#69727d;align-items:center;justify-content:center;text-align:center;cursor:pointer}.elementor-social-icon i{color:var(--e-social-icon-icon-color)}.elementor-social-icon svg{fill:var(--e-social-icon-icon-color)}.elementor-social-icon:last-child{margin:0}.elementor-social-icon:hover{opacity:.9;color:#fff}.elementor-social-icon-android{background-color:#a4c639}.elementor-social-icon-apple{background-color:#999}.elementor-social-icon-behance{background-color:#1769ff}.elementor-social-icon-bitbucket{background-color:#205081}.elementor-social-icon-codepen{background-color:#000}.elementor-social-icon-delicious{background-color:#39f}.elementor-social-icon-deviantart{background-color:#05cc47}.elementor-social-icon-digg{background-color:#005be2}.elementor-social-icon-dribbble{background-color:#ea4c89}.elementor-social-icon-elementor{background-color:#d30c5c}.elementor-social-icon-envelope{background-color:#ea4335}.elementor-social-icon-facebook,.elementor-social-icon-facebook-f{background-color:#3b5998}.elementor-social-icon-flickr{background-color:#0063dc}.elementor-social-icon-foursquare{background-color:#2d5be3}.elementor-social-icon-free-code-camp,.elementor-social-icon-freecodecamp{background-color:#006400}.elementor-social-icon-github{background-color:#333}.elementor-social-icon-gitlab{background-color:#e24329}.elementor-social-icon-globe{background-color:#69727d}.elementor-social-icon-google-plus,.elementor-social-icon-google-plus-g{background-color:#dd4b39}.elementor-social-icon-houzz{background-color:#7ac142}.elementor-social-icon-instagram{background-color:#262626}.elementor-social-icon-jsfiddle{background-color:#487aa2}.elementor-social-icon-link{background-color:#818a91}.elementor-social-icon-linkedin,.elementor-social-icon-linkedin-in{background-color:#0077b5}.elementor-social-icon-medium{background-color:#00ab6b}.elementor-social-icon-meetup{background-color:#ec1c40}.elementor-social-icon-mixcloud{background-color:#273a4b}.elementor-social-icon-odnoklassniki{background-color:#f4731c}.elementor-social-icon-pinterest{background-color:#bd081c}.elementor-social-icon-product-hunt{background-color:#da552f}.elementor-social-icon-reddit{background-color:#ff4500}.elementor-social-icon-rss{background-color:#f26522}.elementor-social-icon-shopping-cart{background-color:#4caf50}.elementor-social-icon-skype{background-color:#00aff0}.elementor-social-icon-slideshare{background-color:#0077b5}.elementor-social-icon-snapchat{background-color:#fffc00}.elementor-social-icon-soundcloud{background-color:#f80}.elementor-social-icon-spotify{background-color:#2ebd59}.elementor-social-icon-stack-overflow{background-color:#fe7a15}.elementor-social-icon-steam{background-color:#00adee}.elementor-social-icon-stumbleupon{background-color:#eb4924}.elementor-social-icon-telegram{background-color:#2ca5e0}.elementor-social-icon-threads{background-color:#000}.elementor-social-icon-thumb-tack{background-color:#1aa1d8}.elementor-social-icon-tripadvisor{background-color:#589442}.elementor-social-icon-tumblr{background-color:#35465c}.elementor-social-icon-twitch{background-color:#6441a5}.elementor-social-icon-twitter{background-color:#1da1f2}.elementor-social-icon-viber{background-color:#665cac}.elementor-social-icon-vimeo{background-color:#1ab7ea}.elementor-social-icon-vk{background-color:#45668e}.elementor-social-icon-weibo{background-color:#dd2430}.elementor-social-icon-weixin{background-color:#31a918}.elementor-social-icon-whatsapp{background-color:#25d366}.elementor-social-icon-wordpress{background-color:#21759b}.elementor-social-icon-x-twitter{background-color:#000}.elementor-social-icon-xing{background-color:#026466}.elementor-social-icon-yelp{background-color:#af0606}.elementor-social-icon-youtube{background-color:#cd201f}.elementor-social-icon-500px{background-color:#0099e5}.elementor-shape-rounded .elementor-icon.elementor-social-icon{border-radius:10%}.elementor-shape-circle .elementor-icon.elementor-social-icon{border-radius:50%}</style>		<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-ceec562" href="https://www.facebook.com/salahkaarR/" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-41e79b4" href="https://www.instagram.com/salahkaar.realtors/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-fe6f301" href="https://www.youtube.com/@SalahkaarRealtors" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-3c098c3" href="https://in.linkedin.com/company/salahkaar-realtors?trk=public_jobs_sub-nav-cta-optional-url" target="_blank">
						<span class="elementor-screen-only">Linkedin</span>
						<i class="fab fa-linkedin"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-376f9d8" href="https://twitter.com/SalahkaarR" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-99f8a85" data-id="99f8a85" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-7fbafc3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="7fbafc3" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-957500e" data-id="957500e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-8f3588a elementor-widget__width-initial elementor-widget elementor-widget-text-editor" data-id="8f3588a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#69727d;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#69727d;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<p><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:info@salahkaarrealtors.com">info@salahkaarrealtors.com</a>    |     <i class="fa fa-mobile" aria-hidden="true"></i> <a href="tel:+9170090960">+91- 70 09 09 60 60</a></p>						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-62577af elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="62577af" data-element_type="section">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-56a61a7" data-id="56a61a7" data-element_type="column">
			<div class="elementor-widget-wrap">
							</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-761c21a" data-id="761c21a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-2d504a5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2d504a5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5608f3c" data-id="5608f3c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4e4a631 elementor-shape-circle elementor-grid-mobile-0 e-grid-align-tablet-left e-grid-align-mobile-left elementor-widget-tablet__width-initial elementor-widget-mobile__width-initial elementor-widget__width-initial elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="4e4a631" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-5e26feb" href="https://www.facebook.com/salahkaarR" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-f820cb8" href="https://www.instagram.com/salahkaar.realtors/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-7193c23" href="https://www.youtube.com/@SalahkaarRealtors" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-899f99a" target="_blank">
						<span class="elementor-screen-only">Linkedin</span>
						<i class="fab fa-linkedin"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-33e5344" href="https://twitter.com/SalahkaarR" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ac7b83b" data-id="ac7b83b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e3e512f elementor-widget-mobile__width-initial elementor-widget elementor-widget-text-editor" data-id="e3e512f" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p><a href="mailto:info@salahkaarrealtors.com"><span class="x19la9d6 x1fc57z9 x6ikm8r x10wlt62 x19co3pv x1g5zs5t xfibh0p xiy17q3 x1xsqp64 x1lkfr7t xexx8yu x4uap5 x18d9i69 xkhd6sd"><span class="xrtxmta x1bhl96m">📩 </span></span>info@salahkaarrealtors.com</a> | <span class="x19la9d6 x1fc57z9 x6ikm8r x10wlt62 x19co3pv x1g5zs5t xfibh0p xiy17q3 x1xsqp64 x1lkfr7t xexx8yu x4uap5 x18d9i69 xkhd6sd"><span class="xrtxmta x1bhl96m">📱 </span></span><a href="tel:+91 70 09 09 60 60">+91-7009096060</a></p>						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-7e98dad elementor-section-height-min-height elementor-section-items-top elementor-hidden-tablet elementor-section-boxed elementor-section-height-default" data-id="7e98dad" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-bdd7b13" data-id="bdd7b13" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-38ab07f e-transform elementor-widget__width-initial elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-eli-logo" data-id="38ab07f" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-12,&quot;sizes&quot;:[]},&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_translateX_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="eli-logo.default">
				<div class="elementor-widget-container">
			<div class="widget-eli eli-logo" id="eli_59420799">
    <div class="eli_container">
                    <a href="https://salahkaarrealtors.com/"  class="custom-logo-link">
                <img src="https://salahkaarrealtors.com/wp-content/uploads/2023/03/1-Salahkaar_logo-removebg-preview.png" alt="salahkaarrealtors">
            </a>
            </div>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-a6d9885 elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-absolute elementor-hidden-desktop elementor-hidden-tablet elementor-widget elementor-widget-image" data-id="a6d9885" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>											<a href="https://salahkaarrealtors.com/">
							<img width="150" height="150" src="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-150x150.png" class="attachment-thumbnail size-thumbnail wp-image-5957" alt="" srcset="https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-150x150.png 150w, https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-300x300.png 300w, https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3-120x120.png 120w, https://salahkaarrealtors.com/wp-content/uploads/2024/05/Salahkaar-logo-3.png 400w" sizes="(max-width: 150px) 100vw, 150px" />								</a>
													</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-193b6d3" data-id="193b6d3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-ba1d833 elementor-widget-mobile__width-auto elementor-widget-tablet__width-auto wl-nav-menu--indicator-angle wl-nav-menu--dropdown-mobile elementor-widget__width-initial elementor-absolute elementor-hidden-tablet elementor-hidden-mobile wl-nav-menu__text-align-aside wl-nav-menu--toggle wl-nav-menu--burger elementor-widget elementor-widget-eli-menu" data-id="ba1d833" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="eli-menu.default">
				<div class="elementor-widget-container">
			
        <div class="widget-eli elementinvader-addons-for-elementor eli-menu elementor-clickable" id="eli_195156019">
    <div class="eli-container">
        <div class="wl_nav_mask"></div>
                    <nav role="navigation" class="wl-nav-menu--main wl-nav-menu__container wl-nav-menu--layout-horizontal"><div class="menu-menu-1-container"><ul id="menu-1-ba1d833" class="wl-nav-menu wl-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-164"><a href="https://salahkaarrealtors.com/" class="wl-item">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2807"><a href="https://salahkaarrealtors.com/index.php/about-us/" class="wl-item">About us</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4351"><a href="https://salahkaarrealtors.com/index.php/vision/" class="wl-sub-item">Vision</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4352"><a href="https://salahkaarrealtors.com/index.php/mission-3/" class="wl-sub-item">Mission</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4104"><a href="https://salahkaarrealtors.com/index.php/who-we-are/" class="wl-sub-item">Who we are</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2622"><a href="#" class="wl-item wl-item-anchor">Projects</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4204"><a href="https://salahkaarrealtors.com/index.php/commercial/" class="wl-sub-item">Commercial</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4007"><a href="https://salahkaarrealtors.com/index.php/residential/" class="wl-sub-item">Residential</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6431"><a href="https://salahkaarrealtors.com/index.php/contact/" class="wl-item">Contact Form</a></li>
</ul></div></nav>
                    <div class="wl-menu-toggle" role="button" aria-label="Menu Toggle" aria-expanded="false">
            <i aria-hidden="true" class="fas fa-bars"></i>                    </div>
        <nav class="wl-nav-menu--dropdown wl-nav-menu__container" role="navigation" aria-hidden="true">
            <a href="#" class="wl_close-menu">
                <span class="bar1"></span>
                <span class="bar3"></span>
            </a>
            <div class="menu-menu-1-container"><ul id="menu-1-ba1d833" class="wl-nav-menu wl-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-164"><a href="https://salahkaarrealtors.com/" class="wl-item">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2807"><a href="https://salahkaarrealtors.com/index.php/about-us/" class="wl-item">About us</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4351"><a href="https://salahkaarrealtors.com/index.php/vision/" class="wl-sub-item">Vision</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4352"><a href="https://salahkaarrealtors.com/index.php/mission-3/" class="wl-sub-item">Mission</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4104"><a href="https://salahkaarrealtors.com/index.php/who-we-are/" class="wl-sub-item">Who we are</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2622"><a href="#" class="wl-item wl-item-anchor">Projects</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4204"><a href="https://salahkaarrealtors.com/index.php/commercial/" class="wl-sub-item">Commercial</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4007"><a href="https://salahkaarrealtors.com/index.php/residential/" class="wl-sub-item">Residential</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6431"><a href="https://salahkaarrealtors.com/index.php/contact/" class="wl-item">Contact Form</a></li>
</ul></div>        </nav>
    </div>
    
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-a395f8b wl-nav-menu--dropdown-mobile wl-nav-menu__text-align-center elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-absolute elementor-hidden-desktop elementor-hidden-tablet wl-nav-menu--indicator-classic wl-nav-menu--toggle wl-nav-menu--burger elementor-widget elementor-widget-eli-menu" data-id="a395f8b" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="eli-menu.default">
				<div class="elementor-widget-container">
			
        <div class="widget-eli elementinvader-addons-for-elementor eli-menu elementor-clickable" id="eli_171532171">
    <div class="eli-container">
        <div class="wl_nav_mask"></div>
                    <nav role="navigation" class="wl-nav-menu--main wl-nav-menu__container wl-nav-menu--layout-horizontal"><div class="menu-menu-1-container"><ul id="menu-1-a395f8b" class="wl-nav-menu wl-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-164"><a href="https://salahkaarrealtors.com/" class="wl-item">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2807"><a href="https://salahkaarrealtors.com/index.php/about-us/" class="wl-item">About us</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4351"><a href="https://salahkaarrealtors.com/index.php/vision/" class="wl-sub-item">Vision</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4352"><a href="https://salahkaarrealtors.com/index.php/mission-3/" class="wl-sub-item">Mission</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4104"><a href="https://salahkaarrealtors.com/index.php/who-we-are/" class="wl-sub-item">Who we are</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2622"><a href="#" class="wl-item wl-item-anchor">Projects</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4204"><a href="https://salahkaarrealtors.com/index.php/commercial/" class="wl-sub-item">Commercial</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4007"><a href="https://salahkaarrealtors.com/index.php/residential/" class="wl-sub-item">Residential</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6431"><a href="https://salahkaarrealtors.com/index.php/contact/" class="wl-item">Contact Form</a></li>
</ul></div></nav>
                    <div class="wl-menu-toggle" role="button" aria-label="Menu Toggle" aria-expanded="false">
            <i aria-hidden="true" class="eicon-menu-bar"></i>                    </div>
        <nav class="wl-nav-menu--dropdown wl-nav-menu__container" role="navigation" aria-hidden="true">
            <a href="#" class="wl_close-menu">
                <span class="bar1"></span>
                <span class="bar3"></span>
            </a>
            <div class="menu-menu-1-container"><ul id="menu-1-a395f8b" class="wl-nav-menu wl-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-164"><a href="https://salahkaarrealtors.com/" class="wl-item">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2807"><a href="https://salahkaarrealtors.com/index.php/about-us/" class="wl-item">About us</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4351"><a href="https://salahkaarrealtors.com/index.php/vision/" class="wl-sub-item">Vision</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4352"><a href="https://salahkaarrealtors.com/index.php/mission-3/" class="wl-sub-item">Mission</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4104"><a href="https://salahkaarrealtors.com/index.php/who-we-are/" class="wl-sub-item">Who we are</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2622"><a href="#" class="wl-item wl-item-anchor">Projects</a>
<ul class="sub-menu wl-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4204"><a href="https://salahkaarrealtors.com/index.php/commercial/" class="wl-sub-item">Commercial</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4007"><a href="https://salahkaarrealtors.com/index.php/residential/" class="wl-sub-item">Residential</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6431"><a href="https://salahkaarrealtors.com/index.php/contact/" class="wl-item">Contact Form</a></li>
</ul></div>        </nav>
    </div>
    
</div>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
				</header>

				<section class="blog-standart">
			<h1 class="blog-hd">Blog</h1>
		</section><!--blog-standart end-->
	
		<section class="main-content" id="content">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 col-md-12 col-sm-12 col-12">
						<div class="blog-items">
							<div class="blog-item post-837 post type-post status-publish format-standard has-post-thumbnail hentry category-island">
			<div class="blog-thumbnail">
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/" title="Your Glasses Seasonal Update">
				<img fetchpriority="high" width="788" height="557" src="https://salahkaarrealtors.com/wp-content/uploads/2021/07/news-5-770x483-1.jpg" class="attachment-nexproperty-post-thumbnail-nocrop size-nexproperty-post-thumbnail-nocrop wp-post-image" alt="" decoding="async" />			</a>
			    
			<span class="category-name">Island</span>
		</div><!--blog-thumbnail end-->
		<div class="blog-info">
					<ul class="meta">
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/" title="Post Date">March 18, 2023</a>
					</li>
									<li class="posted-by">
						<span>by</span><a href="https://salahkaarrealtors.com/index.php/author/digicept-1social/" title="Post Author">Salahkaar</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/#respond" title="Number of comments">No Comments</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/category/island/" rel="category tag">Island</a>					</li>
							</ul><!--meta end-->
													<h3 class="blog-title">
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/" title="Your Glasses Seasonal Update">
						Your Glasses Seasonal Update					</a>
				</h3>
			      
		      
		<div class="blog-body">
														
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat nec purus eget porta. Aliquam ebendum erat. Donec dui eros, tincidunt at felis non, tristique aliquet ex. Aenean luctus, orci condimentum cursus, quam lorem vulputate ligula, ac pretium risus metus non est. Cras rutrum dolor in tortor ultrices, ullamcorper finibus magna sollicitudin. Vivamus sed massa sit amet diam porta dignissim at in lorem. In facilisis quis erat at tempus. Aliquam semper diam mollis mollis. Mauris dictum, ante ac interdum.</p>



<p>Astibulum, nibh ipsum condimentum felis, quis luctus nisi nisl sed orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempus puet rutrum ultrces. Cras pretium pretium odio aliquam tortor interduma. Morbi commodo egestas mauris, et porttitor ipsum iaculis fermentum. Phasellus ante nibh, posuere gravida odio mattis cursus</p>
												                </div>

	</div><!--blog-info end-->
</div><!--blog-item end-->
<div class="blog-item post-836 post type-post status-publish format-standard has-post-thumbnail hentry category-travel">
			<div class="blog-thumbnail">
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/" title="The Effortless Australian Label">
				<img width="836" height="557" src="https://salahkaarrealtors.com/wp-content/uploads/2021/07/news-4-770x483-1.jpg" class="attachment-nexproperty-post-thumbnail-nocrop size-nexproperty-post-thumbnail-nocrop wp-post-image" alt="" decoding="async" />			</a>
			    
			<span class="category-name">Travel</span>
		</div><!--blog-thumbnail end-->
		<div class="blog-info">
					<ul class="meta">
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/" title="Post Date">March 18, 2023</a>
					</li>
									<li class="posted-by">
						<span>by</span><a href="https://salahkaarrealtors.com/index.php/author/digicept-1social/" title="Post Author">Salahkaar</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/#respond" title="Number of comments">No Comments</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/category/travel/" rel="category tag">Travel</a>					</li>
							</ul><!--meta end-->
													<h3 class="blog-title">
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/" title="The Effortless Australian Label">
						The Effortless Australian Label					</a>
				</h3>
			      
		      
		<div class="blog-body">
														
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat nec purus eget porta. Aliquam ebendum erat. Donec dui eros, tincidunt at felis non, tristique aliquet ex. Aenean luctus, orci condimentum cursus, quam lorem vulputate ligula, ac pretium risus metus non est. Cras rutrum dolor in tortor ultrices, ullamcorper finibus magna sollicitudin. Vivamus sed massa sit amet diam porta dignissim at in lorem. In facilisis quis erat at tempus. Aliquam semper diam mollis mollis. Mauris dictum, ante ac interdum.</p>



<p>Astibulum, nibh ipsum condimentum felis, quis luctus nisi nisl sed orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempus puet rutrum ultrces. Cras pretium pretium odio aliquam tortor interduma. Morbi commodo egestas mauris, et porttitor ipsum iaculis fermentum. Phasellus ante nibh, posuere gravida odio mattis cursus.</p>
												                </div>

	</div><!--blog-info end-->
</div><!--blog-item end-->
<div class="blog-item post-835 post type-post status-publish format-standard has-post-thumbnail hentry category-travel">
			<div class="blog-thumbnail">
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/" title="When it all Just Works">
				<img width="841" height="557" src="https://salahkaarrealtors.com/wp-content/uploads/2021/07/news-3-770x483-1.jpg" class="attachment-nexproperty-post-thumbnail-nocrop size-nexproperty-post-thumbnail-nocrop wp-post-image" alt="" decoding="async" />			</a>
			    
			<span class="category-name">Travel</span>
		</div><!--blog-thumbnail end-->
		<div class="blog-info">
					<ul class="meta">
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/" title="Post Date">March 18, 2023</a>
					</li>
									<li class="posted-by">
						<span>by</span><a href="https://salahkaarrealtors.com/index.php/author/digicept-1social/" title="Post Author">Salahkaar</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/#respond" title="Number of comments">No Comments</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/category/travel/" rel="category tag">Travel</a>					</li>
							</ul><!--meta end-->
													<h3 class="blog-title">
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/" title="When it all Just Works">
						When it all Just Works					</a>
				</h3>
			      
		      
		<div class="blog-body">
														
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat nec purus eget porta. Aliquam ebendum erat. Donec dui eros, tincidunt at felis non, tristique aliquet ex. Aenean luctus, orci condimentum cursus, quam lorem vulputate ligula, ac pretium risus metus non est. Cras rutrum dolor in tortor ultrices, ullamcorper finibus magna sollicitudin. Vivamus sed massa sit amet diam porta dignissim at in lorem. In facilisis quis erat at tempus. Aliquam semper diam mollis mollis. Mauris dictum, ante ac interdum.</p>



<p>Astibulum, nibh ipsum condimentum felis, quis luctus nisi nisl sed orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempus puet rutrum ultrces. Cras pretium pretium odio aliquam tortor interduma. Morbi commodo egestas mauris, et porttitor ipsum iaculis fermentum. Phasellus ante nibh, posuere gravida odio mattis cursus.</p>
												                </div>

	</div><!--blog-info end-->
</div><!--blog-item end-->
<div class="blog-item post-834 post type-post status-publish format-standard has-post-thumbnail hentry category-travel">
			<div class="blog-thumbnail">
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/" title="How To Get Lips Lipstick Ready">
				<img width="841" height="557" src="https://salahkaarrealtors.com/wp-content/uploads/2021/07/news-2-770x483-1.jpg" class="attachment-nexproperty-post-thumbnail-nocrop size-nexproperty-post-thumbnail-nocrop wp-post-image" alt="" decoding="async" />			</a>
			    
			<span class="category-name">Travel</span>
		</div><!--blog-thumbnail end-->
		<div class="blog-info">
					<ul class="meta">
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/" title="Post Date">March 18, 2023</a>
					</li>
									<li class="posted-by">
						<span>by</span><a href="https://salahkaarrealtors.com/index.php/author/digicept-1social/" title="Post Author">Salahkaar</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/#respond" title="Number of comments">No Comments</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/category/travel/" rel="category tag">Travel</a>					</li>
							</ul><!--meta end-->
													<h3 class="blog-title">
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/" title="How To Get Lips Lipstick Ready">
						How To Get Lips Lipstick Ready					</a>
				</h3>
			      
		      
		<div class="blog-body">
														
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat nec purus eget porta. Aliquam ebendum erat. Donec dui eros, tincidunt at felis non, tristique aliquet ex. Aenean luctus, orci condimentum cursus, quam lorem vulputate ligula, ac pretium risus metus non est. Cras rutrum dolor in tortor ultrices, ullamcorper finibus magna sollicitudin. Vivamus sed massa sit amet diam porta dignissim at in lorem. In facilisis quis erat at tempus. Aliquam semper diam mollis mollis. Mauris dictum, ante ac interdum.</p>



<p>Astibulum, nibh ipsum condimentum felis, quis luctus nisi nisl sed orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempus puet rutrum ultrces. Cras pretium pretium odio aliquam tortor interduma. Morbi commodo egestas mauris, et porttitor ipsum iaculis fermentum. Phasellus ante nibh, posuere gravida odio mattis cursus</p>
												                </div>

	</div><!--blog-info end-->
</div><!--blog-item end-->
<div class="blog-item post-826 post type-post status-publish format-standard has-post-thumbnail hentry category-island">
			<div class="blog-thumbnail">
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/" title="Featured Property">
				<img width="829" height="557" src="https://salahkaarrealtors.com/wp-content/uploads/2021/07/news-6-770x483-1.jpg" class="attachment-nexproperty-post-thumbnail-nocrop size-nexproperty-post-thumbnail-nocrop wp-post-image" alt="" decoding="async" />			</a>
			    
			<span class="category-name">Island</span>
		</div><!--blog-thumbnail end-->
		<div class="blog-info">
					<ul class="meta">
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/" title="Post Date">March 18, 2023</a>
					</li>
									<li class="posted-by">
						<span>by</span><a href="https://salahkaarrealtors.com/index.php/author/digicept-1social/" title="Post Author">Salahkaar</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/#respond" title="Number of comments">No Comments</a>
					</li>
									<li>
						<a href="https://salahkaarrealtors.com/index.php/category/island/" rel="category tag">Island</a>					</li>
							</ul><!--meta end-->
													<h3 class="blog-title">
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/" title="Featured Property">
						Featured Property					</a>
				</h3>
			      
		      
		<div class="blog-body">
														
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat nec purus eget porta. Aliquam ebendum erat. Donec dui eros, tincidunt at felis non, tristique aliquet ex. Aenean luctus, orci condimentum cursus, quam lorem vulputate ligula, ac pretium risus metus non est. Cras rutrum dolor in tortor ultrices, ullamcorper finibus magna sollicitudin. Vivamus sed massa sit amet diam porta dignissim at in lorem. In facilisis quis erat at tempus. Aliquam semper diam mollis mollis. Mauris dictum, ante ac interdum.</p>



<p>Astibulum, nibh ipsum condimentum felis, quis luctus nisi nisl sed orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempus puet rutrum ultrces. Cras pretium pretium odio aliquam tortor interduma. Morbi commodo egestas mauris, et porttitor ipsum iaculis fermentum. Phasellus ante nibh, posuere gravida odio mattis cursus.</p>
												                </div>

	</div><!--blog-info end-->
</div><!--blog-item end-->
						</div><!--featur-prop-sec end-->
					</div>
												<div class="col-lg-3 col-md-12 col-sm-12 col-12">
								<div class="sidebar">
									<div id="search-1" class="widget widget_search"><form role="search"  method="get" class="search-form" action="https://salahkaarrealtors.com/">
	<input type="search" id="search-form-1" class="search-field" value="" placeholder="Search..." name="s" />
	<button type="submit" class="search-submit">Search</button>
</form>
</div>
		<div id="recent-posts-1" class="widget widget_recent_entries">
		<h1 class="widget-title">Recent Posts</h1>
		<ul>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/">Your Glasses Seasonal Update</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/">The Effortless Australian Label</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/">When it all Just Works</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/">How To Get Lips Lipstick Ready</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/">Featured Property</a>
									</li>
					</ul>

		</div><div id="categories-1" class="widget widget_categories"><h1 class="widget-title">Categories</h1>
			<ul>
					<li class="cat-item cat-item-2"><a href="https://salahkaarrealtors.com/index.php/category/island/">Island</a>
</li>
	<li class="cat-item cat-item-3"><a href="https://salahkaarrealtors.com/index.php/category/travel/">Travel</a>
</li>
			</ul>

			</div><div id="search-2" class="widget widget_search"><form role="search"  method="get" class="search-form" action="https://salahkaarrealtors.com/">
	<input type="search" id="search-form-2" class="search-field" value="" placeholder="Search..." name="s" />
	<button type="submit" class="search-submit">Search</button>
</form>
</div>
		<div id="recent-posts-2" class="widget widget_recent_entries">
		<h1 class="widget-title">Recent Posts</h1>
		<ul>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/">Your Glasses Seasonal Update</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/">The Effortless Australian Label</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/">When it all Just Works</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/">How To Get Lips Lipstick Ready</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/">Featured Property</a>
									</li>
					</ul>

		</div><div id="categories-2" class="widget widget_categories"><h1 class="widget-title">Categories</h1>
			<ul>
					<li class="cat-item cat-item-2"><a href="https://salahkaarrealtors.com/index.php/category/island/">Island</a>
</li>
	<li class="cat-item cat-item-3"><a href="https://salahkaarrealtors.com/index.php/category/travel/">Travel</a>
</li>
			</ul>

			</div><div id="text-1" class="widget widget_text"><h1 class="widget-title">Popular Properties</h1>			<div class="textwidget"><div class="wdk-shortcode wdk-element " id="wdk_el_">
    <div class="wdk-listings-list">
        <div class="wdk-row">
                                                                    <div class="wdk-col">
                        <div class="listing-item">
                            <div class="listing-img-sec">
                                <a href="https://salahkaarrealtors.com/index.php/wdk-listing/primrose-house/" title="Primrose House">
                                    <img src="https://salahkaarrealtors.com/wp-content/uploads/2023/03/real-estate-22.jpg" alt="Primrose House">
                                </a>
                            </div><!--prop-img-sec enf-->
                            <div class="listing-inf-sec">
                                                                    <h3 class="title">
                                        <a href="https://salahkaarrealtors.com/index.php/wdk-listing/primrose-house/">
                                                                                            <span>
                                                    Primrose House                                                </span> 
                                                                                    </a>
                                    </h3>
                                                                                                    <div class="price">
                                                                                <span>
                                            $                                                                                            35,000                                                                                                                                </span> 
                                                                            </div>
                                                            </div><!--prop-inf-sec enf-->
                        </div>
                    </div>
                                                        <div class="wdk-col">
                        <div class="listing-item">
                            <div class="listing-img-sec">
                                <a href="https://salahkaarrealtors.com/index.php/wdk-listing/kingston-house/" title="GYMNASIUM">
                                    <img src="https://salahkaarrealtors.com/wp-content/uploads/2023/03/image-046.jpg" alt="GYMNASIUM">
                                </a>
                            </div><!--prop-img-sec enf-->
                            <div class="listing-inf-sec">
                                                                    <h3 class="title">
                                        <a href="https://salahkaarrealtors.com/index.php/wdk-listing/kingston-house/">
                                                                                            <span>
                                                    GYMNASIUM                                                </span> 
                                                                                    </a>
                                    </h3>
                                                                                                    <div class="price">
                                                                                <span>
                                            $                                                                                            125,000                                                                                                                                </span> 
                                                                            </div>
                                                            </div><!--prop-inf-sec enf-->
                        </div>
                    </div>
                 
                    </div>
    </div>
</div>

</div>
		</div>
		<div id="recent-posts-3" class="widget widget_recent_entries">
		<h1 class="widget-title">Recent Posts</h1>
		<ul>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/apartment-on-nice-island/">Your Glasses Seasonal Update</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/ten-things-you-did-know-about/">The Effortless Australian Label</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/beaches-in-croatia/">When it all Just Works</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/how-much-do-you-know-about-news/">How To Get Lips Lipstick Ready</a>
									</li>
											<li>
					<a href="https://salahkaarrealtors.com/index.php/2023/03/18/five-facts-you-never-knew/">Featured Property</a>
									</li>
					</ul>

		</div><div id="text-2" class="widget widget_text"><h1 class="widget-title">Newsletter</h1>			<div class="textwidget"><div class="eli-shortcode widget-elementinvader_addons_for_elementor elementinvader_contact_form contact-form ">
    <div class="elementinvader_addons_for_elementor-container">
        <form class="elementinvader_addons_for_elementor_f">
            <div class="config" data-url="https://salahkaarrealtors.com/wp-admin/admin-ajax.php"></div>
            <input type="hidden" name="element_id" value="1">
            <input type="hidden" name="shortcode" value="1">
                                                                                            <input type="hidden" name="mail_data_subject" value="Newsletter">
                                            <input type="hidden" name="mail_data_from_email" value="salahkaargroup@gmail.com">
                                            <input type="hidden" name="mail_data_from_name" value="salahkaargroup@gmail.com">
                                            <input type="hidden" name="mail_data_to_email" value="salahkaargroup@gmail.com">
                                                                                                            <input type="hidden" name="send_action_type" value="mail_base">
                        <div class="elementinvader_addons_for_elementor_f_box_alert"></div>
            <div class="elementinvader_addons_for_elementor_f_container">
                <div class="elementinvader_addons_for_elementor_f_group email elementinvader_addons_for_elementor_f_group_el_7250807 " style="">
                    <input name="Email" id="emailemail" type="email" class="elementinvader_addons_for_elementor_f_field" required="required" value="" placeholder="Email">
                </div>               
                <div class="elementinvader_addons_for_elementor_f_group elementinvader_addons_for_elementor_f_group_el_button justify">
                    <button type="submit">
                        <span class="elementor-button-text">Subscribe</span>
                        <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking " style="display: none;"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div></div>
		</div>								</div>
							</div>
							
				</div>
			</div>
		</section><!--standert-prop end-->


		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="4359" class="elementor elementor-4359">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-d657c55 elementor-hidden-tablet elementor-hidden-mobile elementor-section-height-min-height elementor-section-items-top elementor-section-boxed elementor-section-height-default" data-id="d657c55" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-fa9a06e elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile" data-id="fa9a06e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2c7d3cb elementor-widget elementor-widget-image" data-id="2c7d3cb" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img width="640" height="549" src="https://salahkaarrealtors.com/wp-content/uploads/2024/06/page-12-1.jpg" class="attachment-large size-large wp-image-6215" alt="" srcset="https://salahkaarrealtors.com/wp-content/uploads/2024/06/page-12-1.jpg 700w, https://salahkaarrealtors.com/wp-content/uploads/2024/06/page-12-1-650x557.jpg 650w" sizes="(max-width: 640px) 100vw, 640px" />													</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c82e541 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c82e541" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-f87eeff" data-id="f87eeff" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-11ccab7 e-transform elementor-widget elementor-widget-heading" data-id="11ccab7" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-24,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default"><a href="http://[contact-form-7%20id=84671a1%20title=Contact%20Us]">Contact Us:</a></h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d4e9804 elementor-list-item-link-inline elementor-mobile-align-left elementor-align-left elementor-widget elementor-widget-icon-list" data-id="d4e9804" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">		<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="tel:+91%2070090960">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-phone-alt"></i>						</span>
										<span class="elementor-icon-list-text">+91- 70 09 09 60 60</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="mailto:info@salahkaarrealtors.com">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-envelope"></i>						</span>
										<span class="elementor-icon-list-text">info@salahkaarrealtors.com</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-738aa40 elementor-widget elementor-widget-heading" data-id="738aa40" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Follow Us:</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c0afe4c e-grid-align-left elementor-widget__width-initial elementor-shape-circle elementor-grid-0 elementor-invisible elementor-widget elementor-widget-social-icons" data-id="c0afe4c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-ceec562" href="https://www.facebook.com/salahkaarR/" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-41e79b4" href="https://www.instagram.com/salahkaar.realtors/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-848dad7" href="https://www.youtube.com/@SalahkaarRealtors" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-3c098c3" href="https://in.linkedin.com/company/salahkaar-realtors?trk=public_jobs_sub-nav-cta-optional-url" target="_blank">
						<span class="elementor-screen-only">Linkedin</span>
						<i class="fab fa-linkedin"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-376f9d8" href="https://twitter.com/SalahkaarR" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-57e1688" data-id="57e1688" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-c6aca30 elementor-widget elementor-widget-heading" data-id="c6aca30" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Address:</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-02de2a8 e-transform elementor-widget elementor-widget-text-editor" data-id="02de2a8" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-19,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Address: H-112, Sector 63, Noida, Uttar Pradesh 201301</p>						</div>
				</div>
				<div class="elementor-element elementor-element-bfb58cf elementor-invisible elementor-widget elementor-widget-wdk-button" data-id="bfb58cf" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;zoomIn&quot;}" data-widget_type="wdk-button.default">
				<div class="elementor-widget-container">
			<div class="wdk-element" id="wdk_el_bfb58cf">
    <a href="https://maps.app.goo.gl/j48Lr9ogKnyB9tUz7?g_st=iw" id="" class="wdk-element-button">
                    <i aria-hidden="true" class="fas fa-directions"></i>                Get Direction            </a>
</div>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-099e675" data-id="099e675" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-cc5caa7 e-transform elementor-widget elementor-widget-heading" data-id="cc5caa7" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-24,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Links:</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-a0328c4 elementor-mobile-align-left e-transform elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="a0328c4" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-50,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://salahkaarrealtors.com/index.php/residential/">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-right"></i>						</span>
										<span class="elementor-icon-list-text">Featured Properties</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salahkaarrealtors.com/blog/">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-right"></i>						</span>
										<span class="elementor-icon-list-text">Recent Posts</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salahkaarrealtors.com/home-alt/">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-right"></i>						</span>
										<span class="elementor-icon-list-text">Blogs</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salahkaarrealtors.com/index.php/sitemap/">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-right"></i>						</span>
										<span class="elementor-icon-list-text">Site Map</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-121d490 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="121d490" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9766a2c" data-id="9766a2c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-9c38487 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9c38487" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-033ec58" data-id="033ec58" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-eb40f6e elementor-widget elementor-widget-heading" data-id="eb40f6e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<div class="elementor-heading-title elementor-size-default">Copyright © 2023 Salahkaar Realtors</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c5dde25" data-id="c5dde25" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-bb5d1d2 elementor-widget elementor-widget-heading" data-id="bb5d1d2" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<div class="elementor-heading-title elementor-size-default"><a href="//wpdirectorykit.com" target="_blank">All Rights are Reserved </a></div>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div>		</footer>
	</div><!-- #page -->
            <div class="brave_popup brave_popup--popup" id="brave_popup_4371" data-loaded="false" >
               <!-- <p></p> -->
               <input type="hidden" id="brave_form_security-NRIz8ywHGExzcP8OZa9" name="brave_form_security-NRIz8ywHGExzcP8OZa9" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" />         <script>
            document.addEventListener("DOMContentLoaded", function(event) {


                              brave_popup_formData['-NRIz8ywHGExzcP8OZa9'] = {
                  formID: '-NRIz8ywHGExzcP8OZa9',
                  popupID: '4371',
                  stepID: '0',
                  device: 'desktop',
                  fields: '{"-NRIzXw7kqNTM1ca7wot":{"uid":"","type":"input","required":false,"validation":"text"},"-NRIz8yxbyD_fZtCIm3W":{"uid":"","type":"input","required":true,"validation":"email","conditions":{}},"-NRIzfH7IlSmu5uLUB5i":{"uid":"","type":"input","required":false,"validation":"text"}}',
                  track: 'null',
                  changesFormHeight: false,
                  heightData: [295],
                  goal: false,
                  recaptcha: false,
                  social_optin: false,
                  totalSteps: 0,
                  quiz: false,
                  quizScoring: "points",
                  totalQuestions: 0,
                  totalScore: 0,
                  totalCorrect: 0,
                  freemailAllow: false,
                  conditions: [],
                  conditionsMatch: {},
                  conditionsVals: {},
                  onSubmit: function(formData, response){  },
               }
               
            });
         </script>

      <div id="brave_popup_4371__step__0" class="brave_popup__step_wrap brave_popup__step--mobile-noContent"><div class="brave_popup__step brave_popup__step__desktop  position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-nomobilecontent="true" data-scrollock="" data-width="700" data-height="450" data-popopen="false" style="z-index:99999"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4371', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4371', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "><div id="brave_element--NRIz8ywHGExzcP8OZa6" class="brave_element brave_element--image   ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           <div class="brave_element__image_inner">
                              
                                 
                                 <img class="brave_element__image  brave_element_img_item skip-lazy no-lazyload" data-lazy="https://salahkaarrealtors.com/wp-content/uploads/2023/03/4.jpg" src="https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/images/preloader.png" alt="" />
                                 
                              
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRIz8ywHGExzcP8OZa7" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">Enquire Now!</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRIz8ywHGExzcP8OZa8" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">If you have any queries, kindly fill the form:</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRIz8ywHGExzcP8OZa9" class="brave_element brave_element--form ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           
                           <div class="brave_element__form_inner ">
                           
                              <form id="brave_form_-NRIz8ywHGExzcP8OZa9" class="brave_form_form    " method="post" data-cookies="" onsubmit="brave_submit_form(event, brave_popup_formData['-NRIz8ywHGExzcP8OZa9'] )">
                                 <div class="brave_form_overlay"></div><div class="brave_form_fields" data-step="0"><div id="brave_form_field-NRIzXw7kqNTM1ca7wot" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Full Name"  name="-NRIzXw7kqNTM1ca7wot"  class=""  /></div><div id="brave_form_field-NRIz8yxbyD_fZtCIm3W" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="email" placeholder="Email Address*"  name="-NRIz8yxbyD_fZtCIm3W"  class=""  /></div><div id="brave_form_field-NRIzfH7IlSmu5uLUB5i" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Phone"  name="-NRIzfH7IlSmu5uLUB5i"  class=""  /></div><input type="hidden" id="brave_form_security-NRIz8ywHGExzcP8OZa9" name="brave_form_security-NRIz8ywHGExzcP8OZa9" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" /></div><div class="brave_form_button  "><button id="brave_form_button--NRIz8ywHGExzcP8OZa9"><span id="brave_form_loading_-NRIz8ywHGExzcP8OZa9" class="brave_form_loading"><svg width="20px" height="20px" viewBox="0 0 6.82666 6.82666" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none">
               <g fill="rgb(255,255,255)">
               <path d="M2.46703 5.54888c0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.030374,-0.113677 -0.0371575,-0.230461 -0.150835,-0.260835 -0.466854,-0.125091 -0.838799,-0.427543 -1.06273,-0.815406 -0.223752,-0.387547 -0.299567,-0.860783 -0.174425,-1.32783 0.125091,-0.466854 0.427543,-0.838795 0.815406,-1.06273 0.387547,-0.223752 0.860783,-0.299571 1.32783,-0.174429 0.466854,0.125091 0.838795,0.427543 1.06273,0.815406 0.223752,0.387547 0.299571,0.860783 0.174429,1.32783 -0.030374,0.113677 0.0371575,0.230461 0.150835,0.260835 0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.155433,-0.580094 0.0608307,-1.16861 -0.217768,-1.65116 -0.278421,-0.482236 -0.740776,-0.85826 -1.32106,-1.01374 -0.580094,-0.155433 -1.16861,-0.0608307 -1.65116,0.217768 -0.482236,0.278421 -0.85826,0.740776 -1.01374,1.32106 -0.155433,0.580094 -0.0608346,1.16861 0.217764,1.65116 0.278421,0.482236 0.74078,0.85826 1.32106,1.01374z"/><path d="M5.895 3.43303c0.0906654,-0.0745551 0.10372,-0.2085 0.0291654,-0.299165 -0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654l-0.669823 0.551189 -0.551102 -0.669724c-0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654 -0.0906654,0.0745551 -0.10372,0.2085 -0.0291654,0.299165l0.674638 0.81985c0.00343307,0.00497244 0.00708661,0.00985039 0.0109961,0.0146024 0.0748622,0.0909764 0.209307,0.104035 0.300283,0.0291732l-0.0005 -0.000606299 0.833839 -0.686154z"/></g>
               <rect fill="transparent" height="6.82666" width="6.82666"/>
            </svg></span><span class="brave_element-icon"><svg viewBox="0 0 512 512" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z" fill="rgb(255,255,255)"/></svg></span>Proceed </button></div></form>
                              <div id="brave_form_custom_content-NRIz8ywHGExzcP8OZa9" class="brave_form_custom_content"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div><div class="brave_popup__step brave_popup__step__mobile brave_popup__step--noContent position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-width="320" data-scrollock="" data-height="480" data-popopen="false" style="z-index:99999" data-nomobilecontent="true"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4371', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4371', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div></div>            </div>
                     <div class="brave_popup brave_popup--popup" id="brave_popup_4845" data-loaded="false" >
               <!-- <p></p> -->
               <input type="hidden" id="brave_form_security-NRdvoHJNCCMeMMN2nVn" name="brave_form_security-NRdvoHJNCCMeMMN2nVn" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" />         <script>
            document.addEventListener("DOMContentLoaded", function(event) {


                              brave_popup_formData['-NRdvoHJNCCMeMMN2nVn'] = {
                  formID: '-NRdvoHJNCCMeMMN2nVn',
                  popupID: '4845',
                  stepID: '0',
                  device: 'desktop',
                  fields: '{"-NRdvoHJNCCMeMMN2nVo":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}},"-NRdvoHJNCCMeMMN2nVp":{"uid":"","type":"input","required":true,"validation":"email","conditions":{}},"-NRdvoHJNCCMeMMN2nVq":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}}}',
                  track: 'null',
                  changesFormHeight: false,
                  heightData: [295],
                  goal: false,
                  recaptcha: false,
                  social_optin: false,
                  totalSteps: 0,
                  quiz: false,
                  quizScoring: "points",
                  totalQuestions: 0,
                  totalScore: 0,
                  totalCorrect: 0,
                  freemailAllow: false,
                  conditions: [],
                  conditionsMatch: {},
                  conditionsVals: {},
                  onSubmit: function(formData, response){  },
               }
               
            });
         </script>

      <div id="brave_popup_4845__step__0" class="brave_popup__step_wrap brave_popup__step--mobile-noContent"><div class="brave_popup__step brave_popup__step__desktop  position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-nomobilecontent="true" data-scrollock="" data-width="700" data-height="450" data-popopen="false" style="z-index:99999"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4845', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4845', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "><div id="brave_element--NRdvoHJNCCMeMMN2nVk" class="brave_element brave_element--image   ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           <div class="brave_element__image_inner">
                              
                                 
                                 <img class="brave_element__image  brave_element_img_item skip-lazy no-lazyload" data-lazy="https://salahkaarrealtors.com/wp-content/uploads/2023/03/1-4.png" src="https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/images/preloader.png" alt="" />
                                 
                              
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvoHJNCCMeMMN2nVl" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">Enquire Now!</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvoHJNCCMeMMN2nVm" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">If you have any queries, kindly fill the form:</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvoHJNCCMeMMN2nVn" class="brave_element brave_element--form ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           
                           <div class="brave_element__form_inner ">
                           
                              <form id="brave_form_-NRdvoHJNCCMeMMN2nVn" class="brave_form_form    " method="post" data-cookies="" onsubmit="brave_submit_form(event, brave_popup_formData['-NRdvoHJNCCMeMMN2nVn'] )">
                                 <div class="brave_form_overlay"></div><div class="brave_form_fields" data-step="0"><div id="brave_form_field-NRdvoHJNCCMeMMN2nVo" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Full Name"  name="-NRdvoHJNCCMeMMN2nVo"  class=""  /></div><div id="brave_form_field-NRdvoHJNCCMeMMN2nVp" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="email" placeholder="Email Address*"  name="-NRdvoHJNCCMeMMN2nVp"  class=""  /></div><div id="brave_form_field-NRdvoHJNCCMeMMN2nVq" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Phone"  name="-NRdvoHJNCCMeMMN2nVq"  class=""  /></div><input type="hidden" id="brave_form_security-NRdvoHJNCCMeMMN2nVn" name="brave_form_security-NRdvoHJNCCMeMMN2nVn" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" /></div><div class="brave_form_button  "><button id="brave_form_button--NRdvoHJNCCMeMMN2nVn"><span id="brave_form_loading_-NRdvoHJNCCMeMMN2nVn" class="brave_form_loading"><svg width="20px" height="20px" viewBox="0 0 6.82666 6.82666" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none">
               <g fill="rgb(255,255,255)">
               <path d="M2.46703 5.54888c0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.030374,-0.113677 -0.0371575,-0.230461 -0.150835,-0.260835 -0.466854,-0.125091 -0.838799,-0.427543 -1.06273,-0.815406 -0.223752,-0.387547 -0.299567,-0.860783 -0.174425,-1.32783 0.125091,-0.466854 0.427543,-0.838795 0.815406,-1.06273 0.387547,-0.223752 0.860783,-0.299571 1.32783,-0.174429 0.466854,0.125091 0.838795,0.427543 1.06273,0.815406 0.223752,0.387547 0.299571,0.860783 0.174429,1.32783 -0.030374,0.113677 0.0371575,0.230461 0.150835,0.260835 0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.155433,-0.580094 0.0608307,-1.16861 -0.217768,-1.65116 -0.278421,-0.482236 -0.740776,-0.85826 -1.32106,-1.01374 -0.580094,-0.155433 -1.16861,-0.0608307 -1.65116,0.217768 -0.482236,0.278421 -0.85826,0.740776 -1.01374,1.32106 -0.155433,0.580094 -0.0608346,1.16861 0.217764,1.65116 0.278421,0.482236 0.74078,0.85826 1.32106,1.01374z"/><path d="M5.895 3.43303c0.0906654,-0.0745551 0.10372,-0.2085 0.0291654,-0.299165 -0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654l-0.669823 0.551189 -0.551102 -0.669724c-0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654 -0.0906654,0.0745551 -0.10372,0.2085 -0.0291654,0.299165l0.674638 0.81985c0.00343307,0.00497244 0.00708661,0.00985039 0.0109961,0.0146024 0.0748622,0.0909764 0.209307,0.104035 0.300283,0.0291732l-0.0005 -0.000606299 0.833839 -0.686154z"/></g>
               <rect fill="transparent" height="6.82666" width="6.82666"/>
            </svg></span><span class="brave_element-icon"><svg viewBox="0 0 512 512" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z" fill="rgb(255,255,255)"/></svg></span>Proceed </button></div></form>
                              <div id="brave_form_custom_content-NRdvoHJNCCMeMMN2nVn" class="brave_form_custom_content"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div><div class="brave_popup__step brave_popup__step__mobile brave_popup__step--noContent position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-width="320" data-scrollock="" data-height="480" data-popopen="false" style="z-index:99999" data-nomobilecontent="true"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4845', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4845', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div></div>            </div>
                     <div class="brave_popup brave_popup--popup" id="brave_popup_4846" data-loaded="false" >
               <!-- <p></p> -->
               <input type="hidden" id="brave_form_security-NRdvsIkOBLA3cKZjeMI" name="brave_form_security-NRdvsIkOBLA3cKZjeMI" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" />         <script>
            document.addEventListener("DOMContentLoaded", function(event) {


                              brave_popup_formData['-NRdvsIkOBLA3cKZjeMI'] = {
                  formID: '-NRdvsIkOBLA3cKZjeMI',
                  popupID: '4846',
                  stepID: '0',
                  device: 'desktop',
                  fields: '{"-NRdvsIkOBLA3cKZjeMJ":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}},"-NRdvsIkOBLA3cKZjeMK":{"uid":"","type":"input","required":true,"validation":"email","conditions":{}},"-NRdvsIkOBLA3cKZjeML":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}}}',
                  track: 'null',
                  changesFormHeight: false,
                  heightData: [295],
                  goal: false,
                  recaptcha: false,
                  social_optin: false,
                  totalSteps: 0,
                  quiz: false,
                  quizScoring: "points",
                  totalQuestions: 0,
                  totalScore: 0,
                  totalCorrect: 0,
                  freemailAllow: false,
                  conditions: [],
                  conditionsMatch: {},
                  conditionsVals: {},
                  onSubmit: function(formData, response){  },
               }
               
            });
         </script>

      <div id="brave_popup_4846__step__0" class="brave_popup__step_wrap brave_popup__step--mobile-noContent"><div class="brave_popup__step brave_popup__step__desktop  position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-nomobilecontent="true" data-scrollock="" data-width="700" data-height="450" data-popopen="false" style="z-index:99999"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4846', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4846', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "><div id="brave_element--NRdvsIkOBLA3cKZjeMF" class="brave_element brave_element--image   ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           <div class="brave_element__image_inner">
                              
                                 
                                 <img class="brave_element__image  brave_element_img_item skip-lazy no-lazyload" data-lazy="https://salahkaarrealtors.com/wp-content/uploads/2023/03/gallery5.jpg" src="https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/images/preloader.png" alt="" />
                                 
                              
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvsIkOBLA3cKZjeMG" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">Enquire Now!</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvsIkOBLA3cKZjeMH" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">If you have any queries, kindly fill the form:</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvsIkOBLA3cKZjeMI" class="brave_element brave_element--form ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           
                           <div class="brave_element__form_inner ">
                           
                              <form id="brave_form_-NRdvsIkOBLA3cKZjeMI" class="brave_form_form    " method="post" data-cookies="" onsubmit="brave_submit_form(event, brave_popup_formData['-NRdvsIkOBLA3cKZjeMI'] )">
                                 <div class="brave_form_overlay"></div><div class="brave_form_fields" data-step="0"><div id="brave_form_field-NRdvsIkOBLA3cKZjeMJ" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Full Name"  name="-NRdvsIkOBLA3cKZjeMJ"  class=""  /></div><div id="brave_form_field-NRdvsIkOBLA3cKZjeMK" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="email" placeholder="Email Address*"  name="-NRdvsIkOBLA3cKZjeMK"  class=""  /></div><div id="brave_form_field-NRdvsIkOBLA3cKZjeML" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Phone"  name="-NRdvsIkOBLA3cKZjeML"  class=""  /></div><input type="hidden" id="brave_form_security-NRdvsIkOBLA3cKZjeMI" name="brave_form_security-NRdvsIkOBLA3cKZjeMI" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" /></div><div class="brave_form_button  "><button id="brave_form_button--NRdvsIkOBLA3cKZjeMI"><span id="brave_form_loading_-NRdvsIkOBLA3cKZjeMI" class="brave_form_loading"><svg width="20px" height="20px" viewBox="0 0 6.82666 6.82666" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none">
               <g fill="rgb(255,255,255)">
               <path d="M2.46703 5.54888c0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.030374,-0.113677 -0.0371575,-0.230461 -0.150835,-0.260835 -0.466854,-0.125091 -0.838799,-0.427543 -1.06273,-0.815406 -0.223752,-0.387547 -0.299567,-0.860783 -0.174425,-1.32783 0.125091,-0.466854 0.427543,-0.838795 0.815406,-1.06273 0.387547,-0.223752 0.860783,-0.299571 1.32783,-0.174429 0.466854,0.125091 0.838795,0.427543 1.06273,0.815406 0.223752,0.387547 0.299571,0.860783 0.174429,1.32783 -0.030374,0.113677 0.0371575,0.230461 0.150835,0.260835 0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.155433,-0.580094 0.0608307,-1.16861 -0.217768,-1.65116 -0.278421,-0.482236 -0.740776,-0.85826 -1.32106,-1.01374 -0.580094,-0.155433 -1.16861,-0.0608307 -1.65116,0.217768 -0.482236,0.278421 -0.85826,0.740776 -1.01374,1.32106 -0.155433,0.580094 -0.0608346,1.16861 0.217764,1.65116 0.278421,0.482236 0.74078,0.85826 1.32106,1.01374z"/><path d="M5.895 3.43303c0.0906654,-0.0745551 0.10372,-0.2085 0.0291654,-0.299165 -0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654l-0.669823 0.551189 -0.551102 -0.669724c-0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654 -0.0906654,0.0745551 -0.10372,0.2085 -0.0291654,0.299165l0.674638 0.81985c0.00343307,0.00497244 0.00708661,0.00985039 0.0109961,0.0146024 0.0748622,0.0909764 0.209307,0.104035 0.300283,0.0291732l-0.0005 -0.000606299 0.833839 -0.686154z"/></g>
               <rect fill="transparent" height="6.82666" width="6.82666"/>
            </svg></span><span class="brave_element-icon"><svg viewBox="0 0 512 512" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z" fill="rgb(255,255,255)"/></svg></span>Proceed </button></div></form>
                              <div id="brave_form_custom_content-NRdvsIkOBLA3cKZjeMI" class="brave_form_custom_content"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div><div class="brave_popup__step brave_popup__step__mobile brave_popup__step--noContent position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-width="320" data-scrollock="" data-height="480" data-popopen="false" style="z-index:99999" data-nomobilecontent="true"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4846', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4846', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div></div>            </div>
                     <div class="brave_popup brave_popup--popup" id="brave_popup_4847" data-loaded="false" >
               <!-- <p></p> -->
               <input type="hidden" id="brave_form_security-NRdvxmdsAL75VCtxUfx" name="brave_form_security-NRdvxmdsAL75VCtxUfx" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" />         <script>
            document.addEventListener("DOMContentLoaded", function(event) {


                              brave_popup_formData['-NRdvxmdsAL75VCtxUfx'] = {
                  formID: '-NRdvxmdsAL75VCtxUfx',
                  popupID: '4847',
                  stepID: '0',
                  device: 'desktop',
                  fields: '{"-NRdvxmdsAL75VCtxUfy":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}},"-NRdvxmdsAL75VCtxUfz":{"uid":"","type":"input","required":true,"validation":"email","conditions":{}},"-NRdvxmdsAL75VCtxUg-":{"uid":"","type":"input","required":false,"validation":"text","conditions":{}}}',
                  track: 'null',
                  changesFormHeight: false,
                  heightData: [295],
                  goal: false,
                  recaptcha: false,
                  social_optin: false,
                  totalSteps: 0,
                  quiz: false,
                  quizScoring: "points",
                  totalQuestions: 0,
                  totalScore: 0,
                  totalCorrect: 0,
                  freemailAllow: false,
                  conditions: [],
                  conditionsMatch: {},
                  conditionsVals: {},
                  onSubmit: function(formData, response){  },
               }
               
            });
         </script>

      <div id="brave_popup_4847__step__0" class="brave_popup__step_wrap brave_popup__step--mobile-noContent"><div class="brave_popup__step brave_popup__step__desktop  position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-nomobilecontent="true" data-scrollock="" data-width="700" data-height="450" data-popopen="false" style="z-index:99999"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4847', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4847', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "><div id="brave_element--NRdvxmcdHZdA2eSBxEk" class="brave_element brave_element--image   ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           <div class="brave_element__image_inner">
                              
                                 
                                 <img class="brave_element__image  brave_element_img_item skip-lazy no-lazyload" data-lazy="https://salahkaarrealtors.com/wp-content/uploads/2023/03/Untitled-design-5.jpg" src="https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/images/preloader.png" alt="" />
                                 
                              
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvxmcdHZdA2eSBxEl" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">Enquire Now!</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvxmdsAL75VCtxUfw" class="brave_element brave_element--text ">
                  <div class="brave_element__wrap ">
                     <div class="brave_element__styler ">
                        <div class="brave_element__inner" >
                           
                              <div class="brave_element__text_inner">If you have any queries, kindly fill the form:</div>
                              
                           
                        </div>
                     </div>
                  </div>
               </div><div id="brave_element--NRdvxmdsAL75VCtxUfx" class="brave_element brave_element--form ">
                  <div class="brave_element__wrap">
                     <div class="brave_element__styler">
                        <div class="brave_element__inner">
                           
                           <div class="brave_element__form_inner ">
                           
                              <form id="brave_form_-NRdvxmdsAL75VCtxUfx" class="brave_form_form    " method="post" data-cookies="" onsubmit="brave_submit_form(event, brave_popup_formData['-NRdvxmdsAL75VCtxUfx'] )">
                                 <div class="brave_form_overlay"></div><div class="brave_form_fields" data-step="0"><div id="brave_form_field-NRdvxmdsAL75VCtxUfy" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Full Name"  name="-NRdvxmdsAL75VCtxUfy"  class=""  /></div><div id="brave_form_field-NRdvxmdsAL75VCtxUfz" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="email" placeholder="Email Address*"  name="-NRdvxmdsAL75VCtxUfz"  class=""  /></div><div id="brave_form_field-NRdvxmdsAL75VCtxUg-" class="brave_form_field brave_form_field--input "><div class="brave_form_field_error"></div><input type="text" placeholder="Phone"  name="-NRdvxmdsAL75VCtxUg-"  class=""  /></div><input type="hidden" id="brave_form_security-NRdvxmdsAL75VCtxUfx" name="brave_form_security-NRdvxmdsAL75VCtxUfx" value="2cfd76528f" /><input type="hidden" name="_wp_http_referer" value="/popper.js" /></div><div class="brave_form_button  "><button id="brave_form_button--NRdvxmdsAL75VCtxUfx"><span id="brave_form_loading_-NRdvxmdsAL75VCtxUfx" class="brave_form_loading"><svg width="20px" height="20px" viewBox="0 0 6.82666 6.82666" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none">
               <g fill="rgb(255,255,255)">
               <path d="M2.46703 5.54888c0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.030374,-0.113677 -0.0371575,-0.230461 -0.150835,-0.260835 -0.466854,-0.125091 -0.838799,-0.427543 -1.06273,-0.815406 -0.223752,-0.387547 -0.299567,-0.860783 -0.174425,-1.32783 0.125091,-0.466854 0.427543,-0.838795 0.815406,-1.06273 0.387547,-0.223752 0.860783,-0.299571 1.32783,-0.174429 0.466854,0.125091 0.838795,0.427543 1.06273,0.815406 0.223752,0.387547 0.299571,0.860783 0.174429,1.32783 -0.030374,0.113677 0.0371575,0.230461 0.150835,0.260835 0.113677,0.030374 0.230461,-0.0371575 0.260835,-0.150835 0.155433,-0.580094 0.0608307,-1.16861 -0.217768,-1.65116 -0.278421,-0.482236 -0.740776,-0.85826 -1.32106,-1.01374 -0.580094,-0.155433 -1.16861,-0.0608307 -1.65116,0.217768 -0.482236,0.278421 -0.85826,0.740776 -1.01374,1.32106 -0.155433,0.580094 -0.0608346,1.16861 0.217764,1.65116 0.278421,0.482236 0.74078,0.85826 1.32106,1.01374z"/><path d="M5.895 3.43303c0.0906654,-0.0745551 0.10372,-0.2085 0.0291654,-0.299165 -0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654l-0.669823 0.551189 -0.551102 -0.669724c-0.0745551,-0.0906654 -0.2085,-0.10372 -0.299165,-0.0291654 -0.0906654,0.0745551 -0.10372,0.2085 -0.0291654,0.299165l0.674638 0.81985c0.00343307,0.00497244 0.00708661,0.00985039 0.0109961,0.0146024 0.0748622,0.0909764 0.209307,0.104035 0.300283,0.0291732l-0.0005 -0.000606299 0.833839 -0.686154z"/></g>
               <rect fill="transparent" height="6.82666" width="6.82666"/>
            </svg></span><span class="brave_element-icon"><svg viewBox="0 0 512 512" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z" fill="rgb(255,255,255)"/></svg></span>Proceed </button></div></form>
                              <div id="brave_form_custom_content-NRdvxmdsAL75VCtxUfx" class="brave_form_custom_content"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div><div class="brave_popup__step brave_popup__step__mobile brave_popup__step--noContent position_center closeButton_icon brave_popup__step--boxed closeButtonPosition_inside_right has_overlay" data-width="320" data-scrollock="" data-height="480" data-popopen="false" style="z-index:99999" data-nomobilecontent="true"  data-exitanimlength="0.5" data-layout="boxed" data-position="center"><div class="brave_popup__step__inner">
                     <div class="brave_popupSections__wrap">
                        <div class="brave_popupMargin__wrap">
                           <div class="brave_popup__step__close"><div class="brave_popup__close brave_popup__close--inside_right brave_popup__close--icon">
                  <div class="brave_popup__close__button"  onclick="brave_close_popup('4847', 0, false)" onkeypress="if(event.key == 'Enter') { brave_close_popup('4847', 0, false) }"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"/></g></svg></div>
                  </div></div>
                           <div class="brave_popup__step__popup"><div class="brave_popup__step__content"><div class="brave_popup__step__elements"><div class="brave_popup__elements_wrap "></div></div></div></div>
                           
                        </div>
                     </div>
                  </div><div class="brave_popup__step__overlay " ></div></div></div>            </div>
         <div id="bravepop_element_tooltip"></div><div id="bravepop_element_lightbox"><div id="bravepop_element_lightbox_close" onclick="brave_lightbox_close()"></div><div id="bravepop_element_lightbox_content"></div></div><div id="qlwapp" class="qlwapp qlwapp-free qlwapp-button qlwapp-bottom-left qlwapp-all qlwapp-rounded">
	<div class="qlwapp-container">
		
		<a class="qlwapp-toggle" data-action="open" data-phone="917009096060" data-message="Hello I want to know more about the projects." role="button" tabindex="0" target="_blank">
							<i class="qlwapp-icon qlwapp-whatsapp-icon"></i>
						<i class="qlwapp-close" data-action="close">&times;</i>
							<span class="qlwapp-text">How can We help you?</span>
					</a>
	</div>
</div>
            <script>
               
               document.addEventListener("DOMContentLoaded", function(event) {
                  brave_popup_data[4371] = {
                  title: 'enquire',
                  type: 'popup',
                  fonts: ["Abril Fatface"],
                  advancedAnimation:false,
                  hasAnimation: false,
                  hasContAnim:  false,
                  animationData: [{"desktop":{"elements":[],"totalDuration":0},"mobile":{"elements":[],"totalDuration":0}}],
                  videoData: [],
                  hasYoutube: false,
                  hasVimeo: false,
                  settings: {"goal":"custom","audience":{},"frequency":{},"placement":{"placementType":"sitewide"},"trigger":{"triggerType":"click"},"goalAction":{"type":"step","step":0}},
                  close: [{"desktop":{},"mobile":{}}],
                  forceLoad: false,
                  forceStep: false,
                  hasDesktopEmbed: false,
                  hasMobileEmbed: false,
                  hasLoginElement: false,
                  schedule:{},
                  parentID:false,
                  variants: [],
                  embedLock: false,
                  ajaxLoad: false,
                  ajaxLoaded: false,
                  timers: [],
               }
                  brave_init_popup(4371, brave_popup_data[4371]);
               });

                        </script>
                  <style type='text/css'>
               #brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__step__inner{ width: 700px;  height: 450px;margin-top:-225px;font-family:Arial;}#brave_popup_4371__step__0 .brave_popup__step__desktop .brave_element__wrap{ font-family:Arial;}#brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4371__step__0 .brave_popup__step__desktop .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa6{ width: 316px;height: 466px;top: -4px;left: -12px;z-index: 0;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa7{ width: 244px;height: 67px;top: 44px;left: 352px;z-index: 1;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa8{ width: 281px;height: 33px;top: 112px;left: 351px;z-index: 2;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9{ width: 316px;height: 295px;top: 137px;left: 341px;z-index: 3;}#brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__step__inner{ width: 320px;  height: 480px;margin-top:-240px;font-family:Arial;}#brave_popup_4371__step__0 .brave_popup__step__mobile .brave_element__wrap{ font-family:Arial;}#brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4371__step__0 .brave_popup__step__mobile .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa6 .brave_element__styler{ }#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa6 img{ object-position: 0% 50%;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa7 .brave_element__text_inner{
            font-size: 34px;font-family: 'Abril Fatface';line-height: 1.7em;color: rgba(0,0,0, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa8 .brave_element__text_inner{
            font-size: 13px;line-height: 1.7em;color: rgba(138,138,138, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_element__styler, #brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_fields .formfield__checkbox_label{ font-size: 12px;font-family: inherit;color: rgba(0,0,0, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 input, #brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 textarea, #brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 select{ 
         padding: 18px;background-color: rgba(255, 255, 255, 1);color: rgba(51,51,51, 1);font-size: 12px;border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;font-family: inherit; border-style: solid;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_field { margin: 7.5px 0px;line-height: 18px;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .braveform_label { font-size: 12px;font-family: inherit;color: rgba(68,68,68, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 input[type="checkbox"]:checked:before, #brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 input[type="radio"]:checked:before{ color: rgba(230,91,107, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_button button{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;float: left;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_field--step .brave_form_stepNext{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;line-height: 40px;float: left;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_field--step .brave_form_skipstep{ font-family: inherit;font-size: 12px;color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .bravepopform_socialOptin_button{font-family: inherit;border-radius: 4px;font-size: 13px;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .bravepopform_socialOptin_button--email{background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_element-icon{ font-size: 11.05px}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_icon svg{ fill: rgba(255,255,255, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .formfield__inner__image--selected img{ border-color: rgba(230,91,107, 1);}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .formfield__inner__image__selection{ border-color: rgba(230,91,107, 1) transparent transparent transparent;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_field--checkbox_borderd .formfield__inner__checkbox label{border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;}#brave_popup_4371__step__0 #brave_element--NRIz8ywHGExzcP8OZa9 .brave_form_custom_content{ font-size: 13px;color: rgba(107, 107, 107, 1);}            </style>
                  <script>
               
               document.addEventListener("DOMContentLoaded", function(event) {
                  brave_popup_data[4845] = {
                  title: 'enquire tarc',
                  type: 'popup',
                  fonts: ["Abril Fatface"],
                  advancedAnimation:false,
                  hasAnimation: false,
                  hasContAnim:  false,
                  animationData: [{"desktop":{"elements":[],"totalDuration":0},"mobile":{"elements":[],"totalDuration":0}}],
                  videoData: [],
                  hasYoutube: false,
                  hasVimeo: false,
                  settings: {"goal":"custom","audience":{},"frequency":{},"placement":{"placementType":"sitewide"},"trigger":{"triggerType":"click"},"goalAction":{"type":"step","step":0}},
                  close: [{"desktop":{},"mobile":{}}],
                  forceLoad: false,
                  forceStep: false,
                  hasDesktopEmbed: false,
                  hasMobileEmbed: false,
                  hasLoginElement: false,
                  schedule:{},
                  parentID:false,
                  variants: [],
                  embedLock: false,
                  ajaxLoad: false,
                  ajaxLoaded: false,
                  timers: [],
               }
                  brave_init_popup(4845, brave_popup_data[4845]);
               });

                        </script>
                  <style type='text/css'>
               #brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__step__inner{ width: 700px;  height: 450px;margin-top:-225px;font-family:Arial;}#brave_popup_4845__step__0 .brave_popup__step__desktop .brave_element__wrap{ font-family:Arial;}#brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4845__step__0 .brave_popup__step__desktop .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVk{ width: 316px;height: 466px;top: -4px;left: -12px;z-index: 0;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVl{ width: 244px;height: 67px;top: 44px;left: 352px;z-index: 1;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVm{ width: 281px;height: 33px;top: 112px;left: 351px;z-index: 2;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn{ width: 316px;height: 295px;top: 137px;left: 341px;z-index: 3;}#brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__step__inner{ width: 320px;  height: 480px;margin-top:-240px;font-family:Arial;}#brave_popup_4845__step__0 .brave_popup__step__mobile .brave_element__wrap{ font-family:Arial;}#brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4845__step__0 .brave_popup__step__mobile .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVk .brave_element__styler{ }#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVk img{ object-position: 26% 200%;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVl .brave_element__text_inner{
            font-size: 34px;font-family: 'Abril Fatface';line-height: 1.7em;color: rgba(0,0,0, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVm .brave_element__text_inner{
            font-size: 13px;line-height: 1.7em;color: rgba(138,138,138, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_element__styler, #brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_fields .formfield__checkbox_label{ font-size: 12px;font-family: inherit;color: rgba(0,0,0, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn input, #brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn textarea, #brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn select{ 
         padding: 18px;background-color: rgba(255, 255, 255, 1);color: rgba(51,51,51, 1);font-size: 12px;border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;font-family: inherit; border-style: solid;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_field { margin: 7.5px 0px;line-height: 18px;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .braveform_label { font-size: 12px;font-family: inherit;color: rgba(68,68,68, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn input[type="checkbox"]:checked:before, #brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn input[type="radio"]:checked:before{ color: rgba(230,91,107, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_button button{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;float: left;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_field--step .brave_form_stepNext{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;line-height: 40px;float: left;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_field--step .brave_form_skipstep{ font-family: inherit;font-size: 12px;color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .bravepopform_socialOptin_button{font-family: inherit;border-radius: 4px;font-size: 13px;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .bravepopform_socialOptin_button--email{background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_element-icon{ font-size: 11.05px}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_icon svg{ fill: rgba(255,255,255, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .formfield__inner__image--selected img{ border-color: rgba(230,91,107, 1);}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .formfield__inner__image__selection{ border-color: rgba(230,91,107, 1) transparent transparent transparent;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_field--checkbox_borderd .formfield__inner__checkbox label{border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;}#brave_popup_4845__step__0 #brave_element--NRdvoHJNCCMeMMN2nVn .brave_form_custom_content{ font-size: 13px;color: rgba(107, 107, 107, 1);}            </style>
                  <script>
               
               document.addEventListener("DOMContentLoaded", function(event) {
                  brave_popup_data[4846] = {
                  title: 'enquire noida',
                  type: 'popup',
                  fonts: ["Abril Fatface"],
                  advancedAnimation:false,
                  hasAnimation: false,
                  hasContAnim:  false,
                  animationData: [{"desktop":{"elements":[],"totalDuration":0},"mobile":{"elements":[],"totalDuration":0}}],
                  videoData: [],
                  hasYoutube: false,
                  hasVimeo: false,
                  settings: {"goal":"custom","audience":{},"frequency":{},"placement":{"placementType":"sitewide"},"trigger":{"triggerType":"click"},"goalAction":{"type":"step","step":0}},
                  close: [{"desktop":{},"mobile":{}}],
                  forceLoad: false,
                  forceStep: false,
                  hasDesktopEmbed: false,
                  hasMobileEmbed: false,
                  hasLoginElement: false,
                  schedule:{},
                  parentID:false,
                  variants: [],
                  embedLock: false,
                  ajaxLoad: false,
                  ajaxLoaded: false,
                  timers: [],
               }
                  brave_init_popup(4846, brave_popup_data[4846]);
               });

                        </script>
                  <style type='text/css'>
               #brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__step__inner{ width: 700px;  height: 450px;margin-top:-225px;font-family:Arial;}#brave_popup_4846__step__0 .brave_popup__step__desktop .brave_element__wrap{ font-family:Arial;}#brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4846__step__0 .brave_popup__step__desktop .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMF{ width: 316px;height: 466px;top: -4px;left: -12px;z-index: 0;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMG{ width: 244px;height: 67px;top: 44px;left: 352px;z-index: 1;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMH{ width: 281px;height: 33px;top: 112px;left: 351px;z-index: 2;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI{ width: 316px;height: 295px;top: 137px;left: 341px;z-index: 3;}#brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__step__inner{ width: 320px;  height: 480px;margin-top:-240px;font-family:Arial;}#brave_popup_4846__step__0 .brave_popup__step__mobile .brave_element__wrap{ font-family:Arial;}#brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4846__step__0 .brave_popup__step__mobile .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMF .brave_element__styler{ }#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMF img{ object-position: 60% 50%;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMG .brave_element__text_inner{
            font-size: 34px;font-family: 'Abril Fatface';line-height: 1.7em;color: rgba(0,0,0, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMH .brave_element__text_inner{
            font-size: 13px;line-height: 1.7em;color: rgba(138,138,138, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_element__styler, #brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_fields .formfield__checkbox_label{ font-size: 12px;font-family: inherit;color: rgba(0,0,0, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI input, #brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI textarea, #brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI select{ 
         padding: 18px;background-color: rgba(255, 255, 255, 1);color: rgba(51,51,51, 1);font-size: 12px;border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;font-family: inherit; border-style: solid;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_field { margin: 7.5px 0px;line-height: 18px;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .braveform_label { font-size: 12px;font-family: inherit;color: rgba(68,68,68, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI input[type="checkbox"]:checked:before, #brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI input[type="radio"]:checked:before{ color: rgba(230,91,107, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_button button{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;float: left;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_field--step .brave_form_stepNext{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;line-height: 40px;float: left;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_field--step .brave_form_skipstep{ font-family: inherit;font-size: 12px;color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .bravepopform_socialOptin_button{font-family: inherit;border-radius: 4px;font-size: 13px;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .bravepopform_socialOptin_button--email{background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_element-icon{ font-size: 11.05px}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_icon svg{ fill: rgba(255,255,255, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .formfield__inner__image--selected img{ border-color: rgba(230,91,107, 1);}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .formfield__inner__image__selection{ border-color: rgba(230,91,107, 1) transparent transparent transparent;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_field--checkbox_borderd .formfield__inner__checkbox label{border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;}#brave_popup_4846__step__0 #brave_element--NRdvsIkOBLA3cKZjeMI .brave_form_custom_content{ font-size: 13px;color: rgba(107, 107, 107, 1);}            </style>
                  <script>
               
               document.addEventListener("DOMContentLoaded", function(event) {
                  brave_popup_data[4847] = {
                  title: 'enquire mahagun',
                  type: 'popup',
                  fonts: ["Abril Fatface"],
                  advancedAnimation:false,
                  hasAnimation: false,
                  hasContAnim:  false,
                  animationData: [{"desktop":{"elements":[],"totalDuration":0},"mobile":{"elements":[],"totalDuration":0}}],
                  videoData: [],
                  hasYoutube: false,
                  hasVimeo: false,
                  settings: {"goal":"custom","audience":{},"frequency":{},"placement":{"placementType":"sitewide"},"trigger":{"triggerType":"click"},"goalAction":{"type":"step","step":0}},
                  close: [{"desktop":{},"mobile":{}}],
                  forceLoad: false,
                  forceStep: false,
                  hasDesktopEmbed: false,
                  hasMobileEmbed: false,
                  hasLoginElement: false,
                  schedule:{},
                  parentID:false,
                  variants: [],
                  embedLock: false,
                  ajaxLoad: false,
                  ajaxLoaded: false,
                  timers: [],
               }
                  brave_init_popup(4847, brave_popup_data[4847]);
               });

                        </script>
                  <style type='text/css'>
               #brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__step__inner{ width: 700px;  height: 450px;margin-top:-225px;font-family:Arial;}#brave_popup_4847__step__0 .brave_popup__step__desktop .brave_element__wrap{ font-family:Arial;}#brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4847__step__0 .brave_popup__step__desktop .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmcdHZdA2eSBxEk{ width: 316px;height: 466px;top: -4px;left: -12px;z-index: 0;}#brave_popup_4847__step__0 #brave_element--NRdvxmcdHZdA2eSBxEl{ width: 244px;height: 67px;top: 44px;left: 352px;z-index: 1;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfw{ width: 281px;height: 33px;top: 112px;left: 351px;z-index: 2;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx{ width: 316px;height: 295px;top: 137px;left: 341px;z-index: 3;}#brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__step__inner{ width: 320px;  height: 480px;margin-top:-240px;font-family:Arial;}#brave_popup_4847__step__0 .brave_popup__step__mobile .brave_element__wrap{ font-family:Arial;}#brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__step__content{ background-color: rgba(255,255,255, 1); }#brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__step__overlay{ background-color: rgba(0,0,0, 0.7);}#brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__close{ font-size:24px; width:24px; color:rgba(0,0,0, 1);top:-32px}
                        #brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__close svg{ width:24px; height:24px;}
                        #brave_popup_4847__step__0 .brave_popup__step__mobile .brave_popup__close svg path{ fill:rgba(0,0,0, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmcdHZdA2eSBxEk .brave_element__styler{ }#brave_popup_4847__step__0 #brave_element--NRdvxmcdHZdA2eSBxEk img{ object-position: 0% 50%;}#brave_popup_4847__step__0 #brave_element--NRdvxmcdHZdA2eSBxEl .brave_element__text_inner{
            font-size: 34px;font-family: 'Abril Fatface';line-height: 1.7em;color: rgba(0,0,0, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfw .brave_element__text_inner{
            font-size: 13px;line-height: 1.7em;color: rgba(138,138,138, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_element__styler, #brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_fields .formfield__checkbox_label{ font-size: 12px;font-family: inherit;color: rgba(0,0,0, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx input, #brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx textarea, #brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx select{ 
         padding: 18px;background-color: rgba(255, 255, 255, 1);color: rgba(51,51,51, 1);font-size: 12px;border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;font-family: inherit; border-style: solid;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_field { margin: 7.5px 0px;line-height: 18px;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .braveform_label { font-size: 12px;font-family: inherit;color: rgba(68,68,68, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx input[type="checkbox"]:checked:before, #brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx input[type="radio"]:checked:before{ color: rgba(230,91,107, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_button button{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;float: left;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_field--step .brave_form_stepNext{ font-family: inherit;border-radius: 4px;background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);font-size: 13px;line-height: 40px;float: left;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_field--step .brave_form_skipstep{ font-family: inherit;font-size: 12px;color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .bravepopform_socialOptin_button{font-family: inherit;border-radius: 4px;font-size: 13px;font-family: inherit;border-width: 0px;border-color: rgba(0,0,0, 1);line-height: 40px;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .bravepopform_socialOptin_button--email{background-color: rgba(230,91,107, 1);color: rgba(255,255,255, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_element-icon{ font-size: 11.05px}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_icon svg{ fill: rgba(255,255,255, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .formfield__inner__image--selected img{ border-color: rgba(230,91,107, 1);}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .formfield__inner__image__selection{ border-color: rgba(230,91,107, 1) transparent transparent transparent;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_field--checkbox_borderd .formfield__inner__checkbox label{border-width: 1px;border-color: rgba(221,221,221, 1);border-radius: 4px;}#brave_popup_4847__step__0 #brave_element--NRdvxmdsAL75VCtxUfx .brave_form_custom_content{ font-size: 13px;color: rgba(107, 107, 107, 1);}            </style>
      <link rel='stylesheet' id='fluentform-elementor-widget-css' href='https://salahkaarrealtors.com/wp-content/plugins/fluentform/assets/css/fluent-forms-elementor-widget.css?ver=5.1.18' type='text/css' media='all' />
<link rel='stylesheet' id='wdk-elementor-main-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/elementor-elements/assets/css/wdk-main.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='eli-main-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/css/main.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/slick/slick.css?ver=1.8' type='text/css' media='all' />
<link rel='stylesheet' id='wdk-listings-list-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/elementor-elements/assets/css/widgets/wdk-listings-list.css?ver=1.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='wdk-element-button-css' href='https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/elementor-elements/assets/css/widgets/wdk-element-button.css?ver=1.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='bravepop_front_css-css' href='https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/css/frontend.min.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='e-animations-css' href='https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.21.8' type='text/css' media='all' />
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/salahkaarrealtors.com\/index.php\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/download-after-email/js/media-query.js?ver=1710674578" id="dae-media-query-js"></script>
<script type="text/javascript" id="dae-download-js-extra">
/* <![CDATA[ */
var objDaeDownload = {"ajaxUrl":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php","nonce":"9a92cf2e9f"};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/download-after-email/js/download.js?ver=1710674578" id="dae-download-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/download-pdf-after-submit-form/include/../js/axios.min.js?ver=1.0.0" id="axiosjs-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementinvader-addons-for-elementor/assets/js/main.js?ver=6.5.4" id="elementinvader_addons_for_elementor-main-js"></script>
<script type="text/javascript" id="rmp_menu_scripts-js-extra">
/* <![CDATA[ */
var rmp_menu = {"ajaxURL":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php","wp_nonce":"dbf184136b","menu":[]};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/responsive-menu/v4.0.0/assets/js/rmp-menu.min.js?ver=4.3.5" id="rmp_menu_scripts-js"></script>
<script type="text/javascript" id="wp-sms-front-script-js-extra">
/* <![CDATA[ */
var wpsms_ajax_object = {"newsletter_endpoint_url":"https:\/\/salahkaarrealtors.com\/index.php\/wp-json\/wpsms\/v1\/newsletter","unknown_error":"Unknown Error! Check your connection and try again.","loading_text":"Loading...","subscribe_text":"Subscribe","activation_text":"Activate","sender":"","front_sms_endpoint_url":null};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wp-sms/assets/js/frontend.min.js?ver=6.9.1" id="wp-sms-front-script-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/popper.min.js?ver=1.2.0" id="bootstrap-popper-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/libs/bootstrap-4.5.3/js/bootstrap.min.js?ver=4.5.0" id="bootstrap-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/counter.min.js?ver=1.0" id="nexproperty-counter-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/custom-select.js?ver=1.2.0" id="nexproperty-custom-select-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/froogaloop2.min.js?ver=1.2.0" id="froogaloop2-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/jquery.validate.min.js?ver=1.2.0" id="jquery-validate-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/modernizr-3.6.0.min.js?ver=3.6.0" id="modernizr-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/script.js?ver=1.2.0" id="nexproperty-script-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/js/validator.js?ver=1.2.0" id="nexproperty-validator-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/public/js/slick/slick.min.js?ver=1.8" id="slick-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/themes/nexproperty/assets/libs/slim-select/slimselect.min.js?ver=6.5.4" id="slimselect-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpdirectorykit/elementor-elements/assets/js/wdk-main.js?ver=1.0" id="wdk-elementor-main-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/uploads/wpmss/wpmssab.min.js?ver=1722949598" id="wpmssab-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/mousewheel-smooth-scroll/js/SmoothScroll.min.js?ver=1.4.10" id="SmoothScroll-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/uploads/wpmss/wpmss.min.js?ver=1722949598" id="wpmss-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wp-whatsapp-chat/build/frontend/js/index.js?ver=e91de9a147a4b721ec5b" id="qlwapp-js"></script>
<script type="text/javascript" id="wpcf7cf-scripts-js-extra">
/* <![CDATA[ */
var wpcf7cf_global_settings = {"ajaxurl":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/cf7-conditional-fields/js/scripts.js?ver=2.4.12" id="wpcf7cf-scripts-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/connect-contact-form-7-to-social-apps/assets/js/cf7cw-front-script.js?ver=2.1" id="cf7cw_script-js"></script>
<script type="text/javascript" id="bravepop_front_js-js-extra">
/* <![CDATA[ */
var bravepop_global = {"loggedin":"false","isadmin":"false","referer":"http:\/\/salahkaarrealtors.com\/wp-content\/themes\/nexproperty\/assets\/libs\/bootstrap-4.5.3\/js\/bootstrap.min.js?ver=4.5.0","security":"951cc8d2e8","goalSecurity":"87d0048302","couponSecurity":"1bb977f159","cartURL":"","checkoutURL":"","ajaxURL":"https:\/\/salahkaarrealtors.com\/wp-admin\/admin-ajax.php","field_required":"Required","no_html_allowed":"No Html Allowed","invalid_number":"Invalid Number","invalid_email":"Invalid Email","invalid_url":"Invalid URL","invalid_date":"Invalid Date","fname_required":"First Name is Required.","lname_required":"Last Name is Required.","username_required":"Username is Required.","email_required":"Email is Required.","email_invalid":"Invalid Email addresss.","pass_required":"Password is Required.","pass_short":"Password is too Short.","yes":"Yes","no":"No","login_error":"Something Went Wrong. Please contact the Site administrator.","pass_reset_success":"Please check your Email for the Password reset link.","customFonts":[],"disableGoogleFonts":"false"};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/brave-popup-builder/assets/frontend/brave.js?ver=6.5.4" id="bravepop_front_js-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.21.8" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.21.8" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.21.8","is_static":false,"experimentalFeatures":{"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"e_swiper_latest":true,"home_screen":true},"urls":{"assets":"https:\/\/salahkaarrealtors.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; salahkaarrealtors","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.21.8" id="elementor-frontend-js"></script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-includes/js/wp-util.min.js?ver=6.5.4" id="wp-util-js"></script>
<script type="text/javascript" id="wpforms-elementor-js-extra">
/* <![CDATA[ */
var wpformsElementorVars = {"captcha_provider":"recaptcha","recaptcha_type":"v2"};
/* ]]> */
</script>
<script type="text/javascript" src="https://salahkaarrealtors.com/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min.js?ver=1.8.8.3" id="wpforms-elementor-js"></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	         <script>
                     </script>
               <script>
                     </script>
               <script>
                     </script>
               <script>
                     </script>
      <div data-pafe-ajax-url="https://salahkaarrealtors.com/wp-admin/admin-ajax.php"></div></body>
</html> 
