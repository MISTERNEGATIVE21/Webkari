<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <meta name="format-detection" content="telephone=no">
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v22.8 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Royale Realtors India</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Royale Realtors India" />
	<meta property="og:site_name" content="Royale Realtors India" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.royalerealtorsindia.com/#website","url":"https://www.royalerealtorsindia.com/","name":"Royale Realtors India","description":"Luxury Real Estate","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.royalerealtorsindia.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//mlyapkxmiy5z.i.optimole.com' />
<link rel='preconnect' href='https://mlyapkxmiy5z.i.optimole.com' />
<link rel="alternate" type="application/rss+xml" title="Royale Realtors India &raquo; Feed" href="https://www.royalerealtorsindia.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Royale Realtors India &raquo; Comments Feed" href="https://www.royalerealtorsindia.com/comments/feed/" />
<link rel='stylesheet' id='ht_ctc_main_css-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/css/main.css?ver=4.4' type='text/css' media='all' />
<link rel='stylesheet' id='premium-addons-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/premium-addons-for-elementor/assets/frontend/min-css/premium-addons.min.css?ver=4.10.31' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://www.royalerealtorsindia.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video{margin:0 0 1em}.wp-block-template-part.has-background{margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #394041;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #fff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--primary: #ea723d;--wp--preset--color--orange-dark: #e0652e;--wp--preset--color--secondary: #1ea69a;--wp--preset--color--blue-dark: #0b8278;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 14px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 28px;--wp--preset--font-size--x-large: 42px;--wp--preset--font-size--normal: 16px;--wp--preset--font-size--huge: 36px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='wpcf7-redirect-script-frontend-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/wpcf7-redirect/build/css/wpcf7-redirect-frontend.min.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=1.6.28' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.29.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.20.3' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-12-css' href='https://www.royalerealtorsindia.com/wp-content/uploads/elementor/css/post-12.css?ver=1704434835' type='text/css' media='all' />
<link rel='stylesheet' id='ere-elementor-frontend-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/css/frontend.css?ver=2.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='inspiry-elementor-style-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/css/elementor-styles.min.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10416-css' href='https://www.royalerealtorsindia.com/wp-content/uploads/elementor/css/post-10416.css?ver=1709197965' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-8091-css' href='https://www.royalerealtorsindia.com/wp-content/uploads/elementor/css/post-8091.css?ver=1714062933' type='text/css' media='all' />
<link rel='stylesheet' id='main-css-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/styles/css/main.min.css?ver=4.2.1' type='text/css' media='all' />
<style id='main-css-inline-css' type='text/css'>
#scroll-top { bottom : 15px; }
.rh_banner__image { background-position : top center; }
h1, h2, h3, h4, h5, h6, .rh_logo .rh_logo__heading a,
							.rh_user .rh_user__details .rh_user__msg,
							.rh_slide__desc h3 .title, .rh_section .rh_section__head .rh_section__subtitle,
							.rh_page__head .rh_page__title .title, .rh_modal .rh_modal__wrap .rh_modal__dashboard .rh_modal__dash_link,
							.rh_page__head .rh_page__title .sub,
							.rh_page__head .rh_page__title .sub, .rh_agent_card__wrap .rh_agent_card__head .rh_agent_card__name .name a,
							body .rh_prop_card__details_elementor h3 a,
							body .rh_section__agents_elementor .rh_agent_elementor .rh_agent__details h3 a,
							body .classic_properties_elementor_wrapper .rhea_property_title a,
							.rh_prop_card .rh_prop_card__details h3 a,
							.property-thumbnail .property-title a { color : #1a1a1a; }
.rh_banner__cover { background : #0a0000; }
.rh_banner__cover { opacity : .5; }
.rh_banner .rh_banner__title { color : #ffffff; }
.inspiry_mod_header_varition_one ul.rh_menu__main li a:hover,
							   .inspiry_mod_header_varition_one ul.rh_menu__main > .current-menu-item > a,
							   .inspiry_mod_header_varition_one ul.rh_menu__main > .current-menu-ancestor > a,
							   .inspiry_mod_header_varition_one ul.rh_menu__main li:hover, 
							   .rh_menu--hover,
							   .rh_section__featured .rh_flexslider__nav a:hover,
							   .dsidx-widget-guided-search form input[type=submit]:hover,
							   .dsidx-widget-quick-search form input[type=submit]:hover,
							   #ihf-main-container .btn-primary.active,
							   .rh_prop_search__buttons_smart .rh_prop_search__advance a,
							   .rh_prop_search__buttons_smart .rh_prop_search__searchBtn button,
							   .rh_header_var_1 ul.rh_menu__main li:hover,
							   .rh_header_var_1 ul.rh_menu__main > .current-menu-item > a,
							   .rh_header_var_1 ul.rh_menu__main > .current-menu-ancestor > a,
							   .rh_header_var_1 ul.rh_menu__main li a:hover,
							   .rh_btn--secondary, 
							   .mc4wp-form-fields input[type="submit"],
							   .inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__searchBtn button,
							   .inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__advance a,
							   .rh_form__item .inspiry-details-wrapper .inspiry-detail .add-detail,
							   .brands-owl-carousel .owl-nav button.owl-prev:hover:not(.disabled), 
							   .brands-owl-carousel .owl-nav button.owl-next:hover:not(.disabled),
							   .rh_agent_options label .control__indicator:after,
							   .inspiry_bs_orange div.dropdown-menu,
							   .rh_prop_search__form_smart .inspiry_select_picker_trigger.open button.dropdown-toggle,
							   .rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu,
							   .widget.RVR_Booking_Widget h4.title,
							   .rvr_phone_icon,
							   .rh_cfos .cfos_phone_icon,
							   .woocommerce span.onsale, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content { background : #0a0000; }
.rh_cfos .cfos_phone_icon:after,
								.rvr_phone_icon:after { border-left-color : #0a0000; }
.rtl .rh_cfos .cfos_phone_icon:before,
								.rh_prop_search__form_smart .rh_form_smart_top_fields .inspiry_select_picker_trigger.open button.dropdown-toggle { border-right-color : #0a0000; }
.rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link .rh_agent_form .rh_agent_form__row,
				               .rh_agent_form .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link .rh_agent_form__row,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link p,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link span,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link i,
							   .qe-faqs-filters-container li a:hover,
							   #dsidx-top-search span.dsidx-search-bar-openclose:hover,
							   #dsidx.dsidx-results .dsidx-paging-control a:hover,
							   .dsidx-results-widget .dsidx-expanded .featured-listing>h4 a:hover,
							   .commentlist article .comment-detail-wrap .comment-reply-link:hover,
							   .rh_modal .rh_modal__wrap a:hover,
							   .agent-content-wrapper .description a, 
							   .agent-content-wrapper .rh_agent_card__link,
							   .rh_prop_search__wrap_smart .open_more_features,
							   .inspiry_mod_search_form_smart .rh_prop_search__wrap_smart .open_more_features,
							   .rh_section__news_wrap .categories a:hover,
							   .rh_agent .rh_agent__details .rh_agent__phone a:hover,
							   .rvr_optional_services_status li.rh_property__feature .rvr_not_available i,
							   .rvr_fa_icon
							    { color : #0a0000; }
.rh_prop_search__buttons_smart .rh_prop_search__searchBtn button:hover,
								.inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__searchBtn button:hover,
								.rh_form__item .inspiry-details-wrapper .inspiry-detail .add-detail:hover
								 { background : #090000; }
.inspiry_bs_orange div.dropdown-menu li.selected a,
								.inspiry_bs_orange div.dropdown-menu li:hover a,
								.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu li.selected a,
								.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu li:hover a,
								.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb,
								.rh_prop_search__form_smart .inspiry_select_picker_trigger .bs-actionsbox .btn-block .bs-select-all:hover,
								.rh_prop_search__form_smart .inspiry_select_picker_trigger .bs-actionsbox .btn-block .bs-deselect-all:hover { background : #080000; }
.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb { outline-color : #080000; }
.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track { box-shadow :  inset 0 0 6px #080000; }
.rh_cta__wrap .rh_cta__btns .rh_btn--secondary,
				.availability-calendar table td.unavailable,
				div.daterangepicker .calendar-table td.reserved,
				.rh_property__ava_calendar_wrap .calendar-guide ul li.reserved-days::before { background : rgba(10,0,0,1); }
.rh_cta__wrap .rh_cta__btns .rh_btn--secondary:hover, 
								.rh_btn--secondary:hover, .mc4wp-form-fields input:hover[type="submit"],
								.inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__advance a { background : rgba(10,0,0,0.8); }
.rh_modal .rh_modal__wrap .rh_modal__dashboard .rh_modal__dash_link:hover svg,
								.rh_property__features_wrap .rh_property__feature .rh_done_icon svg,
								.rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns a:hover svg path,
								.rh_list_card__wrap .rh_list_card__map_thumbnail .rh_list_card__btns a:hover svg path,
								.rh_property__print .rh_single_compare_button .highlight svg path,
								.rh_double_check,
								.rh_fav_icon_box a:hover svg path,
								.highlight svg path { fill : #0a0000; }
ul.rh_menu__main ul.sub-menu,
							   .rh_header_var_1 ul.rh_menu__main ul.sub-menu,
							   .rh_header_var_1 ul.rh_menu__main ul.sub-menu ul.sub-menu { border-top-color : #0a0000; }
.qe-testimonial-wrapper .qe-testimonial-img a:hover .avatar,
							   .commentlist article>a:hover img,
							   .rh_var_header .rh_menu__main .current-menu-ancestor,
							    .rh_var_header .rh_menu__main .current-menu-item,
							    .rh_var_header .rh_menu__main > li:hover,
							    .rh_prop_search__form_smart .inspiry_select_picker_trigger.open button.dropdown-toggle
							     { border-color : #0a0000; }
::selection { background-color : #d7a405; }
::-moz-selection { background-color : #d7a405; }
.rh_slide__desc .rh_slide_prop_price span,
							   .rh_slide__desc h3 .title:hover,
							   .rh_section--props_padding .rh_section__head .rh_section__subtitle,
							   .rh_section .rh_section__head .rh_section__subtitle,
							   .rh_prop_card .rh_prop_card__details h3 a:hover,
							   .rh_list_card__wrap .rh_list_card__map_wrap h3 a:hover,
							   .rh_list_card__wrap .rh_list_card__details_wrap h3 a:hover,
							   .rh_prop_card .rh_prop_card__details .rh_prop_card__priceLabel .rh_prop_card__price,
							   .rh_list_card__wrap .rh_list_card__map_details .rh_list_card__priceLabel .rh_list_card__price .price,
							   .rh_list_card__wrap .rh_list_card__priceLabel .rh_list_card__price .price,
							   .rh_prop_card .rh_prop_card__thumbnail .rh_overlay__contents a:hover,
							   .rh_agent .rh_agent__details h3 a:hover,
							   .rh_agent .rh_agent__details .rh_agent__phone a,
							   .rh_agent .rh_agent__details .rh_agent__email:hover,
							   .rh_agent .rh_agent__details .rh_agent__listed .figure,
							   .rh_list_card__wrap .rh_list_card__thumbnail .rh_overlay__contents a:hover,
							   .property-template-default .rh_page__property_price .price,
							   .rh_page__property .rh_page__property_price .price,
							   .rh_property_agent .rh_property_agent__agent_info .email .value,
							   .rh_property__id .id,
							   .rh_property__heading,
							   .rvr_price_details_wrap .rvr_price_details ul li.bulk-pricing-heading,
							   .rh_agent_card__wrap .rh_agent_card__head .rh_agent_card__listings .count,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link:hover .rh_agent_form .rh_agent_form__row,
							   .rh_agent_form .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link:hover .rh_agent_form__row,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link:hover p,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link:hover span,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__link:hover i,
							   .rh_agent_card__wrap .rh_agent_card__head .rh_agent_card__name .name a:hover,
							   .rh_agent_card__wrap .rh_agent_card__details .rh_agent_card__contact .rh_agent_card__contact_wrap .contact a:hover,
							   .rh_agent_profile__wrap .rh_agent_profile__head .rh_agent_profile__details .detail a:hover,
							   .rh_agent_profile__wrap .rh_agent_profile__head .rh_agent_profile__dp .listed_properties .number,
							   .agent-content-wrapper .listed_properties .number,
							   .rh_page__head .rh_page__title .sub,
							   .rh_gallery__wrap .rh_gallery__item .item-title a:hover,
							   .qe-testimonial-wrapper .qe-testimonial-byline a,
							   .qe-faqs-filters-container li a,
							   ol.dsidx-results li.dsidx-prop-summary .dsidx-prop-features>div:before,
							   #dsidx-top-search span.dsidx-search-bar-openclose,
							   #dsidx.dsidx-results .dsidx-paging-control a,
							   .dsidx-results:not(.dsidx-results-grid) #dsidx-listings .dsidx-listing .dsidx-data .dsidx-primary-data .dsidx-price,
							   .dsidx-results:not(.dsidx-results-grid) #dsidx-listings .dsidx-listing .dsidx-data .dsidx-secondary-data>div:before,
							   .dsidx-results-widget .dsidx-expanded .featured-listing ul li:before,
							   #ihf-main-container a:focus,
							   #ihf-main-container a:hover,
							   #ihf-main-container h4.ihf-price,
							   #ihf-main-container a:hover .ihf-grid-result-address,
							   #ihf-main-container a:focus .ihf-grid-result-address,
							   .commentlist article .comment-detail-wrap .comment-reply-link,
							   .page-breadcrumbs-modern li a,
							   .page-breadcrumbs-modern li i,
							   .agent-content-wrapper .description a:hover,
							   .agent-content-wrapper .rh_agent_card__link:hover,
							   .property-thumbnail .property-price p,
							   .property-thumbnail .property-title a:hover,
							   .rh_property__agent_head .description p a:hover,
							   .rh_property__agent_head .contacts-list .contact.email a:hover,
							   .rh_section__news_wrap .categories a,
							   .rh_section__news_wrap h3 a:hover,
							   .rh_compare__slide_img .rh_compare_view_title:hover,
							   div.rh_login_modal_wrapper .rh_login_tabs li.rh_active,
							   div.rh_login_modal_wrapper .rh_login_tabs li:hover,
							   .rh_list_card__wrap .rh_list_card__map_thumbnail .rh_overlay__contents a:hover,
							   body .leaflet-popup-content p,
							   body .leaflet-popup-content .osm-popup-title a:hover,
							   body .rh_compare__slide_img .rh_compare_view_title:hover,
							   .rh_my-property .rh_my-property__publish .publish h5,
							   .rh_property__yelp_wrap .yelp-places-group-title i,
							   .infoBox .map-info-window p,
							   .rvr_request_cta_number_wrapper .rvr-phone-number a,
							   .widget.RVR_Owner_Widget .rvr_widget_owner_label,
							   .infoBox .map-info-window a:hover,
							   .woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product .rh_agent_form .price.rh_agent_form__row, .rh_agent_form .woocommerce div.product .price.rh_agent_form__row, .woocommerce div.product span.price, .woocommerce ul.cart_list li .amount, .woocommerce ul.product_list_widget li .amount,
							   .rh_property__meta_wrap .rh_property__meta i,
							   .commentlist article .comment-detail-wrap .url,
							   h3.rh_heading_stylish a:hover,
							   .rh_theme_card__priceLabel_sty .rh_theme_card__price_sty,
							   .floor-plans-accordions .floor-plan-title .floor-plan-meta .floor-price-value,
							   .rvr_guests_accommodation_wrap .rvr_guests_accommodation ul li i.fas
							    { color : #d7a405; }
.rh_btn--primary, 
							   .post-password-form input[type="submit"],
							   .widget .searchform input[type="submit"],
							   .comment-form .form-submit .submit,
							   .rh_memberships__selection .ims-stripe-button .stripe-button-el,
							   .rh_memberships__selection #ims-free-button,
							   .rh_contact__form .wpcf7-form input[type="submit"],
							   .widget_mortgage-calculator .mc-wrapper p input[type="submit"],
							   .rh_memberships__selection .ims-receipt-button #ims-receipt,
							   .rh_contact__form .rh_contact__input input[type="submit"],
							   .rh_form__item input[type="submit"], .rh_pagination__pages-nav a,
							   .rh_modal .rh_modal__wrap button,
							   .rh_section__testimonial .diagonal-mod-background,
							   .rh_section__testimonial.flat-border,
							   .rh_blog__post .entry-header,
							   .rh_prop_search__form .rh_prop_search__fields .rh_prop_search__active,
							   .dsidx-widget-guided-search form input[type=submit],
							   .dsidx-widget-quick-search form input[type=submit],
							   ol.dsidx-results li.dsidx-prop-summary .dsidx-prop-title,
							   .rh_blog__post .entry-header,
							   .dsidx-results:not(.dsidx-results-grid) #dsidx-listings .dsidx-listing .dsidx-media .dsidx-photo .dsidx-photo-count,
							   #dsidx-top-search #dsidx-search-bar .dsidx-search-controls .button button,
							   .dsidx-results-grid #dsidx-listings .dsidx-listing .dsidx-data .dsidx-primary-data .dsidx-price,
							   .dsidx-results-grid #dsidx-listings .dsidx-listing .dsidx-media .dsidx-photo .dsidx-photo-count,
							   #dsidx .dsidx-large-button,
							   #dsidx .dsidx-small-button,
							   body.dsidx .dsidx-large-button,
							   body.dsidx .dsidx-small-button,
							   #dsidx-rentzestimate-notice,
							   #dsidx-zestimate-notice,
							   #dsidx.dsidx-details .dsidx-headerbar-green,
							   #ihf-main-container .title-bar-1,
							   #ihf-main-container .btn-primary,
							   #ihf-main-container .dropdown-menu>.active>a,
							   #ihf-main-container .dropdown-menu>li>a:hover,
							   #ihf-main-container .pagination li:first-child>a,
							   #ihf-main-container .pagination li:first-child>span,
							   #ihf-main-container .pagination li:last-child>a,
							   #ihf-main-container .pagination li:last-child>span,
							   #ihf-main-container .ihf-map-search-refine-link,
							   #ihf-main-container .btn-default,
							   .rh_sidebar .widget_ihomefinderpropertiesgallery>a,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-email,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-facebook,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-more,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-print,
							   button,
							   #ihf-main-container .modal-footer .btn,
							   .ihf-map-icon,
							   .rh_var2_header_meta_wrapper,
							   .rh_var3_header,
							   .open_more_features,
							   #home-properties-section .pagination a.current,
							   #home-properties-section .pagination a:hover,
							   .inspiry-floor-plans-group-wrapper .inspiry-btn-group .real-btn,
							   body .rh_fixed_side_bar_compare .rh_compare__submit,
							   .agent-custom-contact-form .wpcf7 input[type="submit"],
							   .rh_mod_sfoi_wrapper .rh_prop_search__select.rh_prop_search__active,
							   body .leaflet-popup-tip,
							   body .marker-cluster-small div,
							   .rh_prop_search__form .rh_prop_search__fields .inspiry_bs_is_open,
							   .rh_prop_search__form .rh_prop_search__fields .inspiry_bs_is_open .inspiry_select_picker_trigger button.dropdown-toggle,
							   .rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu,
							   #ui-datepicker-div .ui-datepicker-header,
							   #ui-datepicker-div .ui-datepicker-calendar tbody tr td.ui-datepicker-today a, 
							   #ui-datepicker-div.schedule-calendar-wrapper .ui-datepicker-calendar tbody tr td a.ui-state-highlight, 
							   #ui-datepicker-div.schedule-calendar-wrapper .ui-datepicker-calendar tbody tr td a.ui-state-highlight:hover, 
							   #ui-datepicker-div .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day,
							   form.rh_sfoi_advance_search_form .inspiry_bs_is_open,
							   form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu,
							   .inspiry_bs_green div.dropdown-menu,
							   .widget.RVR_Booking_Widget .rvr-booking-form-wrap .rvr-booking-form .submission-area input[type="submit"],
							   .availability-calendar .paging,
							    .cluster div,
							    .ere_latest_properties_ajax .pagination a.current,
							    .ere_latest_properties_ajax .pagination a:hover,
							    .woocommerce #respond input#submit:hover,
							    .woocommerce-page-wrapper .woocommerce a.button:hover,
							    .woocommerce a.button:hover,
							    .woocommerce button.button:hover,
							    .woocommerce input.button:hover,
							    .woocommerce #respond input#submit.alt:hover,
							    .woocommerce a.button.alt:hover,
							    .woocommerce button.button.alt:hover,
							    .woocommerce input.button.alt:hover,
							    .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
							    .select2-container--open .select2-dropdown--below, .select2-container--open .select2-dropdown--above,
								div.daterangepicker td.active, div.daterangepicker td.active:hover,
								.availability-calendar table td.today,
								.rh_property__ava_calendar_wrap .calendar-guide ul li.today::before { background : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .rh_mc_field .rh_form__item input[type=range]::-webkit-slider-thumb { background : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .rh_mc_field .rh_form__item input[type=range]::-moz-range-thumb  { background : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .rh_mc_field .rh_form__item input[type=range]::-ms-thumb { background : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .mc_cost_graph_circle .mc_graph_svg .mc_graph_interest { stroke : #0a0000; }
.rh_property__mc_wrap .rh_property__mc .mc_cost_graph_circle .mc_graph_svg .mc_graph_tax { stroke : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .mc_cost_graph_circle .mc_graph_svg .mc_graph_hoa { stroke : rgba(215,164,5,0.3); }
.rh_property__mc_wrap .rh_property__mc .mc_cost li.mc_cost_interest::before { background-color : #0a0000; }
.rh_property__mc_wrap .rh_property__mc .mc_cost li.mc_cost_tax::before { background-color : #d7a405; }
.rh_property__mc_wrap .rh_property__mc .mc_cost li.mc_cost_hoa::before { background-color : rgba(215,164,5,0.3); }
#ihf-main-container .btn-primary:active,
							   #ihf-main-container .btn-primary:focus,
							   #ihf-main-container .btn-primary:hover,
							   #ihf-main-container .pagination li:first-child>a:hover,
							   #ihf-main-container .pagination li:first-child>span:hover,
							   #ihf-main-container .pagination li:last-child>a:hover,
							   #ihf-main-container .pagination li:last-child>span:hover,
							   #ihf-main-container .ihf-map-search-refine-link,
							   #ihf-main-container .btn-default:active,
							   #ihf-main-container .btn-default:focus,
							   #ihf-main-container .btn-default:hover,
							   .rh_sidebar .widget_ihomefinderpropertiesgallery>a:hover,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-email:hover,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-facebook:hover,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-more:hover,
							   #ihf-main-container .ihf-social-share .ihf-share-btn-print:hover,
							   #ihf-main-container .modal-footer .btn:active,
							   #ihf-main-container .modal-footer .btn:focus,
							   #ihf-main-container .modal-footer .btn:hover,
							   .inspiry-floor-plans-group-wrapper .inspiry-btn-group .real-btn:hover,
							   .agent-custom-contact-form .wpcf7 input[type="submit"]:hover,
							   .widget.RVR_Booking_Widget .rvr-booking-form-wrap .rvr-booking-form .submission-area input[type="submit"]:hover,
							   .rh_mode_sfoi_search_btn button:hover { background : #c69705; }
.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu li.selected,
								.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu li:hover,
								.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu li.selected,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu li:hover,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb,
								.inspiry_bs_green div.dropdown-menu li.selected a,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu .actions-btn:hover,
								.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu .actions-btn:hover,
								.inspiry_bs_green div.dropdown-menu ::-webkit-scrollbar-thumb,
								.inspiry_bs_green div.dropdown-menu li:hover a { background : #b58a04; }
.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-thumb,
								.inspiry_bs_green div.dropdown-menu ::-webkit-scrollbar-thumb { outline-color : #b58a04; }
.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track,
								form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track,
								.inspiry_bs_green div.dropdown-menu ::-webkit-scrollbar-track { box-shadow :  inset 0 0 6px #b58a04; }
.rh_overlay { background : rgba(215,164,5,0.7); }
#dsidx-zestimate,#dsidx-rentzestimate { background-color : rgba(215,164,5,0.1); }
.rh_my-property .rh_my-property__publish .publish  { background-color : rgba(215,164,5,0.3); }
.rh_cta--contact .rh_cta .rh_cta__overlay { background-color : rgba(215,164,5,0.8); }
.rh_gallery__wrap .rh_gallery__item .media_container { background-color : rgba(215,164,5,0.9); }
blockquote,
				               .qe-faq-toggle .qe-toggle-title { background-color : rgba(215,164,5,0.1); }
.qe-faq-toggle .qe-toggle-title:hover,.qe-faq-toggle.active .qe-toggle-title, div.daterangepicker td.in-range:not(.active,.ends), .availability-calendar table td.available:not(.past-date,.today), .rh_property__ava_calendar_wrap .calendar-guide ul li.available-days::before { background-color : rgba(215,164,5,0.2); }
.qe-faq-toggle .qe-toggle-content { background-color : rgba(215,164,5,0.05); }
body .marker-cluster-small, .cluster { background-color : rgba(215,164,5,0.5); }
.rh_page__gallery_filters a.active,
							   .rh_page__gallery_filters a:hover,
							   .rh_page__head .rh_page__nav .active,
							   .rh_page__head .rh_page__nav .rh_page__nav_item:hover,
							   div.rh_login_modal_wrapper .rh_login_tabs li.rh_active,
							   div.rh_login_modal_wrapper .rh_login_tabs li:hover,
							   body .leaflet-popup-content-wrapper,
							   .infoBox .map-info-window { border-bottom-color : #d7a405; }
.ihf-map-icon:after, .infoBox .map-info-window .arrow-down,
							   .rh_latest_properties_2 .rh_tags_wrapper .rh_featured:before { border-top-color : #d7a405; }
blockquote,
							   .qe-testimonial-wrapper .qe-testimonial-img a .avatar,
							   #dsidx-rentzestimate, #dsidx-zestimate,
							   #dsidx.dsidx-details .dsidx-headerbar-green,
							   #dsidx.dsidx-details .dsidx-contact-form,
							   .commentlist article>a img,
							   .woocommerce #respond input#submit:hover, .woocommerce-page-wrapper .woocommerce a.button:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover { border-color : #d7a405; }
blockquote,
							   #dsidx-rentzestimate-triangle, #dsidx-zestimate-triangle,
							   .rh_latest_properties_2 .rh_tags_wrapper .rh_featured:before { border-left-color : #d7a405; }
.rh_latest_properties_2 .rh_tags_wrapper .rh_featured:before { border-right-color : #d7a405; }
.rh_slide__prop_meta .rh_svg,
							   .rh_svg,
							   .rh_banner .rh_view_type .active path,
							   .rh_banner .rh_view_type a:hover path,
							   .rh_view_type a.active svg path,
							   .rh_view_type a:hover svg path,							  
							   div.rh_modal_login_loader svg path { fill : #d7a405; }
.rh_btn--primary:hover, 
							   .post-password-form input[type="submit"]:hover,
							   .widget .searchform input[type="submit"]:hover,
							   .comment-form .form-submit .submit:hover,
							   .rh_memberships__selection .ims-stripe-button .stripe-button-el:hover,
							   .rh_memberships__selection #ims-free-button:hover,
							   .rh_contact__form .wpcf7-form input[type="submit"]:hover,
							   .widget_mortgage-calculator .mc-wrapper p input[type="submit"]:hover,
							   .rh_memberships__selection .ims-receipt-button #ims-receipt:hover,
							   .rh_contact__form .rh_contact__input input[type="submit"]:hover,
							   .rh_form__item input[type="submit"]:hover, .rh_pagination__pages-nav a:hover,
							   .rh_modal .rh_modal__wrap button:hover,
							   #dsidx .dsidx-large-button:hover,
							   #dsidx .dsidx-small-button:hover,
							   body.dsidx .dsidx-large-button:hover,
							   body.dsidx .dsidx-small-button:hover,
							   .open_more_features:hover,
							   #rh_save_search button:hover,
							   body .rh_fixed_side_bar_compare .rh_compare__submit:hover,
							   .select2-container--default .select2-results__option[aria-selected=true], 
							   .select2-container--default .select2-results__option[data-selected=true],
							   div.rh_login_modal_wrapper button:not(.dropdown-toggle):hover
							    { background : #ce9b18; }
.page-breadcrumbs-modern li a:hover { color : #ce9b18; }
.rh_section__testimonial .quotes-marks svg,
				               .rh_view_type a svg path { fill : #ce9b18; }
.rh_agent_card__wrap .rh_agent_card__head .rh_agent_card__name .name .rh_agent_verification__icon,
				               .rh_view_type a svg path { background : #d7a405; }
.rh_var2_header_meta_wrapper { background : #0054a6; }
.rh_logo .rh_logo__heading a,
								.rh_var_header .rh_logo__heading a { color : #ffffff; }
.rh_section--props_padding .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section--props_padding .rh_section__head .rh_section__desc { color : #808080; }
.rh_section--featured .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section--featured .rh_section__head .rh_section__desc { color : #808080; }
.rh_section__agents .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section__agents .rh_section__head .rh_section__desc { color : #808080; }
.rh_cta--featured .rh_cta__title { color : #ffffff; }
.rh_cta--featured .rh_cta__quote { color : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--secondary { color : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--greyBG { color : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--greyBG { background : rgba(255,255,255,0.25); }
.rh_cta__wrap .rh_cta__btns .rh_btn--greyBG:hover { background : rgba(255,255,255,0.4); }
.rh_cta--contact .rh_cta__title { color : #ffffff; }
.rh_cta--contact .rh_cta__quote { color : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--blackBG { color : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--blackBG { background : #303030; }
.rh_cta__wrap .rh_cta__btns .rh_btn--blackBG:hover { background : rgba(48,48,48,0.8); }
.rh_cta__wrap .rh_cta__btns .rh_btn--whiteBG { color : #303030; }
.rh_cta__wrap .rh_cta__btns .rh_btn--whiteBG { background : #ffffff; }
.rh_cta__wrap .rh_cta__btns .rh_btn--whiteBG:hover { background : rgba(255,255,255,0.8); }
.rh_latest-properties .diagonal-mod-background,
								.rh_latest-properties.flat-border { background-color : #F7F7F7; }
.rh_section--featured .diagonal-mod-background,
								.rh_section--featured.flat-border { background-color : #ffffff; }
.rh_testimonial .rh_testimonial__quote { color : #ffffff; }
.rh_testimonial .rh_testimonial__author .rh_testimonial__author_name { color : #ffffff; }
.rh_testimonial .rh_testimonial__author .rh_testimonial__author__link a { color : #ffffff; }
.rh_agent .rh_agent__details h3 a { color : #1a1a1a; }
.rh_agent .rh_agent__details .rh_agent__email, .rh_agent .rh_agent__details .rh_agent__listed .heading { color : #1a1a1a; }
.rh_section__agents .diagonal-mod-background,
								.rh_section__agents.flat-border { background-color : #f7f7f7; }
.rh_section__features .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section__features .rh_section__head .rh_section__desc { color : #808080; }
.rh_feature h4.rh_feature__title, .rh_feature h4.rh_feature__title a { color : #1a1a1a; }
.rh_feature .rh_feature__desc p { color : #808080; }
.rh_section__features .diagonal-mod-background,
								.rh_section__features.flat-border { background-color : #ffffff; }
.rh_section__partners .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section__partners .rh_section__head .rh_section__desc { color : #808080; }
.rh_section__partners .diagonal-mod-background,
								.rh_section__partners.flat-border { background-color : #ffffff; }
.rh_section__news .rh_section__head .rh_section__title { color : #1a1a1a; }
.rh_section__news .rh_section__head .rh_section__desc { color : #808080; }
.rh_section__news .diagonal-mod-background,
								.rh_section__news.flat-border { background-color : #ffffff; }
.rh_prop_card .rh_prop_card__details,
				 .rh_list_card__wrap .rh_list_card__details_wrap, 
				 .rh_list_card__wrap .rh_list_card__map_wrap,
			     .rh_latest_properties_2 .rh_property_card_stylish_inner,
				.rh_latest_properties_2 .rh_detail_wrapper_2 { background-color : #ffffff; }
.rh_prop_card .rh_prop_card__details h3 a, 
				.rh_list_card__wrap .rh_list_card__map_wrap h3 a, 
				.rh_list_card__wrap .rh_list_card__details_wrap h3 a,
				h3.rh_heading_stylish a { color : #1a1a1a; }
.rh_list_card__wrap,
				.rh_list_card__wrap .rh_list_card__details_wrap .rh_list_card__excerpt, 
				.rh_prop_card .rh_prop_card__details .rh_prop_card__excerpt,
				.rh_prop_card .rh_prop_card__details,
				.rh_latest_properties_2,
				div.rh_added_sty
				 { color : #808080; }
.rh_prop_card .rh_prop_card__details .rh_prop_card__meta .figure, .rh_list_card__meta div .label, .rh_list_card__meta div .figure,
				.rh_prop_card_meta_theme_stylish .rh_prop_card__meta .figure { color : #444; }
.rh_prop_card .rh_prop_card__details .rh_prop_card__meta span.rh_meta_titles, 
								.rh_prop_card .rh_prop_card__details .rh_prop_card__priceLabel .rh_prop_card__status, 
								.rh_list_card__wrap .rh_list_card__map_details .rh_list_card__priceLabel .rh_list_card__price .status, 
								.rh_list_card__meta h4, .rh_list_card__wrap .rh_list_card__priceLabel .rh_list_card__price .status, 
								.rh_list_card__wrap .rh_list_card__priceLabel .rh_list_card__author span,
								.rh_theme_card__priceLabel_sty span.rh_theme_card__status_sty,
								div.rh_added_sty span,
								.rh_prop_card_meta_theme_stylish .rh_prop_card__meta .rh_meta_titles { color : #1a1a1a; }
.rh_prop_card .rh_prop_card__details .rh_prop_card__meta svg, .rh_list_card__meta div svg,
				                .rh_prop_card_meta_theme_stylish .rh_prop_card__meta .rh_svg { fill : #b3b3b3; }
.rh_list_card__wrap .rh_list_card__thumbnail .rh_list_card__btns a svg path, 
				.rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns a svg path { fill : #ffffff; }
.rh_list_card__wrap .rh_list_card__thumbnail .rh_list_card__btns .favorite:hover svg path, 
				.rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns .favorite:hover svg path,
				.rh_fav_icon_box .favorite:hover svg path
				 { fill : #ea3d3d; }
.rh_list_card__wrap .rh_list_card__thumbnail .rh_list_card__btns .rh_trigger_compare svg path,
				.rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns .rh_trigger_compare svg path { fill : #ffffff; }
.rh_list_card__wrap .rh_list_card__thumbnail .rh_list_card__btns .rh_trigger_compare:hover svg path,
				.rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns .rh_trigger_compare:hover svg path,
				.rh_fav_icon_box .rh_trigger_compare:hover svg path { fill : #ea723d; }
[data-tooltip]:not([flow])::before, [data-tooltip][flow^=up]::before { border-top-color : #ea723d; }
[data-tooltip]::after { background : #ea723d; }
[data-tooltip]::after { color : #ffffff; }
.rh_address_sty a { color : #1f79b8; }
.rh_address_sty a:hover { color : #ea723d; }
.rh_address_sty .rh_address_pin svg { fill : #1f79b8; }
.rh_address_sty a:hover svg { fill : #ea723d; }
.rh_latest_properties_2 .rh_tags_wrapper .rh_featured:before { border-color : #1ea69a; }
.rh_latest_properties_2 .rh_tags_wrapper .rh_featured:before { border-bottom-color : transparent; }
.rh_latest_properties_2 .rh_tags_wrapper .rh-tags svg { fill : #fff; }
.rh_latest_properties_2 .rh_tags_wrapper .rh_hot:before { border-color : #d22d3e; }
.rh_latest_properties_2 .rh_tags_wrapper .rh_hot:before { border-bottom-color : transparent; }
.rh_latest_properties_2 .rh_tags_wrapper .rh-tags:not(.rh_featured) svg { fill : #fff; }
.rh_prop_status_sty { background-color : #000; }
.rh_prop_status_sty { color : #fff; }
.rh_agent_expand_wrapper .rh_agent_list .rh_agent_agency .rh_property_agent__title { color : #ffffff; }
.rh_agent_expand_wrapper .rh_agent_list .rh_agent_agency .rh_property_agent__title:hover { color : #f7f7f7; }
.rh_agent_expand_wrapper .rh_agent_list .rh_agent_agency .rh_property_agent__agency { color : #ffffff; }
.rh_agent_expand_wrapper .rh_agent_list .rh_agent_agency .rh_property_agent__agency:hover { color : #f7f7f7; }
.rh_wrapper_bottom_agent .rh_agent_expand_wrapper { background : #f7f7f7; }
.rh_wrapper_bottom_agent .rh_agent_expand_wrapper .rh_agent_list .rh_property_agent__title { color : #1a1a1a; }
.rh_wrapper_bottom_agent .rh_agent_expand_wrapper .rh_agent_list .rh_property_agent__title:hover { color : #1a1a1a; }
.rh_wrapper_bottom_agent .rh_agent_expand_wrapper .rh_agent_list .rh_property_agent__agency { color : #808080; }
.rh_wrapper_bottom_agent .rh_agent_expand_wrapper .rh_agent_list .rh_property_agent__agency:hover { color : #1a1a1a; }
.rh-grid-card-4 .rh-status-property-tag { background-color : #0b8278; }
.rh-grid-card-4 .rh-status-property-tag { color : #fff; }
.rh-grid-card-4 .rh_prop_card__price { color : #fff; }
.rh-grid-card-5 .rh-status-property-tag { background-color : #0b8278; }
.rh-grid-card-5 .rh-status-property-tag { color : #fff; }
.rh-grid-card-5 .rh-property-title { color : #fff; }
.rh-grid-card-5 .rh-property-price { color : #fff; }
.rh-grid-card-5 .rh_prop_card_meta_theme_stylish .rh_prop_card__meta .figure { color : #fff; }
.rh-grid-card-5 .rh_prop_card_meta_theme_stylish .rh_prop_card__meta svg,
				 .rh-grid-card-5 .rh_prop_card_meta_theme_stylish .rh_prop_card__meta path,
				 .rh-grid-card-5 .rh_prop_card_meta_theme_stylish .rh_prop_card__meta circle,
				 .rh-grid-card-5 .rh_prop_card_meta_theme_stylish .rh_prop_card__meta .label { fill : #fff; }
.rh_footer { background : #0054a5; }
.rh_footer:before { border-right-color : #0054a5; }
.rh_footer a, .rh_footer .rh_footer__wrap .designed-by a, .rh_footer .rh_footer__wrap .copyrights a, .rh_footer .rh_footer__social a { color : #aacef2; }
.rh_footer .Property_Types_Widget li::before, 
								.rh_footer .widget_recent_comments li::before, 
								.rh_footer .widget_recent_entries li::before, 
								.rh_footer .widget_categories li::before, 
								.rh_footer .widget_nav_menu li::before, 
								.rh_footer .widget_archive li::before, 
								.rh_footer .widget_pages li::before, 
								.rh_footer .widget_meta li::before { border-left-color : #aacef2; }
.rh_footer a:hover, .rh_footer .rh_contact_widget .rh_contact_widget__item a.content:hover, .rh_footer .rh_footer__wrap .designed-by a:hover, .rh_footer .rh_footer__wrap .copyrights a:hover, .rh_footer .rh_footer__social a:hover { color : #ffffff; }
.rh_footer__widgets .widget .title { color : #ffffff; }
.rh_footer, .rh_footer .rh_footer__logo .tag-line, .rh_footer__widgets .textwidget p, .rh_footer__widgets .textwidget, .rh_footer .rh_footer__wrap .copyrights, .rh_footer .rh_footer__wrap .designed-by, .rh_contact_widget .rh_contact_widget__item .content { color : #aacef2; }
.rh_contact_widget .rh_contact_widget__item .icon svg { fill : #aacef2; }
.rh_var2_header_meta_container .rh-btn, .rh_var2_header_meta_container .rh-btn-primary, .rh_var3_header .rh-btn-primary { border-color : #ffffff; }
.rh_var2_header_meta_container .rh-btn, .rh_var2_header_meta_container .rh-btn-primary:hover, .rh_var3_header .rh-btn-primary:hover { border-color : #ffffff; }
.rh_prop_search__form .rh_prop_search__buttons div.rh_prop_search__advance,
							   .inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__advance a { background :  !important; }
.rh_prop_search__form .rh_prop_search__buttons div.rh_prop_search__advance a:hover,
							   .inspiry_mod_search_form_smart .rh_prop_search__buttons_smart .rh_prop_search__advance a:hover { background :  !important; }
.rh_blog__post .entry-header .entry-meta { color : #ffffff; }
.rh_slide__desc h3 .title, .rh_slide__desc h3 { color : #1a1a1a; }
.rh_slide__desc p { color : #808080; }
.rh_slide__desc .rh_slide__meta_wrap .rh_slide__prop_meta span.rh_meta_titles,
								.rh_slide__desc .rh_slide_prop_price .rh_price_sym { color : #1a1a1a; }
.rh_slide__desc .rh_slide__meta_wrap .rh_slide__prop_meta div span { color : #444444; }
.rh_slide__prop_meta .rh_svg { fill : #cccccc; }
.rh_prop_search__form .rh_prop_search__fields .inspiry_select_picker_field .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track,
				 form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track, 
				 form.rh_prop_search__form_smart .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track,
				 form.rh_sfoi_advance_search_form .inspiry_select_picker_trigger div.dropdown-menu ::-webkit-scrollbar-track
				 { box-shadow :  inset 0 0 6px ; }
.rh_prop_search__form_smart .inspiry_select_picker_trigger .form-control,
				form.rh_sfoi_advance_search_form .inspiry_bs_is_open label
				 { color : !important; }
.rh_prop_search__form_smart .inspiry_select_picker_trigger .form-control
				 { border-color : !important; }
.rh_header--shadow { background : linear-gradient(180deg,rgba(0, 0, 0, 0.7)0%, rgba(255, 255, 255, 0) 100%);; }
.cls-1 { fill : #0a0000!important; }
#ihf-main-container .ihf-select-options .ihf-select-available-option>span.ihf-selected, .ihf-eureka .ihf-select-options .ihf-select-available-option>span.ihf-selected,
				#ihf-main-container .btn-primary, #ihf-main-container .btn.btn-default, #ihf-main-container .ihf-btn.ihf-btn-primary, .ihf-eureka .btn-primary, .ihf-eureka .btn.btn-default, .ihf-eureka .ihf-btn.ihf-btn-primary { background-color : #d7a405 !important; }
#ihf-main-container .btn-primary, #ihf-main-container .btn.btn-default,#ihf-main-container .ihf-btn.ihf-btn-primary, .ihf-eureka .btn-primary, .ihf-eureka .btn.btn-default, .ihf-eureka .ihf-btn.ihf-btn-primary { border-color : #d7a405 !important; }
#ihf-main-container .ihf-detail-tab-content #ihf-detail-features-tab .title-bar-1 { background-color : #d7a405 !important; }
#ihf-main-container .btn-primary:active, #ihf-main-container .btn-primary:focus, #ihf-main-container .btn-primary:hover, #ihf-main-container .btn.btn-default:active, #ihf-main-container .btn.btn-default:focus, #ihf-main-container .btn.btn-default:hover, #ihf-main-container .ihf-btn.ihf-btn-primary:active, #ihf-main-container .ihf-btn.ihf-btn-primary:focus, #ihf-main-container .ihf-btn.ihf-btn-primary:hover, .ihf-eureka .btn-primary:active, .ihf-eureka .btn-primary:focus, .ihf-eureka .btn-primary:hover, .ihf-eureka .btn.btn-default:active, .ihf-eureka .btn.btn-default:focus, .ihf-eureka .btn.btn-default:hover, .ihf-eureka .ihf-btn.ihf-btn-primary:active, .ihf-eureka .ihf-btn.ihf-btn-primary:focus, .ihf-eureka .ihf-btn.ihf-btn-primary:hover { background-color : #ce9b18 !important; }
#ihf-main-container .btn-primary:active, #ihf-main-container .btn-primary:focus, #ihf-main-container .btn-primary:hover, #ihf-main-container .btn.btn-default:active, #ihf-main-container .btn.btn-default:focus, #ihf-main-container .btn.btn-default:hover, #ihf-main-container .ihf-btn.ihf-btn-primary:active, #ihf-main-container .ihf-btn.ihf-btn-primary:focus, #ihf-main-container .ihf-btn.ihf-btn-primary:hover, .ihf-eureka .btn-primary:active, .ihf-eureka .btn-primary:focus, .ihf-eureka .btn-primary:hover, .ihf-eureka .btn.btn-default:active, .ihf-eureka .btn.btn-default:focus, .ihf-eureka .btn.btn-default:hover, .ihf-eureka .ihf-btn.ihf-btn-primary:active, .ihf-eureka .ihf-btn.ihf-btn-primary:focus, .ihf-eureka .ihf-btn.ihf-btn-primary:hover { border-color : #ce9b18 !important; }
.rh_prop_search__form .rh_prop_search__buttons .rh_prop_search__advance,
								.rh_mod_sfoi_advanced_expander { background-color : #c69705; }
.rh_prop_search__form .rh_prop_search__buttons .rh_prop_search__advance a:hover,
								.rh_mod_sfoi_advanced_expander:hover,
								.rh_mod_sfoi_advanced_expander.rh_sfoi_is_open { background-color : #b58a04; }
@media ( min-width: 1024px ) {
.open_more_features.featured-open { background : #ce9b18; }
}

</style>
<link rel='stylesheet' id='parent-default-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/style.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='inspiry-google-fonts-css' href='//fonts.googleapis.com/css?family=Jost%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%7CRubik%3A400%2C400i%2C500%2C500i%2C700%2C700i&#038;subset=latin%2Clatin-ext&#038;display=fallback&#038;ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=4.10.31' type='text/css' media='all' />
<link rel='stylesheet' id='vendors-css-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/optimize/vendors.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='parent-custom-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/styles/css/custom.css?ver=4.2.1' type='text/css' media='all' />
<style id='parent-custom-inline-css' type='text/css'>
#scroll-top.show { bottom : 15px; }
:root{--rh-global-color-primary: #d7a405;--rh-global-color-primary-rgb: 215,164,5;--rh-global-color-primary-dark: #ce9b18;--rh-global-color-secondary: #0a0000;--rh-global-color-secondary-rgb: 10,0,0;--rh-global-color-secondary-dark: #004284;--rh-global-color-text: #808080;--rh-global-color-headings: #1a1a1a;--rh-global-color-headings-hover: #d7a405;--rh-global-color-link: #444444;--rh-global-color-link-hover: #d7a405;--rh-small-border-radius: 5px;--rh-medium-border-radius: 10px;--rh-large-border-radius: 12px;}
.rh-btn-primary,
.rh-btn-secondary,
.rhea-btn-primary,
.rhea-btn-secondary {
  position: relative;
  z-index: 1;
  overflow: hidden;
}
.rh-btn-primary:before,
.rh-btn-secondary:before,
.rhea-btn-primary:before,
.rhea-btn-secondary:before {
  display: block;
  content: '';
  position: absolute;
  z-index: -1;
  transition: all 0.3s ease-in-out;
}
.rh-btn-primary:hover:before,
.rh-btn-secondary:hover:before,
.rhea-btn-primary:hover:before,
.rhea-btn-secondary:hover:before {
  transition: all 0.3s ease-in-out;
}
.rh-btn-primary,
.rh-btn-primary:hover,
.rhea-btn-primary,
.rhea-btn-primary:hover {
  background: var(--rh-global-color-primary);
  color: #fff;
}
.rh-btn-primary:before, 
.rhea-btn-primary:before{
  background: var(--rh-global-color-primary-dark, rgba(0, 0, 0, .2));
}
.rh-btn-secondary,
.rh-btn-secondary:hover,
.rhea-btn-secondary,
.rhea-btn-secondary:hover {
  background: var(--rh-global-color-secondary);
  color: #fff;
}
.rh-btn-secondary:before,
.rhea-btn-secondary:before {
  background: var(--rh-global-color-secondary-dark, rgba(0, 0, 0, .2));
}

.rh-btn-primary:before,
.rh-btn-secondary:before,
.rhea-btn-primary:before,
.rhea-btn-secondary:before {
  top: 0;
  right: 0;
  width: 0;
  height: 100%;
}
.rh-btn-primary:hover:before,
.rh-btn-secondary:hover:before,
.rhea-btn-primary:hover:before,
.rhea-btn-secondary:hover:before {
  right: auto;
  left: 0;
  width: 100%;
}

body,
             .rh_theme_card__priceLabel_sty span.rh_theme_card__status_sty, 
			 .rh_theme_card__priceLabel_sty .rh_theme_card__price_sty, 
			 .rh_my-property .rh_my-property__btns .stripe-button-el span
			 {
font-family: 'Jost', sans-serif;
}
h1, h2, h3, h4, h5, h6{
font-family: 'Jost', sans-serif;
font-weight: 500;
}

			.rh_prop_stylish_card__excerpt p, 
			.rh_prop_stylish_card__excerpt .rh_agent_form .rh_agent_form__row,
			.rh_agent_form .rh_prop_stylish_card__excerpt .rh_agent_form__row
			{
font-family: 'Jost', sans-serif;
}
</style>
<link rel='stylesheet' id='inspiry-frontend-style-css' href='https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/css/frontend-styles.min.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=3.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=3.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=3.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=5.9.21' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CJost%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.4.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-regular-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>        <script>
			// Declare some common JS variables.
            var ajaxurl = "https://www.royalerealtorsindia.com/wp-admin/admin-ajax.php";
        </script>
		<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>

<!-- Google tag (gtag.js) snippet added by Site Kit -->

<!-- Google Analytics snippet added by Site Kit -->
<script type="text/javascript" src="https://www.googletagmanager.com/gtag/js?id=G-3WQ0RPYLQH" id="google_gtagjs-js" async></script>
<script type="text/javascript" id="google_gtagjs-js-after">
/* <![CDATA[ */
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["www.royalerealtorsindia.com"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "G-3WQ0RPYLQH");
/* ]]> */
</script>

<!-- End Google tag (gtag.js) snippet added by Site Kit -->
<link rel="https://api.w.org/" href="https://www.royalerealtorsindia.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.royalerealtorsindia.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.3" />
<meta name="generator" content="Site Kit by Google 1.128.0" /><!-- HFCM by 99 Robots - Snippet # 1: LOCAL BUSINESS SEO SCHEMA MARKUP CODE -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "RealEstateAgent",
  "name": "Royale Realtors India",
  "image": "https://mlyapkxmiy5z.i.optimole.com/w:677/h:231/q:mauto/f:avif/https://www.royalerealtorsindia.com/wp-content/uploads/2022/07/cropped-Untitled_design__1_-removebg-preview.png",
  "@id": "",
  "url": "https://royalerealtorsindia.com/",
  "telephone": "9818312077",
  "priceRange": "$$$",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "19 DDA Market, Shanti Niketan",
    "addressLocality": "Delhi",
    "postalCode": "110021",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 28.5771739,
    "longitude": 77.1687974
  },
  "openingHoursSpecification": [{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Friday",
      "Thursday",
      "Saturday"
    ],
    "opens": "10:00",
    "closes": "07:30"
  },{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": "Sunday",
    "opens": "11:00",
    "closes": "06:30"
  }],
  "sameAs": [
    "https://www.facebook.com/royalerealtors/",
    "https://twitter.com/royalerealtors",
    "https://www.instagram.com/royalerealtorsindia/",
    "https://www.youtube.com/channel/UCD2idgfgCcdfanq_pJTxmFg/videos",
    "https://www.linkedin.com/in/lalit-kaushik%F0%9F%A5%87south-delhi-realtor-premium-luxury-%F0%9F%8F%9B%EF%B8%8F-real-estate-experience-5a691515/",
    "https://royalerealtorsindia.com"
  ],
  "department": {
    "@type": "LocalBusiness",
    "name": "",
    "image": "",
    "telephone": "" 
  }
}
</script>
<!-- /end HFCM by 99 Robots -->
<!-- HFCM by 99 Robots - Snippet # 2: GTM -->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MTX82MF4');</script>
<!-- End Google Tag Manager -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MTX82MF4"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- /end HFCM by 99 Robots -->
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '950409708874601');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=950409708874601&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code --><meta name="generator" content="Elementor 3.20.3; features: e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-auto">
<meta name="generator" content="Optimole 3.13.3"><link rel="icon" href="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:32/h:32/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2020/02/cropped-Untitled-design-2.png" sizes="32x32" />
<link rel="icon" href="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:192/h:192/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2020/02/cropped-Untitled-design-2.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:180/h:180/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2020/02/cropped-Untitled-design-2.png" />
<meta name="msapplication-TileImage" content="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:270/h:270/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2020/02/cropped-Untitled-design-2.png" />
		<style type="text/css" id="wp-custom-css">
			.rh_menu__user .rh_menu__user_phone .contact-number,
.user_menu_wrapper .rh_menu__user_phone .contact-number {
  font-size: 1.8rem;
}

@media (min-width: 1500px){
  .rh_slide__desc .rh_slide__desc_wrap {
    bottom: 10rem;
  }
}

.rh_pagination a {
  border-radius: var(--rh-small-border-radius);
}

.rh_prop_status_sty,
.rh_pagination .current,
.rh_pagination .rh_pagination__btn:hover{
  background-color: var(--rh-global-color-secondary);
}

.rh_slide__desc .rh_label,
.rh_label{
  background-color: var(--rh-global-color-primary);
}

#rh_slider__home .rh_label span,
.rh_label span {
  border-left-color:  var(--rh-global-color-primary) !important;
}

.rtl #rh_slider__home .rh_label span, .rh_label span {
  border-right-color:  var(--rh-global-color-primary) !important;
}

.rh_modal .rh_modal__wrap .rh_modal__dashboard .rh_modal__dash_link:hover svg, .rh_property__features_wrap .rh_property__feature .rh_done_icon svg, .rh_prop_card .rh_prop_card__thumbnail .rh_prop_card__btns a:hover svg path, .rh_list_card__wrap .rh_list_card__thumbnail .rh_list_card__btns a:hover svg path, .rh_list_card__wrap .rh_list_card__map_thumbnail .rh_list_card__btns a:hover svg path, .rh_property__print .rh_single_compare_button .highlight svg path, .rh_double_check, .rh_fav_icon_box a:hover svg path, .rh_address_sty a:hover svg, .highlight svg path {
  fill:var(--rh-global-color-primary);
}

[data-tooltip]:not([flow])::before, [data-tooltip][flow^=up]::before{
  border-top-color: var(--rh-global-color-primary);
}

[data-tooltip]::after{
  background-color: var(--rh-global-color-primary);
}

body{
    width:100%;
    overflow-x:hidden;
    overflow-y:hidden;
}		</style>
		</head>
<body class="error404 wp-embed-responsive ehf-header ehf-footer ehf-template-realhomes ehf-stylesheet-realhomes design_modern realhomes-round-corners inspiry_mod_header_variation_two inspriry_search_form_hidden_in_header inspiry_mod_search_form_smart inspiry_body_floating_features_show inspiry_responsive_header_solid elementor-default elementor-kit-12">
<div class="rh_wrap rh_wrap_stick_footer">		<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
			<p class="main-title bhf-hidden" itemprop="headline"><a href="https://www.royalerealtorsindia.com" title="Royale Realtors India" rel="home">Royale Realtors India</a></p>
					<div data-elementor-type="wp-post" data-elementor-id="10416" class="elementor elementor-10416">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-0f89042 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0f89042" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-582320e" data-id="582320e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-648e846 elementor-widget elementor-widget-image" data-id="648e846" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.20.0 - 26-03-2024 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>											<a href="https://www.royalerealtorsindia.com">
							<img fetchpriority="high" width="660" height="232" src="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:660/h:232/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/11/Untitled_design__1_-removebg-preview.png" class="attachment-large size-large wp-image-10424" alt="" srcset="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:660/h:232/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/11/Untitled_design__1_-removebg-preview.png 660w, https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:300/h:105/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/11/Untitled_design__1_-removebg-preview.png 300w, https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:150/h:53/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/11/Untitled_design__1_-removebg-preview.png 150w" sizes="(max-width: 660px) 100vw, 660px" />								</a>
													</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-998aa54" data-id="998aa54" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-10b33dd hfe-nav-menu__align-right hfe-nav-menu__breakpoint-mobile hfe-submenu-icon-arrow hfe-submenu-animation-none hfe-link-redirect-child elementor-widget elementor-widget-navigation-menu" data-id="10b33dd" data-element_type="widget" data-settings="{&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;width_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;220&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="navigation-menu.default">
				<div class="elementor-widget-container">
						<div class="hfe-nav-menu hfe-layout-horizontal hfe-nav-menu-layout horizontal hfe-pointer__none" data-layout="horizontal">
				<div role="button" class="hfe-nav-menu__toggle elementor-clickable">
					<span class="screen-reader-text">Menu</span>
					<div class="hfe-nav-menu-icon">
						<i aria-hidden="true"  class="fas fa-align-justify"></i>					</div>
				</div>
				<nav class="hfe-nav-menu__layout-horizontal hfe-nav-menu__submenu-arrow" data-toggle-icon="&lt;i aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot;fas fa-align-justify&quot;&gt;&lt;/i&gt;" data-close-icon="&lt;i aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot;far fa-window-close&quot;&gt;&lt;/i&gt;" data-full-width="yes">
					<ul id="menu-1-10b33dd" class="hfe-nav-menu"><li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/about/" class = "hfe-menu-item">About</a></li>
<li id="menu-item-328" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children parent hfe-has-submenu hfe-creative-menu"><div class="hfe-has-submenu-container"><a href="#" class = "hfe-menu-item">Properties<span class='hfe-menu-toggle sub-arrow hfe-menu-child-0'><i class='fa'></i></span></a></div>
<ul class="sub-menu">
	<li id="menu-item-330" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/residential-properties/" class = "hfe-sub-menu-item">Residential Properties</a></li>
	<li id="menu-item-331" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/commercial-properties/" class = "hfe-sub-menu-item">Commercial Properties</a></li>
	<li id="menu-item-332" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/farmhouses-villas/" class = "hfe-sub-menu-item">Farmhouses/Villas</a></li>
	<li id="menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/roi-properties/" class = "hfe-sub-menu-item">ROI properties</a></li>
</ul>
</li>
<li id="menu-item-329" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children parent hfe-has-submenu hfe-creative-menu"><div class="hfe-has-submenu-container"><a href="#" class = "hfe-menu-item">Services<span class='hfe-menu-toggle sub-arrow hfe-menu-child-0'><i class='fa'></i></span></a></div>
<ul class="sub-menu">
	<li id="menu-item-334" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/rent-or-lease-property/" class = "hfe-sub-menu-item">Rent or Lease Property</a></li>
	<li id="menu-item-335" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/buy-or-sell-property/" class = "hfe-sub-menu-item">Buy or Sell Property</a></li>
	<li id="menu-item-336" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/buy-sell-or-rent-lease-commercial-properties/" class = "hfe-sub-menu-item">Commercial Properties</a></li>
	<li id="menu-item-337" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/collaborations-joint-ventures/" class = "hfe-sub-menu-item">Collaborations</a></li>
	<li id="menu-item-1603" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/turn-key-construction-projects-architectural-services/" class = "hfe-sub-menu-item">Turnkey Projects</a></li>
	<li id="menu-item-340" class="menu-item menu-item-type-post_type menu-item-object-page hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/interior-projects/" class = "hfe-sub-menu-item">Interior Projects</a></li>
</ul>
</li>
<li id="menu-item-27" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://www.royalerealtorsindia.com/contact/" class = "hfe-menu-item">Contact</a></li>
</ul> 
				</nav>
			</div>
					</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
				</header>

	
<section class="rh_banner rh_banner__default  rh_banner__default_hide "></section>
<!-- /.rh_banner -->
	<section class="rh_section rh_wrap rh_wrap--padding rh_wrap--topPadding">
		<div class="rh_page">
            			<img decoding=async  fetchpriority="high" src="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:auto/h:auto/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/images/404-image.png" alt="404">
			<h2>It looks like you are lost!</h2>
            <br>
            <h4 class="no-results-sub-title">Perhaps the above header navigation can help.</h4>
					</div>
		<!-- /.rh_page -->
	</section>
	<!-- /.rh_section rh_wrap rh_wrap--padding -->
	    <div class="rh_sticky_wrapper_footer rh_apply_sticky_wrapper_footer rhea-hide-before-load">
				<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="8091" class="elementor elementor-8091">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-8111cd8 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8111cd8" data-element_type="section" id="particles" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-54ae85e" data-id="54ae85e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-a0a195e elementor-widget elementor-widget-image" data-id="a0a195e" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img width="677" height="231" src="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:677/h:231/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/07/cropped-Untitled_design__1_-removebg-preview.png" class="attachment-large size-large wp-image-9888" alt="" srcset="https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:677/h:231/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/07/cropped-Untitled_design__1_-removebg-preview.png 677w, https://mlyapkxmiy5z.i.optimole.com/cb:tRni.32383/w:300/h:102/q:mauto/f:best/https://www.royalerealtorsindia.com/wp-content/uploads/2022/07/cropped-Untitled_design__1_-removebg-preview.png 300w" sizes="(max-width: 677px) 100vw, 677px" />													</div>
				</div>
				<div class="elementor-element elementor-element-9434a4d elementor-widget elementor-widget-heading" data-id="9434a4d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.20.0 - 26-03-2024 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">Royale Realtors India</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-2f2df22 elementor-widget elementor-widget-heading" data-id="2f2df22" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">One-Stop Destination for Buying and Selling Luxury Homes and Top-Notch Commercial Spaces</p>		</div>
				</div>
				<div class="elementor-element elementor-element-4524358 elementor-shape-circle e-grid-align-left elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="4524358" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.20.0 - 26-03-2024 */
.elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container{line-height:1;font-size:0}.elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid{display:inline-grid}.elementor-widget-social-icons .elementor-grid{grid-column-gap:var(--grid-column-gap,5px);grid-row-gap:var(--grid-row-gap,5px);grid-template-columns:var(--grid-template-columns);justify-content:var(--justify-content,center);justify-items:var(--justify-content,center)}.elementor-icon.elementor-social-icon{font-size:var(--icon-size,25px);line-height:var(--icon-size,25px);width:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em));height:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em))}.elementor-social-icon{--e-social-icon-icon-color:#fff;display:inline-flex;background-color:#69727d;align-items:center;justify-content:center;text-align:center;cursor:pointer}.elementor-social-icon i{color:var(--e-social-icon-icon-color)}.elementor-social-icon svg{fill:var(--e-social-icon-icon-color)}.elementor-social-icon:last-child{margin:0}.elementor-social-icon:hover{opacity:.9;color:#fff}.elementor-social-icon-android{background-color:#a4c639}.elementor-social-icon-apple{background-color:#999}.elementor-social-icon-behance{background-color:#1769ff}.elementor-social-icon-bitbucket{background-color:#205081}.elementor-social-icon-codepen{background-color:#000}.elementor-social-icon-delicious{background-color:#39f}.elementor-social-icon-deviantart{background-color:#05cc47}.elementor-social-icon-digg{background-color:#005be2}.elementor-social-icon-dribbble{background-color:#ea4c89}.elementor-social-icon-elementor{background-color:#d30c5c}.elementor-social-icon-envelope{background-color:#ea4335}.elementor-social-icon-facebook,.elementor-social-icon-facebook-f{background-color:#3b5998}.elementor-social-icon-flickr{background-color:#0063dc}.elementor-social-icon-foursquare{background-color:#2d5be3}.elementor-social-icon-free-code-camp,.elementor-social-icon-freecodecamp{background-color:#006400}.elementor-social-icon-github{background-color:#333}.elementor-social-icon-gitlab{background-color:#e24329}.elementor-social-icon-globe{background-color:#69727d}.elementor-social-icon-google-plus,.elementor-social-icon-google-plus-g{background-color:#dd4b39}.elementor-social-icon-houzz{background-color:#7ac142}.elementor-social-icon-instagram{background-color:#262626}.elementor-social-icon-jsfiddle{background-color:#487aa2}.elementor-social-icon-link{background-color:#818a91}.elementor-social-icon-linkedin,.elementor-social-icon-linkedin-in{background-color:#0077b5}.elementor-social-icon-medium{background-color:#00ab6b}.elementor-social-icon-meetup{background-color:#ec1c40}.elementor-social-icon-mixcloud{background-color:#273a4b}.elementor-social-icon-odnoklassniki{background-color:#f4731c}.elementor-social-icon-pinterest{background-color:#bd081c}.elementor-social-icon-product-hunt{background-color:#da552f}.elementor-social-icon-reddit{background-color:#ff4500}.elementor-social-icon-rss{background-color:#f26522}.elementor-social-icon-shopping-cart{background-color:#4caf50}.elementor-social-icon-skype{background-color:#00aff0}.elementor-social-icon-slideshare{background-color:#0077b5}.elementor-social-icon-snapchat{background-color:#fffc00}.elementor-social-icon-soundcloud{background-color:#f80}.elementor-social-icon-spotify{background-color:#2ebd59}.elementor-social-icon-stack-overflow{background-color:#fe7a15}.elementor-social-icon-steam{background-color:#00adee}.elementor-social-icon-stumbleupon{background-color:#eb4924}.elementor-social-icon-telegram{background-color:#2ca5e0}.elementor-social-icon-threads{background-color:#000}.elementor-social-icon-thumb-tack{background-color:#1aa1d8}.elementor-social-icon-tripadvisor{background-color:#589442}.elementor-social-icon-tumblr{background-color:#35465c}.elementor-social-icon-twitch{background-color:#6441a5}.elementor-social-icon-twitter{background-color:#1da1f2}.elementor-social-icon-viber{background-color:#665cac}.elementor-social-icon-vimeo{background-color:#1ab7ea}.elementor-social-icon-vk{background-color:#45668e}.elementor-social-icon-weibo{background-color:#dd2430}.elementor-social-icon-weixin{background-color:#31a918}.elementor-social-icon-whatsapp{background-color:#25d366}.elementor-social-icon-wordpress{background-color:#21759b}.elementor-social-icon-x-twitter{background-color:#000}.elementor-social-icon-xing{background-color:#026466}.elementor-social-icon-yelp{background-color:#af0606}.elementor-social-icon-youtube{background-color:#cd201f}.elementor-social-icon-500px{background-color:#0099e5}.elementor-shape-rounded .elementor-icon.elementor-social-icon{border-radius:10%}.elementor-shape-circle .elementor-icon.elementor-social-icon{border-radius:50%}</style>		<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-401f43c" href="https://www.facebook.com/royalerealtors/" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-e0180c2" href="https://www.instagram.com/royalerealtorsindia/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-3d17f15" href="https://www.linkedin.com/in/lalit-kaushik%F0%9F%A5%87south-delhi-realtor-premium-luxury-%F0%9F%8F%9B%EF%B8%8F-real-estate-experience-5a691515/" target="_blank">
						<span class="elementor-screen-only">Linkedin</span>
						<i class="fab fa-linkedin"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-4295b48" href="https://twitter.com/royalerealtors" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-5c03f4b" href="https://www.youtube.com/channel/UCD2idgfgCcdfanq_pJTxmFg/videos" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-5c914e6" data-id="5c914e6" data-element_type="column">
			<div class="elementor-widget-wrap">
							</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-328c63e" data-id="328c63e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-5a6f209 elementor-widget elementor-widget-heading" data-id="5a6f209" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><span style="display:inline-block;width:40px;height:1px;border-top:1px solid white;transform:translateY(-3px);margin-right:10px"></span>

CALL</p>		</div>
				</div>
				<div class="elementor-element elementor-element-cf9d9a9 elementor-widget elementor-widget-heading" data-id="cf9d9a9" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><a href="tel:9818312077">+91 9818312077</a></p>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-f011517" data-id="f011517" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4a434d6 elementor-widget elementor-widget-heading" data-id="4a434d6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><span style="display:inline-block;width:40px;height:1px;border-top:1px solid white;transform:translateY(-3px);margin-right:10px"></span>

WRITE</p>		</div>
				</div>
				<div class="elementor-element elementor-element-257e653 elementor-widget elementor-widget-heading" data-id="257e653" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><a href="mailto:info@royalerealtorsindia.com">Info@royalerealtorsindia.com    </a></p>		</div>
				</div>
				<div class="elementor-element elementor-element-2a33be8 elementor-widget elementor-widget-heading" data-id="2a33be8" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><a href="mailto:Lalit@royalerealtorsindia.com">Lalit@royalerealtorsindia.com</a></p>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-7bcba01" data-id="7bcba01" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d74b671 elementor-widget elementor-widget-heading" data-id="d74b671" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"><span style="display:inline-block;width:40px;height:1px;border-top:1px solid white;transform:translateY(-3px);margin-right:10px"></span>

VISIT</p>		</div>
				</div>
				<div class="elementor-element elementor-element-0055375 elementor-widget elementor-widget-heading" data-id="0055375" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">19 DDA Market, Shanti Niketan, Delhi 110021</p>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-20afc01 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="20afc01" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-23d9e63" data-id="23d9e63" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-a0827e0 elementor-widget elementor-widget-heading" data-id="a0827e0" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">© ROYALE REALTORS 2024. ALL RIGHTS RESERVED.</p>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div>		</footer>
	    </div>
	</div>        <a href="#top" id="scroll-top" class="stp_right"><i class="fas fa-chevron-up"></i></a>
		    <div class="rh_wrapper_floating_features ">
		            <div class="rh_wrapper_properties_compare">
                <div class="rh_floating_compare_button">
						<span class="rh_compare_icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path d="M1144,1942l-8,1v3l-7-5,7-5v3l8,1A1,1,0,0,1,1144,1942Zm-22-14,8,1v3l7-5-7-5v3l-8,1A1,1,0,0,0,1122,1928Z" transform="translate(-1121 -1922)"/>
</svg>
						</span>
                    <span class="rh_compare_count"></span>
                </div>
                <div class="rh_fixed_side_bar_compare">
					    <section class="rh_compare rh_compare__section">
        <h4 class="title">Compare Properties</h4>
        <div class="rh_compare__carousel"></div>
        <a href="https://www.royalerealtorsindia.com/compare-properties/" class="rh_compare__submit rh_btn rh_btn--primary">Compare</a>
    </section>
	                </div>
            </div>
			    </div>
	        <div id="rh_compare_action_notification" class="rh_compare_action_notification">
            <span>You can only compare 4 properties, any new property added will replace the first one from the comparison.</span>
        </div>
		<div class="rh_login_modal_wrapper rh_login_modal_modern">
    <div class="rh_login_modal_box ">
        <span class="rh_login_close"><i class="fas fa-times"></i></span>
		            <div class="rh_login_sides rh_login_quote_side"
				>
                <div class="rh_bg_layer"></div>
                <div class="rh_wapper_quote_contents">
                    <div class="rh_login_quote_box">
						                            <span class="rh_login_quote_mark">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 28">
	<style type="text/css">

		.st0{fill-rule:evenodd;clip-rule:evenodd;}

	</style>
	<path class="st0" d="M33.2 2c-2.7 0-5.4 1.4-8 4.1 -2.7 2.6-4.3 6.2-4.3 9.9 -0.1 2.3 0.7 4.6 2.2 6.4 1.4 1.6 3.4 2.4 5.6 2.4 1.9 0 3.8-0.6 5.2-1.9 1.4-1.1 2.2-2.9 2.1-4.7 0.1-1.5-0.5-2.9-1.4-4 -0.9-1-2.2-1.6-3.6-1.6 -1.2 0.3-2.3 0.6-3.5 0.7 0.6-2.1 2.1-3.9 4.1-4.9l3.2-1.6C35.5 6.3 36 5.4 36 4.4 36 2.8 35.1 2 33.2 2L33.2 2zM12.7 15.8C11 16 9.4 16.6 8 17.5c-0.1-0.5-0.1-1-0.1-1.5 0.1-2 0.8-4 2.1-5.5 1.3-1.9 2-3.2 2-3.9 0-1.6-0.9-2.5-2.8-2.5 -1.5 0-3 1.3-4.6 3.8C2.9 10.3 2 13.2 2 16.2c-0.1 2.8 0.8 5.5 2.4 7.7 1.4 2 3.6 3.1 6 3.1 1.8 0.1 3.6-0.5 5-1.7 1.2-1.1 1.9-2.7 1.9-4.3C17.3 17.5 15.7 15.8 12.7 15.8L12.7 15.8 12.7 15.8z"/>
</svg>                            </span>
                            <p class="rh_login_quote">
								Owning a home is a keystone of wealth… both financial affluence and emotional security.                            </p>
							                                <span class="rh_login_quote_author">Suze Orman</span>
								                    </div>
					                        <div class="rh_login_date_box">
                            <span class="rh_login_date">June 7, 2024</span>
                            <span class="rh_login_day">Friday!</span>
                        </div>
						
                </div>
            </div>
			        <div class="rh_login_sides rh_login_form_side">
			                <div class="rh_login_blog_name">
					Royale Realtors India                </div>
				
            <ul class="rh_login_tabs">
				                    <li class="rh_login_tab rh_login_target rh_active">Login</li>
					            </ul>

            <div class="rh_wrapper_login_forms">
                <div class="rh_form_modal rh_login_form rh_login_modal_show">

					

                    <form id="rh_modal__login_form" action="https://www.royalerealtorsindia.com/wp-admin/admin-ajax.php"
                          method="POST" enctype="multipart/form-data">
                        <label class="rh_modal_labels"
                               for="username">Username</label>
                        <input name="log" class="rh_modal_field focus-class" autocomplete="username" id="username"
                               type="text"
                               placeholder="Username"
                               title="Username" required autofocus/>
                        <div class="rh_wrapper_inline_labels">
                            <label class="rh_modal_labels rh_modal_label_password"
                                   for="password">Password</label>
                            <span class="rh_forget_password_trigger">Forget Password?</span>
                        </div>
                        <input name="pwd" class="rh_modal_field" autocomplete="current-password" id="password"
                               type="password"
                               placeholder="Password"
                               title="Password" required/>
						                        <input type="hidden" name="action" value="inspiry_ajax_login"/>
						<input type="hidden" id="inspiry-secure-login" name="inspiry-secure-login" value="b24780ef28" /><input type="hidden" name="_wp_http_referer" value="/signals/iwl.js" />                        <input type="hidden" name="redirect_to"
                               value="https://www.royalerealtorsindia.com/signals/iwl.js"/>
						                            <button id="login-button"
                                    type="submit">Login</button>
							                    </form>

                </div>


                                <div class="rh_form_modal rh_password_reset_form">
                    <form action="https://www.royalerealtorsindia.com/wp-admin/admin-ajax.php" id="rh_modal__forgot_form"
                          method="post" enctype="multipart/form-data">
                        <input id="reset_username_or_email" name="reset_username_or_email" type="text"
                               placeholder="Username or Email"
                               class="rh_modal_field required"
                               title="Username or Email" required/>
						                        <input type="hidden" name="action" value="inspiry_ajax_forgot"/>
                        <input type="hidden" name="user-cookie" value="1"/>
						<input type="hidden" id="inspiry-secure-reset" name="inspiry-secure-reset" value="9f10e62dbd" /><input type="hidden" name="_wp_http_referer" value="/signals/iwl.js" />
						                            <button id="forgot-button"
                                    name="user-submit">Reset Password</button>
							

                    </form>

                </div>
            </div>

            <div class="inspiry_social_login">
				            </div>

            <div class="rh_modal_login_loader rh_modal_login_loader_hide rh_modal_login_modern">
	            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="32px" height="32px" viewBox="0 0 128 128" xml:space="preserve"><rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF" /><g><path d="M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z" fill="#1ea69a" fill-opacity="1"/><animateTransform attributeName="transform" type="rotate" from="0 64 64" to="360 64 64" dur="1000ms" repeatCount="indefinite"></animateTransform></g></svg>
            </div>

            <div class="rh_login_modal_messages rh_login_message_show">
                <span class="rh_login_close_message"><i class="fas fa-times"></i></span>
                <p id="forgot-error" class="rh_modal__msg"></p>
                <p id="forgot-message" class="rh_modal__msg"></p>

                <p id="register-message" class="rh_modal__msg"></p>
                <p id="register-error" class="rh_modal__msg"></p>

                <p id="login-message" class="rh_modal__msg"></p>
                <p id="login-error" class="rh_modal__msg"></p>
            </div>

        </div>
    </div>
</div>
<!-- Click to Chat - https://holithemes.com/plugins/click-to-chat/  v4.4 -->  
            <div class="ht-ctc ht-ctc-chat ctc-analytics ctc_wp_desktop style-2  " id="ht-ctc-chat"  
                style="display: none;  position: fixed; bottom: 70px; right: 15px;"   >
                                <div class="ht_ctc_style ht_ctc_chat_style">
                <div  style="display: flex; justify-content: center; align-items: center;  " class="ctc-analytics ctc_s_2">
    <p class="ctc-analytics ctc_cta ctc_cta_stick ht-ctc-cta  ht-ctc-cta-hover " style="padding: 0px 16px; line-height: 1.6; font-size: 15px; background-color: #25D366; color: #ffffff; border-radius:10px; margin:0 10px;  display: none; order: 0; ">Hi, How we can help you today?</p>
    <svg style="pointer-events:none; display:block; height:50px; width:50px;" width="50px" height="50px" viewBox="0 0 1024 1024">
        <defs>
        <path id="htwasqicona-chat" d="M1023.941 765.153c0 5.606-.171 17.766-.508 27.159-.824 22.982-2.646 52.639-5.401 66.151-4.141 20.306-10.392 39.472-18.542 55.425-9.643 18.871-21.943 35.775-36.559 50.364-14.584 14.56-31.472 26.812-50.315 36.416-16.036 8.172-35.322 14.426-55.744 18.549-13.378 2.701-42.812 4.488-65.648 5.3-9.402.336-21.564.505-27.15.505l-504.226-.081c-5.607 0-17.765-.172-27.158-.509-22.983-.824-52.639-2.646-66.152-5.4-20.306-4.142-39.473-10.392-55.425-18.542-18.872-9.644-35.775-21.944-50.364-36.56-14.56-14.584-26.812-31.471-36.415-50.314-8.174-16.037-14.428-35.323-18.551-55.744-2.7-13.378-4.487-42.812-5.3-65.649-.334-9.401-.503-21.563-.503-27.148l.08-504.228c0-5.607.171-17.766.508-27.159.825-22.983 2.646-52.639 5.401-66.151 4.141-20.306 10.391-39.473 18.542-55.426C34.154 93.24 46.455 76.336 61.07 61.747c14.584-14.559 31.472-26.812 50.315-36.416 16.037-8.172 35.324-14.426 55.745-18.549 13.377-2.701 42.812-4.488 65.648-5.3 9.402-.335 21.565-.504 27.149-.504l504.227.081c5.608 0 17.766.171 27.159.508 22.983.825 52.638 2.646 66.152 5.401 20.305 4.141 39.472 10.391 55.425 18.542 18.871 9.643 35.774 21.944 50.363 36.559 14.559 14.584 26.812 31.471 36.415 50.315 8.174 16.037 14.428 35.323 18.551 55.744 2.7 13.378 4.486 42.812 5.3 65.649.335 9.402.504 21.564.504 27.15l-.082 504.226z"/>
        </defs>
        <linearGradient id="htwasqiconb-chat" gradientUnits="userSpaceOnUse" x1="512.001" y1=".978" x2="512.001" y2="1025.023">
            <stop offset="0" stop-color="#61fd7d"/>
            <stop offset="1" stop-color="#2bb826"/>
        </linearGradient>
        <use xlink:href="#htwasqicona-chat" overflow="visible" style="fill: url(#htwasqiconb-chat)" fill="url(#htwasqiconb-chat)"/>
        <g>
            <path style="fill: #FFFFFF;" fill="#FFF" d="M783.302 243.246c-69.329-69.387-161.529-107.619-259.763-107.658-202.402 0-367.133 164.668-367.214 367.072-.026 64.699 16.883 127.854 49.017 183.522l-52.096 190.229 194.665-51.047c53.636 29.244 114.022 44.656 175.482 44.682h.151c202.382 0 367.128-164.688 367.21-367.094.039-98.087-38.121-190.319-107.452-259.706zM523.544 808.047h-.125c-54.767-.021-108.483-14.729-155.344-42.529l-11.146-6.612-115.517 30.293 30.834-112.592-7.259-11.544c-30.552-48.579-46.688-104.729-46.664-162.379.066-168.229 136.985-305.096 305.339-305.096 81.521.031 158.154 31.811 215.779 89.482s89.342 134.332 89.312 215.859c-.066 168.243-136.984 305.118-305.209 305.118zm167.415-228.515c-9.177-4.591-54.286-26.782-62.697-29.843-8.41-3.062-14.526-4.592-20.645 4.592-6.115 9.182-23.699 29.843-29.053 35.964-5.352 6.122-10.704 6.888-19.879 2.296-9.176-4.591-38.74-14.277-73.786-45.526-27.275-24.319-45.691-54.359-51.043-63.543-5.352-9.183-.569-14.146 4.024-18.72 4.127-4.109 9.175-10.713 13.763-16.069 4.587-5.355 6.117-9.183 9.175-15.304 3.059-6.122 1.529-11.479-.765-16.07-2.293-4.591-20.644-49.739-28.29-68.104-7.447-17.886-15.013-15.466-20.645-15.747-5.346-.266-11.469-.322-17.585-.322s-16.057 2.295-24.467 11.478-32.113 31.374-32.113 76.521c0 45.147 32.877 88.764 37.465 94.885 4.588 6.122 64.699 98.771 156.741 138.502 21.892 9.45 38.982 15.094 52.308 19.322 21.98 6.979 41.982 5.995 57.793 3.634 17.628-2.633 54.284-22.189 61.932-43.615 7.646-21.427 7.646-39.791 5.352-43.617-2.294-3.826-8.41-6.122-17.585-10.714z"/>
        </g>
        </svg></div>                </div>
            </div>
                        <span class="ht_ctc_chat_data" 
                data-no_number=""
                data-settings="{&quot;number&quot;:&quot;919818312077&quot;,&quot;pre_filled&quot;:&quot;Hey There!\r\nI&amp;#039;d Like To Have Some Help!&quot;,&quot;dis_m&quot;:&quot;show&quot;,&quot;dis_d&quot;:&quot;show&quot;,&quot;css&quot;:&quot;display: none; cursor: pointer; z-index: 99999999;&quot;,&quot;pos_d&quot;:&quot;position: fixed; bottom: 70px; right: 15px;&quot;,&quot;pos_m&quot;:&quot;position: fixed; bottom: 70px; right: 15px;&quot;,&quot;schedule&quot;:&quot;no&quot;,&quot;se&quot;:150,&quot;ani&quot;:&quot;no-animations&quot;,&quot;url_target_d&quot;:&quot;_blank&quot;,&quot;ga&quot;:&quot;yes&quot;,&quot;fb&quot;:&quot;yes&quot;,&quot;g_init&quot;:&quot;default&quot;,&quot;g_an_event_name&quot;:&quot;chat: {number}&quot;,&quot;pixel_event_name&quot;:&quot;Click to Chat by HoliThemes&quot;}" 
            ></span>
            
<script id="tmpl-rwmb-media-item" type="text/html">
	<input type="hidden" name="{{{ data.controller.fieldName }}}" value="{{{ data.id }}}" class="rwmb-media-input">
	<div class="rwmb-file-icon">
		<# if ( data.sizes ) { #>
			<# if ( data.sizes.thumbnail ) { #>
				<img src="{{{ data.sizes.thumbnail.url }}}">
			<# } else { #>
				<img src="{{{ data.sizes.full.url }}}">
			<# } #>
		<# } else { #>
			<# if ( data.image && data.image.src && data.image.src !== data.icon ) { #>
				<img src="{{ data.image.src }}" />
			<# } else { #>
				<img src="{{ data.icon }}" />
			<# } #>
		<# } #>
	</div>
	<div class="rwmb-file-info">
		<a href="{{{ data.url }}}" class="rwmb-file-title" target="_blank">
			<# if( data.title ) { #>
				{{{ data.title }}}
			<# } else { #>
				{{{ i18nRwmbMedia.noTitle }}}
			<# } #>
		</a>
		<div class="rwmb-file-name">{{{ data.filename }}}</div>
		<div class="rwmb-file-actions">
			<a class="rwmb-edit-media" title="{{{ i18nRwmbMedia.edit }}}" href="{{{ data.editLink }}}" target="_blank">
				{{{ i18nRwmbMedia.edit }}}
			</a>
			<a href="#" class="rwmb-remove-media" title="{{{ i18nRwmbMedia.remove }}}">
				{{{ i18nRwmbMedia.remove }}}
			</a>
		</div>
	</div>
</script>

<script id="tmpl-rwmb-media-status" type="text/html">
	<# if ( data.maxFiles > 0 ) { #>
		{{{ data.length }}}/{{{ data.maxFiles }}}
		<# if ( 1 < data.maxFiles ) { #>{{{ i18nRwmbMedia.multiple }}}<# } else {#>{{{ i18nRwmbMedia.single }}}<# } #>
	<# } #>
</script>

<script id="tmpl-rwmb-media-button" type="text/html">
	<a class="button">{{{ data.text }}}</a>
</script>

<script id="tmpl-rwmb-image-item" type="text/html">
	<input type="hidden" name="{{{ data.controller.fieldName }}}" value="{{{ data.id }}}" class="rwmb-media-input">
	<div class="rwmb-file-icon">
		<# if ( 'image' === data.type && data.sizes ) { #>
			<# if ( data.sizes[data.controller.imageSize] ) { #>
				<img src="{{{ data.sizes[data.controller.imageSize].url }}}">
			<# } else { #>
				<img src="{{{ data.sizes.full.url }}}">
			<# } #>
		<# } else { #>
			<# if ( data.image && data.image.src && data.image.src !== data.icon ) { #>
				<img src="{{ data.image.src }}" />
			<# } else { #>
				<img src="{{ data.icon }}" />
			<# } #>
		<# } #>
	</div>
	<div class="rwmb-image-overlay"></div>
	<div class="rwmb-image-actions">
		<a class="rwmb-image-edit rwmb-edit-media" title="{{{ i18nRwmbMedia.edit }}}" href="{{{ data.editLink }}}" target="_blank">
			<span class="dashicons dashicons-edit"></span>
		</a>
		<a href="#" class="rwmb-image-delete rwmb-remove-media" title="{{{ i18nRwmbMedia.remove }}}">
			<span class="dashicons dashicons-no-alt"></span>
		</a>
	</div>
</script>
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=1.6.28' type='text/css' media='all' />
<link rel='stylesheet' id='flatpickr-css' href='https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.min.css?ver=4.1.4' type='text/css' media='all' />
<script type="text/javascript" id="ht_ctc_app_js-js-extra">
/* <![CDATA[ */
var ht_ctc_chat_var = {"number":"919818312077","pre_filled":"Hey There!\r\nI'd Like To Have Some Help!","dis_m":"show","dis_d":"show","css":"display: none; cursor: pointer; z-index: 99999999;","pos_d":"position: fixed; bottom: 70px; right: 15px;","pos_m":"position: fixed; bottom: 70px; right: 15px;","schedule":"no","se":"150","ani":"no-animations","url_target_d":"_blank","ga":"yes","fb":"yes","g_init":"default","g_an_event_name":"chat: {number}","pixel_event_name":"Click to Chat by HoliThemes"};
var ht_ctc_variables = {"g_an_event_name":"chat: {number}","pixel_event_type":"trackCustom","pixel_event_name":"Click to Chat by HoliThemes","g_an_params":["g_an_param_1","g_an_param_2","g_an_param_3"],"g_an_param_1":{"key":"number","value":"{number}"},"g_an_param_2":{"key":"title","value":"{title}"},"g_an_param_3":{"key":"url","value":"{url}"},"pixel_params":["pixel_param_1","pixel_param_2","pixel_param_3","pixel_param_4"],"pixel_param_1":{"key":"Category","value":"Click to Chat for WhatsApp"},"pixel_param_2":{"key":"ID","value":"{number}"},"pixel_param_3":{"key":"Title","value":"{title}"},"pixel_param_4":{"key":"URL","value":"{url}"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/js/app.js?ver=4.4" id="ht_ctc_app_js-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.royalerealtorsindia.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/jquery.form.min.js?ver=4.3.0" id="jquery-form-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/easy-real-estate/js/jquery.validate.min.js?ver=2.1.1" id="jquery-validate-js"></script>
<script type="text/javascript" id="ere-frontend-js-extra">
/* <![CDATA[ */
var ere_social_login_data = {"ajax_url":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/easy-real-estate/js/ere-frontend.js?ver=2.1.1" id="ere-frontend-js"></script>
<script type="text/javascript" id="wpcf7-redirect-script-js-extra">
/* <![CDATA[ */
var wpcf7r = {"ajax_url":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/wpcf7-redirect/build/js/wpcf7r-fe.js?ver=1.1" id="wpcf7-redirect-script-js"></script>
<script type="text/javascript" id="rocket-browser-checker-js-after">
/* <![CDATA[ */
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-extra">
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index\\.php\/)?wp\\-json(\/.*|$)|\/wp-admin|\/logout|\/wp-login.php|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https:\/\/www.royalerealtorsindia.com","onHoverDelay":"100","rateThrottle":"3"};
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-after">
/* <![CDATA[ */
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/scripts/vendors/progressbar/dist/progressbar.min.js?ver=1.0.1" id="progress-bar-js"></script>
<script type="text/javascript" id="inspiry-search-js-extra">
/* <![CDATA[ */
var localizedSearchParams = {"rent_slug":"for-rent"};
var frontEndAjaxUrl = {"sfoiajaxurl":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/scripts/js/inspiry-search-form.js?ver=4.2.1" id="inspiry-search-js"></script>
<script type="text/javascript" id="custom-js-extra">
/* <![CDATA[ */
var localizeSelect = {"select_noResult":"No Results Found!"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/scripts/js/custom.js?ver=4.2.1" id="custom-js"></script>
<script type="text/javascript" id="ajax-search-js-extra">
/* <![CDATA[ */
var localized = {"additionalFields":[],"mapService":"googlemaps"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/assets/modern/scripts/js/ajax-search.js?ver=4.2.1" id="ajax-search-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/ui/tooltip.min.js?ver=1.13.2" id="jquery-ui-tooltip-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/js/inspiry-login.js?ver=4.2.1" id="inspiry-login-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/js/compare-properties.js?ver=4.2.1" id="compare-js-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/optimize/vendors.js?ver=4.2.1" id="vendors-js-js"></script>
<script type="text/javascript" id="vendors-js-js-after">
/* <![CDATA[ */
(function () {"use strict";const scrollSpy = new Gumshoe("#menu-main-menu a",{navClass: "active-menu-item", offset: 85,});})();
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/js/locations.js?ver=4.2.1" id="realhomes-locations-js"></script>
<script type="text/javascript" id="common-custom-js-extra">
/* <![CDATA[ */
var localizeSelect = {"select_noResult":"No Results Found!","ajax_url":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php","page_template":"","searching_string":"Searching...","loadingMore":"Loading more results..."};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/js/common-custom.js?ver=4.2.1" id="common-custom-js"></script>
<script type="text/javascript" id="inspiry-cfos-js-js-extra">
/* <![CDATA[ */
var inspiryUtilsPath = {"stylesheet_directory":"https:\/\/www.royalerealtorsindia.com\/wp-content\/themes\/realhomes\/common\/js\/utils.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/themes/realhomes/common/js/cfos.js?ver=4.2.1" id="inspiry-cfos-js-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=3.1.3" id="elementskit-framework-js-frontend-js"></script>
<script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
/* <![CDATA[ */
		var elementskit = {
			resturl: 'https://www.royalerealtorsindia.com/wp-json/elementskit/v1/',
		}

		
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=3.1.3" id="ekit-widget-scripts-js"></script>
<script type="text/javascript" id="eael-general-js-extra">
/* <![CDATA[ */
var localize = {"ajaxurl":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php","nonce":"050667407d","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"","cart_redirectition":"no","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=5.9.21" id="eael-general-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/wp-rocket/assets/js/heartbeat.js?ver=3.11.2" id="heartbeat-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/premium-addons-for-elementor/assets/frontend/min-js/premium-wrapper-link.min.js?ver=4.10.31" id="pa-wrapper-link-js"></script>
<script type="text/javascript" src="//maps.google.com/maps/api/js?key=AIzaSyBFV5ImxOVPYA6aI7rZao9PqkXjvbTVdvw&amp;language=en&amp;v=quarterly&amp;ver=6.4.3" id="google-map-api-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/markerclusterer.js?ver=2.1.1" id="google-map-marker-clusterer-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/oms.min.js?ver=0.3.3" id="google-map-oms-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/infobox.js?ver=1.1.9" id="google-map-info-box-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.20.3" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.20.3" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.20.3","is_static":false,"experimentalFeatures":{"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"e_swiper_latest":true,"block_editor_assets_optimize":true,"ai-layout":true,"landing-pages":true,"e_image_loading_optimization":true},"urls":{"assets":"https:\/\/www.royalerealtorsindia.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found - Royale Realtors India","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.20.3" id="elementor-frontend-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/google-map.js?ver=2.2.1" id="rhea-properties-google-map-js-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.13.2" id="jquery-ui-mouse-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-includes/js/jquery/ui/slider.min.js?ver=1.13.2" id="jquery-ui-slider-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/jquery.ui.touch-punch.min.js?ver=2.2.1" id="jquery-ui-touch-punch-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.min.js?ver=4.1.4" id="flatpickr-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/header-footer-elementor/inc/js/frontend.js?ver=1.6.28" id="hfe-frontend-js-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/realhomes-elementor-addon/elementor/js/frontend.js?ver=2.2.1" id="ere-elementor-frontend-js"></script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.min.js?ver=3.1.3" id="animate-circle-js"></script>
<script type="text/javascript" id="elementskit-elementor-js-extra">
/* <![CDATA[ */
var ekit_config = {"ajaxurl":"https:\/\/www.royalerealtorsindia.com\/wp-admin\/admin-ajax.php","nonce":"b664e34fb8"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.royalerealtorsindia.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=3.1.3" id="elementskit-elementor-js"></script>
</body>
</html>
