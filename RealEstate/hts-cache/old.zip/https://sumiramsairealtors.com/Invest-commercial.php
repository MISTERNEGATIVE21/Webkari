    <!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="app/dist/font-awesome.css">

    <link rel="stylesheet" href="app/dist/app.css">
    <link rel="stylesheet" href="app/dist/responsive.css">
    <link rel="stylesheet" href="app/dist/owl.css">
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="https://sumiramsairealtors.com/https://sumiramsairealtors.com/assets/images/logo/Favicon.webp">
    <link rel="apple-touch-icon-precomposed" href="https://sumiramsairealtors.com/assets/images/logo/Favicon.webp">
   <!--seo link start-->
     <title>Invest in Commercial Space in Noida@7293100100|Find Commercial property</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="canonical" href="https://sumiramsairealtors.com/Invest-commercial.php"/><meta name="description" content="commercial investment is a journey that demands careful consideration and strategic planning.Sumiram Sai Realtors takes pride in offering a diverse portfolio of commercial property "><meta name="keywords" content="Office Space in Noida, Commercial Project in Noida, Retail Shops in Noida Extension, Commercial Spaces, Commercial Shop, Noida Commercial Projects, Commercial Shops for Sale in Noida, Retail Shops, Office and Retail Space, London Mart Noida, Galactic City Noida, Sumiram Sai Realtors, Office Space in Noida, Retail Shops in Noida Extension, Pre-Leased shop in Noida, Coworking Space in Noida, Corporate Office Space in Noida, Premium Office Space in Noida, Workspace in Noida, Commercial Office Space for Sale in Noida, Buy Commercial Space in Noida, Best Commercial Projects in Noida Expressway, Buy Shop in Noida Extension, Looking for Warehouse Space, Commercial Retail Lease, Shop for Sale in Greater Noida West, Office and Retail Space for Lease, New Commercial Projects in Noida,"><meta name="robots" content="index, follow" /><meta name="googlebot" content="index, follow" /><meta name="author" content="sumiramsairealtors"><meta name="geo.position" content="noida" /><meta name="geo.placename" content="noida" /><meta name="geo.region" content=" 201301" /><meta name="page-topic" content="realtors and consultant " /><meta name="copyright" content="sumiram sai realtors" /><meta name="rating" content="safe for kids" /><meta name="referrer" content="always" /><meta name="reply-to" content="media@sumiramsairealtors.com" /><meta name="allow-search" content="yes" /><meta name="revisit-after" content="daily" /><meta name="distribution" content="india" /><meta name="expires" content="never" /><meta name="bingbot" content=" index, follow " /><meta name="twitter:title" content="Invest in Commercial Space in Noida @7293100100 | Commercial Land in Noida | Commercial land | Commercial space"/><meta name="twitter:description"content="best commercial investment is a journey that demands careful consideration and strategic planning.Sumiram Sai Realtors takes pride in offering a diverse portfolio of commercial properties." /><meta name="twitter:site"content="sumiram sair realtors"/><meta name ="twitter:creater"content="sumiram sai realtors"/><meta name ="author"content="sumiram sai realtors"/><meta property="og:local"content="en-IN"/><meta property="og:type"contnet="website"/><meta prpoerty="og:titel"content="Invest in Commercial Space in Noida @7293100100 | Commercial Land in Noida | Commercial land | Commercial space",/><meta property="og description"content="best commercial investment is a journey that demands careful consideration and strategic planning.Sumiram Sai Realtors takes pride in offering a diverse portfolio of commercial properties."/><meta propert="og:url"content="https://sumiramsairealtors.com"/><meta property="og:site_name"content="sumiram sai realtors"/>
 <script   src="https://code.jquery.com/jquery-3.3.1.js"></script>
<link rel="alternate" type="application/rss+xml" title="ROR" href="https://sumiramsairealtors.com/ror.xml" />
<style>
     .chat-button {
  position: fixed;
  bottom: 100px;
  right: 20px;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background-color: #e2e3e5;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: background-color 0.3s ease;
  z-index:9999;
}

.chat-button:hover {
  background-color: #35373a;
}

.chat-button img {
  width: 40px;
  height: 40px;
}
</style>
   <!--end seo link-->
   <script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "WebSite",
  "name": "Sumiram Sai Realtors",
  "url": "https://sumiramsairealtors.com/Invest-commercial",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://sumiramsairealtors.com/Invest-commercial{search_term_string}https://sumiramsairealtors.com/Invest-commercial",
    "query-input": "required name=search_term_string"
  }
}
</script>
</head>

<body class="body  ">
 <!-- <div class="preload preload-container">
        <div class="boxes ">
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
        </div>
    </div> -->
    
    <!-- /preload -->

    <div id="wrapper">
        <div id="pagee" class="clearfix">

            <!-- Main Header -->
            <header class="main-header">
                <!-- Header Lower -->
                <div class="header-lower">
                    <div class="container6">
                        <div class="row">                      
                            <div class="col-lg-12">         
                                <div class="inner-container flex justify-space align-center">
                                    <!-- Logo Box -->
                                    <div class="logo-box flex">
                                        <div class="logo"><a href="home"><img src="assets/images/logo/log 4.webp" alt="" width="197" height="48"></a></div>
                                    </div>
                                    <div class="nav-outer flex align-center">
                                        <!-- Main Menu -->
                                        <nav class="main-menu show navbar-expand-md">
                                            <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                                <ul class="navigation clearfix">
                                                    <li><a href="home">Home</a>
                                                    </li>
                                                    <li class="dropdown2"><a href="#">Project</a>
                                                        <ul>
                                                        <!--<li class="dropdown"><a href="kimaantra">Kimaantra Greens</a>-->
                                                                <!-- <ul>
                                                                    <li><a href="details-london-mart.php">Food Court</a></li>
                                                                    <li><a href="details-london-mart.php">Retail Shop</a></li> -->
                                                            
                                                                <!-- </ul> -->
                                                            </li>
                                                            <li class="dropdown2"><a href="details-london-mart">London Mart</a>
                                                                <ul>
                                                                    <li><a href="details-london-mart">Food Court</a></li>
                                                                    <li><a href="details-london-mart">Retail Shop</a></li>
                                                                    <!-- <li><a href="properties-list-sidebar-v2.html"></a></li> -->
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2"><a href="details-galactic-city">Galactic City</a>
                                                                <ul>
                                                                    <li><a href="details-galactic-city">IT Spaces</a></li>
                                                                    <li><a href="details-galactic-city">Commercial Spaces</a></li>
                                                                    <li><a href="details-galactic-city">Retail Offices</a></li>
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2"><a href="#">More</a>
                                                                <ul>
                                                                    <li><a href="commercial-property">Commercial Property</a></li>
                                                                    <li><a href="property-consultant">Property-Consultant</a></li>
                                                                    <li><a href="invest-commercial">Invest Commercial</a></li>
                                                                    <li><a href="commercial-realstate">Commercial Realstate</a></li>
                                                                    <li><a href="commercial-space-noida">Commercial Space Noida</a></li>
                                                                    <!--<li><a href="residential-plots">Residential Plot</a></li>-->
                                                                </ul>
                                                            </li>
                                                            <!-- <li class="dropdown2"><a href="#">Property Map</a>
                                                                <ul>
                                                                    <li><a href="properties-map-v1.html">Property Half Map V1</a></li>
                                                                    <li><a href="properties-map-v2.html">Property Half Map V2</a></li>
                                                                    <li><a href="properties-map-v3.html">Property Half Map V3</a></li>
                                                                </ul>
                                                            </li> -->
                                                        </ul>
                                                    </li>
                                                    <li class="dropdown2"><a href="#">About</a>
                                                        <ul>
                                                            <li><a href="about">About Company</a></li>
                                                             <li><a href="directors.php">Director's Corner</a></li>
                                                            <li><a href="leaderships.php">Leadership Board</a></li>
                                                            <li><a href="career">Career</a></li>
                                                            <li><a href="faq">Faq's</a></li>
                                                            <li><a href="gallery">Gallery</a></li>
                                                            <!-- <li><a href="error.html">Error</a></li>
                                                            <li class="dropdown2"><a href="#">Agents</a>
                                                                <ul>
                                                                    <li><a href="agents.html">Agents</a></li>
                                                                    <li><a href="agents-detail.html">Agents Details</a></li>
                                                                    <li><a href="agents-sidebar-v1.html">Agents Sidebar V1</a></li>
                                                                    <li><a href="agents-sidebar-v2.html">Agents Sidebar V2</a></li>
                                                                </ul>
                                                            </li> -->
                                                            <!-- <li class="dropdown2"><a href="#">Agencies</a>
                                                                <ul>
                                                                    <li><a href="agencies.html">Agencies</a></li>
                                                                    <li><a href="agencies-detail.html">Agencies Detail</a></li>
                                                                    <li><a href="agencies-sidebar-v1.html">Agencies Sidebar V1</a></li>
                                                                    <li><a href="agencies-sidebar-v2.html">Agencies Sidebar V2</a></li>
                                                                </ul>
                                                            </li> -->
                                                            <!-- <li><a href="dashboard.html">Dashboard</a></li> -->
                                                        </ul>
                                                    </li>
                                                    <!--<li><a href="news/index.php">News</a>-->
                                                        <!-- <ul>
                                                            <li><a href="blog.html">Blog List</a></li>
                                                            <li><a href="blog-grid.html">Blog Grid</a></li>
                                                            <li><a href="blog-detail.html">Blog Detail</a></li>
                                                        </ul> -->
                                                    </li>
                                                    
                                                    <li><a href="contact-us">Contact</a></li>
                                                </ul>
                                            </div>
                                        </nav>
                                        <!-- Main Menu End-->
                                    </div>
                                     <div class="header-account flex align-center">
                                        <!-- <div class="register">
                                            <ul class="flex align-center">
                                                <li>
                                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9.62501 18.5744H2.70418C2.65555 18.5744 2.60892 18.5551 2.57454 18.5207C2.54016 18.4863 2.52084 18.4397 2.52084 18.3911V17.0619C2.52084 16.3002 3.06443 15.6292 3.90226 15.059C5.39826 14.0378 7.81918 13.3943 10.5417 13.3943C10.9908 13.3943 11.4318 13.4127 11.8626 13.4466C11.9537 13.4558 12.0457 13.4466 12.1332 13.4198C12.2207 13.3929 12.3019 13.3489 12.3722 13.2902C12.4424 13.2315 12.5003 13.1594 12.5423 13.0781C12.5843 12.9968 12.6097 12.9079 12.6169 12.8166C12.6241 12.7254 12.613 12.6336 12.5842 12.5467C12.5555 12.4598 12.5097 12.3795 12.4495 12.3105C12.3893 12.2416 12.316 12.1853 12.2338 12.1451C12.1516 12.1048 12.0621 12.0814 11.9708 12.0762C11.4954 12.038 11.0186 12.0191 10.5417 12.0193C7.49651 12.0193 4.80059 12.7811 3.12676 13.9223C1.84984 14.7932 1.14584 15.8996 1.14584 17.061V18.3911C1.14609 18.8042 1.31037 19.2003 1.60259 19.4924C1.89481 19.7844 2.29104 19.9485 2.70418 19.9485L9.62501 19.9494C9.80735 19.9494 9.98221 19.877 10.1111 19.748C10.2401 19.6191 10.3125 19.4443 10.3125 19.2619C10.3125 19.0796 10.2401 18.9047 10.1111 18.7758C9.98221 18.6468 9.80735 18.5744 9.62501 18.5744ZM10.5417 1.14583C7.75868 1.14583 5.50001 3.4045 5.50001 6.1875C5.50001 8.9705 7.75868 11.2292 10.5417 11.2292C13.3247 11.2292 15.5833 8.9705 15.5833 6.1875C15.5833 3.4045 13.3247 1.14583 10.5417 1.14583ZM10.5417 2.52083C12.5657 2.52083 14.2083 4.1635 14.2083 6.1875C14.2083 8.2115 12.5657 9.85416 10.5417 9.85416C8.51768 9.85416 6.87501 8.2115 6.87501 6.1875C6.87501 4.1635 8.51768 2.52083 10.5417 2.52083Z" fill="#1C1C1E"/>
                                                        <path d="M16.6393 18.524C17.2592 18.618 17.8928 18.5515 18.4796 18.3311C19.0665 18.1106 19.5871 17.7434 19.9918 17.2646C20.3965 16.7858 20.6717 16.2112 20.7913 15.5958C20.9109 14.9804 20.8707 14.3446 20.6748 13.7491C20.4788 13.1536 20.1335 12.6182 19.6719 12.194C19.2102 11.7698 18.6476 11.471 18.0377 11.326C17.4277 11.1811 16.7908 11.1948 16.1877 11.3659C15.5846 11.537 15.0353 11.8598 14.5924 12.3035C14.186 12.7095 13.8807 13.2053 13.7013 13.751C13.5218 14.2967 13.4732 14.877 13.5593 15.4449L11.4308 17.5725C11.3669 17.6364 11.3161 17.7123 11.2815 17.7958C11.2469 17.8793 11.2291 17.9688 11.2292 18.0593V20.1667C11.2292 20.5462 11.5372 20.8542 11.9167 20.8542H14.0241C14.1145 20.8542 14.204 20.8364 14.2875 20.8018C14.3711 20.7672 14.4469 20.7165 14.5108 20.6525L16.6393 18.524ZM16.5917 17.1123C16.4753 17.0813 16.3528 17.0814 16.2365 17.1127C16.1202 17.1439 16.0141 17.2051 15.9289 17.2902L13.7399 19.4792H12.6042V18.3434L14.7932 16.1544C14.8782 16.0692 14.9395 15.9631 14.9707 15.8468C15.0019 15.7305 15.002 15.608 14.971 15.4917C14.8415 15.0042 14.8762 14.4878 15.0697 14.022C15.2632 13.5563 15.6046 13.1672 16.0413 12.915C16.478 12.6627 16.9857 12.5613 17.4858 12.6264C17.9859 12.6915 18.4506 12.9195 18.8082 13.2752C19.1638 13.6327 19.3918 14.0975 19.4569 14.5976C19.522 15.0977 19.4206 15.6053 19.1684 16.042C18.9161 16.4787 18.5271 16.8202 18.0613 17.0136C17.5956 17.2071 17.0791 17.2418 16.5917 17.1123Z" fill="#FFA920"/>
                                                        <path d="M16.4835 15.5998C16.3877 15.5083 16.3111 15.3984 16.2583 15.2768C16.2055 15.1552 16.1775 15.0243 16.1761 14.8917C16.1746 14.7592 16.1996 14.6276 16.2497 14.5049C16.2998 14.3822 16.374 14.2707 16.4678 14.177C16.5616 14.0833 16.6732 14.0093 16.796 13.9594C16.9188 13.9095 17.0503 13.8846 17.1829 13.8862C17.3154 13.8879 17.4463 13.916 17.5679 13.9689C17.6894 14.0219 17.7991 14.0986 17.8906 14.1946C18.0698 14.3826 18.1683 14.6333 18.1651 14.893C18.1619 15.1527 18.0572 15.4009 17.8734 15.5845C17.6896 15.768 17.4413 15.8724 17.1816 15.8752C16.9219 15.8781 16.6713 15.7793 16.4835 15.5998Z" fill="#FFA920"/>
                                                    </svg>
                                                </li>
                                                <li class=""><a href="#" data-toggle="modal" data-target="#popup_bid2">Register</a></li>
                                                <li><span>/</span></li>
                                                <li class=""><a href="#" data-toggle="modal" data-target="#popup_bid"> Login</a></li>
                                            </ul>
                                        </div> -->
                                        <div class="flat-bt-top sc-btn-top">
                                            <a class="sc-button btn-icon " href="#"  data-toggle="modal" data-target="#popup_bid2">
                                                <!--<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">-->
                                                <!--    <path d="M13.25 15.75V15H11.375C10.7547 15 10.25 14.4953 10.25 13.875V12.375C10.25 11.7547 10.7547 11.25 11.375 11.25H11.75V10.5H13.25V11.25H14C14.1989 11.25 14.3897 11.329 14.5303 11.4697C14.671 11.6103 14.75 11.8011 14.75 12C14.75 12.1989 14.671 12.3897 14.5303 12.5303C14.3897 12.671 14.1989 12.75 14 12.75H11.75V13.5H13.625C14.2453 13.5 14.75 14.0047 14.75 14.625V16.125C14.75 16.7453 14.2453 17.25 13.625 17.25H13.25V18H11.75V17.25H11C10.8011 17.25 10.6103 17.171 10.4697 17.0303C10.329 16.8897 10.25 16.6989 10.25 16.5C10.25 16.3011 10.329 16.1103 10.4697 15.9697C10.6103 15.829 10.8011 15.75 11 15.75H13.25Z" fill="white"/>-->
                                                <!--    <path d="M22.469 10.6447L14.315 2.96925C13.8234 2.50736 13.1742 2.25024 12.4996 2.25024C11.825 2.25024 11.1759 2.50736 10.6842 2.96925L8.74998 4.791V3C8.74998 2.80109 8.67096 2.61032 8.53031 2.46967C8.38966 2.32902 8.19889 2.25 7.99998 2.25H4.99998C4.80107 2.25 4.6103 2.32902 4.46965 2.46967C4.329 2.61032 4.24998 2.80109 4.24998 3V9.027L2.55273 10.6252C2.03748 11.0722 1.86348 11.784 2.10798 12.4387C2.34873 13.0837 2.93823 13.5 3.60948 13.5H4.24998V21C4.24998 21.1989 4.329 21.3897 4.46965 21.5303C4.6103 21.671 4.80107 21.75 4.99998 21.75H20C20.1989 21.75 20.3897 21.671 20.5303 21.5303C20.671 21.3897 20.75 21.1989 20.75 21V13.5H21.389C22.061 13.5 22.6512 13.083 22.892 12.438C23.1357 11.7832 22.961 11.0715 22.469 10.6447ZM5.74998 3.75H7.24998V6.2025L5.74998 7.61475V3.75ZM21.4865 11.9138C21.4542 12 21.4047 12 21.389 12H20C19.8011 12 19.6103 12.079 19.4697 12.2197C19.329 12.3603 19.25 12.5511 19.25 12.75V20.25H5.74998V12.75C5.74998 12.5511 5.67096 12.3603 5.53031 12.2197C5.38966 12.079 5.19889 12 4.99998 12H3.60948C3.59373 12 3.54498 12 3.51273 11.9138C3.50022 11.8834 3.49792 11.8498 3.50617 11.818C3.51442 11.7862 3.53278 11.7579 3.55848 11.7375L11.7125 4.062C11.9257 3.86178 12.2071 3.75032 12.4996 3.75032C12.7921 3.75032 13.0735 3.86178 13.2867 4.062L21.4625 11.7578C21.5187 11.8058 21.4977 11.883 21.4865 11.9138Z" fill="white"/>-->
                                                <!--</svg>-->
                                                <span>Get your Offers</span>
                                            </a>
                                        </div>  
                                    </div> 
                                    
                                    <div class="mobile-nav-toggler mobile-button"><span></span></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Header Lower -->
            
                <!-- Mobile Menu  -->
                <div class="close-btn"><span class="icon flaticon-cancel-1"></span></div>    
                <div class="mobile-menu">
                    <div class="menu-backdrop"></div>                            
                    <nav class="menu-box">
                        <div class="nav-logo"><a href="home"><img src="assets/images/logo/log 4.webp" alt="" width="197" height="48"></a></div>
                        <div class="bottom-canvas">
                            <!-- <div class="login-box flex align-center">
                                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.62501 18.5744H2.70418C2.65555 18.5744 2.60892 18.5551 2.57454 18.5207C2.54016 18.4863 2.52084 18.4397 2.52084 18.3911V17.0619C2.52084 16.3002 3.06443 15.6292 3.90226 15.059C5.39826 14.0378 7.81918 13.3943 10.5417 13.3943C10.9908 13.3943 11.4318 13.4127 11.8626 13.4466C11.9537 13.4558 12.0457 13.4466 12.1332 13.4198C12.2207 13.3929 12.3019 13.3489 12.3722 13.2902C12.4424 13.2315 12.5003 13.1594 12.5423 13.0781C12.5843 12.9968 12.6097 12.9079 12.6169 12.8166C12.6241 12.7254 12.613 12.6336 12.5842 12.5467C12.5555 12.4598 12.5097 12.3795 12.4495 12.3105C12.3893 12.2416 12.316 12.1853 12.2338 12.1451C12.1516 12.1048 12.0621 12.0814 11.9708 12.0762C11.4954 12.038 11.0186 12.0191 10.5417 12.0193C7.49651 12.0193 4.80059 12.7811 3.12676 13.9223C1.84984 14.7932 1.14584 15.8996 1.14584 17.061V18.3911C1.14609 18.8042 1.31037 19.2003 1.60259 19.4924C1.89481 19.7844 2.29104 19.9485 2.70418 19.9485L9.62501 19.9494C9.80735 19.9494 9.98221 19.877 10.1111 19.748C10.2401 19.6191 10.3125 19.4443 10.3125 19.2619C10.3125 19.0796 10.2401 18.9047 10.1111 18.7758C9.98221 18.6468 9.80735 18.5744 9.62501 18.5744ZM10.5417 1.14583C7.75868 1.14583 5.50001 3.4045 5.50001 6.1875C5.50001 8.9705 7.75868 11.2292 10.5417 11.2292C13.3247 11.2292 15.5833 8.9705 15.5833 6.1875C15.5833 3.4045 13.3247 1.14583 10.5417 1.14583ZM10.5417 2.52083C12.5657 2.52083 14.2083 4.1635 14.2083 6.1875C14.2083 8.2115 12.5657 9.85416 10.5417 9.85416C8.51768 9.85416 6.87501 8.2115 6.87501 6.1875C6.87501 4.1635 8.51768 2.52083 10.5417 2.52083Z" fill="#1C1C1E"/>
                                    <path d="M16.6393 18.524C17.2592 18.618 17.8928 18.5515 18.4796 18.3311C19.0665 18.1106 19.5871 17.7434 19.9918 17.2646C20.3965 16.7858 20.6717 16.2112 20.7913 15.5958C20.9109 14.9804 20.8707 14.3446 20.6748 13.7491C20.4788 13.1536 20.1335 12.6182 19.6719 12.194C19.2102 11.7698 18.6476 11.471 18.0377 11.326C17.4277 11.1811 16.7908 11.1948 16.1877 11.3659C15.5846 11.537 15.0353 11.8598 14.5924 12.3035C14.186 12.7095 13.8807 13.2053 13.7013 13.751C13.5218 14.2967 13.4732 14.877 13.5593 15.4449L11.4308 17.5725C11.3669 17.6364 11.3161 17.7123 11.2815 17.7958C11.2469 17.8793 11.2291 17.9688 11.2292 18.0593V20.1667C11.2292 20.5462 11.5372 20.8542 11.9167 20.8542H14.0241C14.1145 20.8542 14.204 20.8364 14.2875 20.8018C14.3711 20.7672 14.4469 20.7165 14.5108 20.6525L16.6393 18.524ZM16.5917 17.1123C16.4753 17.0813 16.3528 17.0814 16.2365 17.1127C16.1202 17.1439 16.0141 17.2051 15.9289 17.2902L13.7399 19.4792H12.6042V18.3434L14.7932 16.1544C14.8782 16.0692 14.9395 15.9631 14.9707 15.8468C15.0019 15.7305 15.002 15.608 14.971 15.4917C14.8415 15.0042 14.8762 14.4878 15.0697 14.022C15.2632 13.5563 15.6046 13.1672 16.0413 12.915C16.478 12.6627 16.9857 12.5613 17.4858 12.6264C17.9859 12.6915 18.4506 12.9195 18.8082 13.2752C19.1638 13.6327 19.3918 14.0975 19.4569 14.5976C19.522 15.0977 19.4206 15.6053 19.1684 16.042C18.9161 16.4787 18.5271 16.8202 18.0613 17.0136C17.5956 17.2071 17.0791 17.2418 16.5917 17.1123Z" fill="#FFA920"/>
                                    <path d="M16.4835 15.5998C16.3877 15.5083 16.3111 15.3984 16.2583 15.2768C16.2055 15.1552 16.1775 15.0243 16.1761 14.8917C16.1746 14.7592 16.1996 14.6276 16.2497 14.5049C16.2998 14.3822 16.374 14.2707 16.4678 14.177C16.5616 14.0833 16.6732 14.0093 16.796 13.9594C16.9188 13.9095 17.0503 13.8846 17.1829 13.8862C17.3154 13.8879 17.4463 13.916 17.5679 13.9689C17.6894 14.0219 17.7991 14.0986 17.8906 14.1946C18.0698 14.3826 18.1683 14.6333 18.1651 14.893C18.1619 15.1527 18.0572 15.4009 17.8734 15.5845C17.6896 15.768 17.4413 15.8724 17.1816 15.8752C16.9219 15.8781 16.6713 15.7793 16.4835 15.5998Z" fill="#FFA920"/>
                                </svg>
                                <a href="#" data-toggle="modal" data-target="#popup_bid" class="fw-7 font-2">Login</a>
                            </div> -->
                            <div class="menu-outer"></div>
                            <div class="button-mobi-sell">
                                <!-- <a class="sc-button btn-icon center" href="properties-list.html">
                                    <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.25 15.75V15H11.375C10.7547 15 10.25 14.4953 10.25 13.875V12.375C10.25 11.7547 10.7547 11.25 11.375 11.25H11.75V10.5H13.25V11.25H14C14.1989 11.25 14.3897 11.329 14.5303 11.4697C14.671 11.6103 14.75 11.8011 14.75 12C14.75 12.1989 14.671 12.3897 14.5303 12.5303C14.3897 12.671 14.1989 12.75 14 12.75H11.75V13.5H13.625C14.2453 13.5 14.75 14.0047 14.75 14.625V16.125C14.75 16.7453 14.2453 17.25 13.625 17.25H13.25V18H11.75V17.25H11C10.8011 17.25 10.6103 17.171 10.4697 17.0303C10.329 16.8897 10.25 16.6989 10.25 16.5C10.25 16.3011 10.329 16.1103 10.4697 15.9697C10.6103 15.829 10.8011 15.75 11 15.75H13.25Z" fill="white"/>
                                        <path d="M22.469 10.6447L14.315 2.96925C13.8234 2.50736 13.1742 2.25024 12.4996 2.25024C11.825 2.25024 11.1759 2.50736 10.6842 2.96925L8.74998 4.791V3C8.74998 2.80109 8.67096 2.61032 8.53031 2.46967C8.38966 2.32902 8.19889 2.25 7.99998 2.25H4.99998C4.80107 2.25 4.6103 2.32902 4.46965 2.46967C4.329 2.61032 4.24998 2.80109 4.24998 3V9.027L2.55273 10.6252C2.03748 11.0722 1.86348 11.784 2.10798 12.4387C2.34873 13.0837 2.93823 13.5 3.60948 13.5H4.24998V21C4.24998 21.1989 4.329 21.3897 4.46965 21.5303C4.6103 21.671 4.80107 21.75 4.99998 21.75H20C20.1989 21.75 20.3897 21.671 20.5303 21.5303C20.671 21.3897 20.75 21.1989 20.75 21V13.5H21.389C22.061 13.5 22.6512 13.083 22.892 12.438C23.1357 11.7832 22.961 11.0715 22.469 10.6447ZM5.74998 3.75H7.24998V6.2025L5.74998 7.61475V3.75ZM21.4865 11.9138C21.4542 12 21.4047 12 21.389 12H20C19.8011 12 19.6103 12.079 19.4697 12.2197C19.329 12.3603 19.25 12.5511 19.25 12.75V20.25H5.74998V12.75C5.74998 12.5511 5.67096 12.3603 5.53031 12.2197C5.38966 12.079 5.19889 12 4.99998 12H3.60948C3.59373 12 3.54498 12 3.51273 11.9138C3.50022 11.8834 3.49792 11.8498 3.50617 11.818C3.51442 11.7862 3.53278 11.7579 3.55848 11.7375L11.7125 4.062C11.9257 3.86178 12.2071 3.75032 12.4996 3.75032C12.7921 3.75032 13.0735 3.86178 13.2867 4.062L21.4625 11.7578C21.5187 11.8058 21.4977 11.883 21.4865 11.9138Z" fill="white"/>
                                    </svg>
                                    <span>Sell Property</span>
                                </a> -->
                            </div> 
                            <div class="mobi-icon-box">
                                <h3>Contact</h3>
                                <div class="box flex">
                                    <div class="icon">
                                        <svg width="40" height="41" viewBox="0 0 50 51" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M26.4648 13.7812C26.4648 14.5902 27.1207 15.2461 27.9297 15.2461C28.7387 15.2461 29.3945 14.5902 29.3945 13.7812C29.3945 12.9723 28.7387 12.3164 27.9297 12.3164C27.1207 12.3164 26.4648 12.9723 26.4648 13.7812Z" fill="#E5E5EA"></path>
                                            <path d="M32.3242 13.7812C32.3242 14.5902 32.9801 15.2461 33.7891 15.2461C34.598 15.2461 35.2539 14.5902 35.2539 13.7812C35.2539 12.9723 34.598 12.3164 33.7891 12.3164C32.9801 12.3164 32.3242 12.9723 32.3242 13.7812Z" fill="#E5E5EA"></path>
                                            <path d="M38.1836 13.7812C38.1836 14.5902 38.8395 15.2461 39.6484 15.2461C40.4574 15.2461 41.1133 14.5902 41.1133 13.7812C41.1133 12.9723 40.4574 12.3164 39.6484 12.3164C38.8395 12.3164 38.1836 12.9723 38.1836 13.7812Z" fill="#E5E5EA"></path>
                                            <path d="M22.6771 37.2188L27.0716 34.2891L35.8398 37.2188V43.0781C35.8398 44.6961 34.549 46.0078 32.931 46.0078C16.7508 46.0078 1.46484 30.8195 1.46484 14.6394C1.46484 13.0214 2.77656 11.7305 4.39453 11.7305H10.2539L13.1836 20.4987L10.2539 24.8933C12.1247 29.5703 18 35.3479 22.6771 37.2188Z" stroke="#E5E5EA" stroke-width="1.7" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M19.1406 13.7812C19.1406 18.6354 23.0756 22.5703 27.9297 22.5703V28.4297L33.7891 22.5703H39.6484C44.5025 22.5703 48.5352 18.6354 48.5352 13.7812C48.5352 8.92715 44.5025 4.99219 39.6484 4.99219H27.9297C23.0756 4.99219 19.1406 8.92715 19.1406 13.7812Z" stroke="#E5E5EA" stroke-width="1.7" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                    <div class="content fs-13">
                                        Call us: <h5>+91 7293100100</h5>
                                    </div>
                                </div>
                                <div class="box flex">
                                    <div class="icon">
                                        <svg width="40" height="40" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M36.6559 17.8341L36.6559 17.8341L36.6609 17.8392C36.8315 18.0113 37.0549 18.0969 37.2788 18.0969C37.5021 18.0969 37.7258 18.0116 37.8976 17.8411C38.2409 17.5005 38.241 16.9425 37.8996 16.5985C37.5586 16.2548 37.0037 16.2526 36.66 16.5934L36.6559 17.8341ZM36.6559 17.8341L36.6551 17.8332M36.6559 17.8341L36.6551 17.8332M36.6551 17.8332C36.3141 17.4895 36.3163 16.9345 36.66 16.5935L36.6551 17.8332Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M46.4639 27.8825H46.7054L46.5346 27.7118L39.3343 20.5115C38.992 20.1691 38.992 19.6141 39.3343 19.2718C39.6767 18.9296 40.2317 18.9296 40.574 19.2718L49.6441 28.3419C49.8085 28.5063 49.9009 28.7294 49.901 28.9618C49.901 29.1943 49.8086 29.4172 49.6442 29.5816L34.0757 45.1502C33.9114 45.3145 33.6884 45.4069 33.4559 45.4069C33.2235 45.4069 33.0005 45.3145 32.8361 45.1502L9.34306 21.6572C9.34306 21.6572 9.34305 21.6572 9.34305 21.6572C9.00075 21.3148 9.00076 20.7598 9.34305 20.4175L24.9114 4.84884C25.2537 4.50664 25.8087 4.50664 26.151 4.84884C26.151 4.84884 26.151 4.84884 26.1511 4.84884L34.9723 13.67C35.3146 14.0124 35.3146 14.5675 34.9723 14.9098C34.6299 15.252 34.0749 15.2519 33.7326 14.9098L26.7811 7.95839L26.6104 7.78768V8.0291V25.1994C26.6104 26.679 27.8139 27.8825 29.2935 27.8825H46.4639ZM24.8575 7.62373V7.38231L24.6868 7.55302L12.2497 19.9901L12.079 20.1608H12.3204H24.7575H24.8575V20.0608V7.62373ZM32.4087 42.2434L32.5794 42.4141V42.1727V29.7356V29.6356H32.4794H29.2937C26.8477 29.6356 24.8575 27.6455 24.8575 25.1994V22.0139V21.9139H24.7575H12.3204H12.079L12.2497 22.0846L32.4087 42.2434ZM34.3324 42.1728V42.4142L34.5031 42.2435L46.9401 29.8064L47.1108 29.6356H46.8694H34.4324H34.3324V29.7356V42.1728Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M0.976562 24.9047H6.70225C7.18637 24.9047 7.57881 25.2972 7.57881 25.7812C7.57881 26.2654 7.18637 26.6578 6.70225 26.6578H0.976562C0.492442 26.6578 0.1 26.2653 0.1 25.7812C0.1 25.2972 0.492442 24.9047 0.976562 24.9047Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M9.59961 24.9047H9.61426C10.0984 24.9047 10.4908 25.2972 10.4908 25.7812C10.4908 26.2653 10.0984 26.6578 9.61426 26.6578H9.59961C9.11549 26.6578 8.72305 26.2653 8.72305 25.7812C8.72305 25.2972 9.11549 24.9047 9.59961 24.9047Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M0.978516 14.6508H4.10381C4.58793 14.6508 4.98037 15.0433 4.98037 15.5273C4.98037 16.0114 4.58793 16.4039 4.10381 16.4039H0.978516C0.494395 16.4039 0.101953 16.0114 0.101953 15.5273C0.101953 15.0433 0.494395 14.6508 0.978516 14.6508Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M7.29315 14.6508H10.9873C11.4714 14.6508 11.8639 15.0433 11.8639 15.5273C11.8639 16.0114 11.4714 16.4039 10.9873 16.4039H7.29315C6.80903 16.4039 6.41659 16.0114 6.41659 15.5273C6.41659 15.0433 6.80903 14.6508 7.29315 14.6508Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M7.64453 30.2758H13.1132C13.5972 30.2758 13.9897 30.6683 13.9897 31.1523C13.9897 31.6364 13.5973 32.0289 13.1132 32.0289H7.64453C7.16041 32.0289 6.76797 31.6364 6.76797 31.1523C6.76797 30.6683 7.16041 30.2758 7.64453 30.2758Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                            <path d="M3.61328 36.5258H17.3827C17.8668 36.5258 18.2593 36.9183 18.2593 37.4023C18.2593 37.8864 17.8668 38.2789 17.3827 38.2789H3.61328C3.12916 38.2789 2.73672 37.8864 2.73672 37.4023C2.73672 36.9183 3.12916 36.5258 3.61328 36.5258Z" fill="#E5E5EA" stroke="white" stroke-width="0.2"></path>
                                        </svg>
                                    </div>
                                    <div class="content fs-13 lh-16">
                                        Email: <h5><a href="/cdn-cgi/l/email-protection#90f9fef6ffd0e3e5fdf9e2f1fde3f1f9e2f5f1fce4ffe2e3bef3fffd" class="__cf_email__" data-cfemail="0e7a666b636b7d68626f7a4e69636f6762206d6163"><span class="__cf_email__" data-cfemail="3c55525a537c4f4951554e5d514f5d554e595d5048534e4f125f5351">[email&#160;protected]</span></a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>                
                </div>
                <!-- End Mobile Menu -->
            
            </header>
              
  
            <section class="flat-title " >
                <div class="container">
                    <div class="row">                      
                        <div class="col-lg-12">
                            <div class="title-inner style">
                                <div class="title-group fs-12"><a class="home fw-6 text-color-3" href="home">Home</a><span >Invest Commercial</span></div>
                            </div>
                        </div> 
                    </div>
                </div>
            </section>
            <section class="flat-agent-detail wg-tabs flat-agent flat-agent-sidebar " >
                <div class="container">
                    <div class="row flex">                      
                        <div class="col-lg-12">
                            <div class="post">
                            <div class="box flex ">
                                <div class="relative flex-none ">
                                    <img src="https://sumiramsairealtors.com/assets/images/invest commercial/1.jpg" alt="invest in commercial">
                                </div>
                                <div class="content" style="padding: 5px;">
                                    <h6 style="font-weight:20px; font-size:30px !important;">Commercial Investment in Noida</h6>
                                    <p class="text-1 text-color-2">Welcome to Sumiram Sai Realtors! We're here to help you find the perfect commercial space in Noida. We pride ourselves on creating amazing real estate experiences just for you. Noida is full of opportunities, and Sumiram Sai Realtors offers a variety of projects. From modern office spaces to lively retail properties, we're the go-to for commercial investments in the area. Step into the future with our well-designed office spaces that balance style and functionality. We understand how important the workplace is for creativity and productivity. Experience the vibrant energy of Noida's business hubs with our retail properties. We provide prime locations that guarantee high foot traffic, ensuring the success of your business. Explore investment opportunities with us! Our portfolio reflects Noida's economic growth. We guide you towards secure investments aligned with commercial real estate trends. Put your business at the core of Noida's bustling hubs. We strategically select locations that foster collaboration and growth for your enterprise.</p>
                                </div>
                            </div> 
                            <div class="box flex ">
                                <div class="relative flex-none ">
                                    <img src="https://sumiramsairealtors.com/assets/images/invest commercial/xconvert.com (1).webp" alt="invest in commercial">
                                </div>
                                    <div class="content" style="padding: 5px;">
                                        <h6>High Return Investment</h6>
                                        <p class="text-1 text-color-2">High-return investments can vary depending on individual risk tolerance, investment goals, and market conditions. However, some investment options commonly associated with potentially high returns include:
    
                                    Commercila Real Estate: Buying properties in appreciating areas or investing in real estate investment trusts (REITs) can yield high returns through rental income and property appreciation.</p>
                                     <p class="text-1 text-color-2">
                                    Investing in commercial property can offer potentially high returns due to various factors. Commercial properties, such as office buildings, retail spaces, and industrial warehouses, generate rental income from tenants, providing a steady cash flow. Additionally, commercial leases often include provisions for rent escalation, which can increase income over time.
                                    
                                    Moreover, commercial properties have the potential for capital appreciation as their value typically increases with economic growth and development in the area. Strategic location, accessibility, and amenities also contribute to the property's value appreciation.
                                    </p>
                                
                                    </div>  
                            <!--</div>-->
                                </div>
                                <div class="box-text">
                                <p class="text-1 text-color-2">Furthermore, commercial properties can benefit from economies of scale, especially when investing in larger properties or portfolios. This can lead to higher returns as operational costs spread across multiple tenants.
                                However, investing in commercial property requires careful consideration of factors such as location, market demand, tenant quality, and lease terms. It also involves significant upfront capital, ongoing maintenance costs, and potential vacancies.
                                
                                To maximize returns, investors should conduct thorough due diligence, assess market trends, and seek professional guidance. Despite the potential for high returns, commercial property investment carries risks, including economic downturns, changes in market conditions, and regulatory challenges. Therefore, diversification and a long-term investment horizon are essential for success in this asset class</p>                               </div>
                                </p>
                              </div>

                            <div class="box-text">
                                <h3>Why Should We Invest in Commercial Property in Noida?</h3>
                                <div class="box flex ">
                                    <div class="relative flex-none ">
                                        <img src="https://sumiramsairealtors.com/assets/images/invest commercial/xconvert.com (2).webp" alt="invest in commercial">
                                    </div>
                                    <div class="content" style="padding: 5px;">
                                        <h6></h6>
                                <p class="text-1 text-color-2">Strategic Location: Noida's strategic location near Delhi and its well-connected transportation network make it an attractive destination for businesses. Its proximity to major highways and the Delhi Metro system enhances accessibility, drawing companies to establish their presence in the area.</p>
                                 <h6></h6>
                                <p class="text-1 text-color-2">Booming Economy: Noida has a thriving economy driven by sectors such as IT, manufacturing, and real estate. The city's robust economic growth translates into increased demand for commercial spaces, creating opportunities for investors to benefit from rising property values and rental income.</p>
                                <p class="text-1 text-color-2">Government Support: The local government of Noida actively promotes business and investment in the region through policies that facilitate ease of doing business, streamlined approval processes, and infrastructure development initiatives. This favorable business environment encourages companies to invest in commercial properties and contributes to the city's growth.</p>
                                    </div>
                                </div> 
                                <!-- <div class="relative flex-none ">
                                    <img src="https://sumiramsairealtors.com/assets/images/invest commercial/xconvert.com (2).webp" alt="invest in commercial">
                                </div> -->
                              
                                 <h6>Proximity conected by all majer city:</h6>
                                <p class="text-1 text-color-2">Noida's proximity conected to Delhi, enhances its economic and investment potential. The city's strategic location and well-connected transportation networks can attract businesses, leading to increased demand for commercial spaces and residential properties.
                                </p>
                                 <h6>IT Hub and Business Centers:</h6>
                                <p class="text-1 text-color-2">Noida is known for its thriving IT and business sectors. The presence of multinational companies, tech parks, and business centers can result in steady demand for commercial properties such as office spaces and retail outlets.sumiram sai realtors are providing all service.
                                </p>
                                 <h6>Educational and Healthcare Facilities:</h6>
                                <p class="text-1 text-color-2">Noida hosts renowned educational institutions and healthcare facilities, making it an attractive location for Businessman. This can drive demand for residential properties as people seek quality education and medical services for their families.
                                </p>
                                <h6>Infrastructure and Connectivity:</h6>
                                <p class="text-1 text-color-2">The city has benefited from substantial infrastructure development, including metro connectivity, expressways, and modern amenities. Good infrastructure often contributes to the appreciation of property values and can attract businesses and residents.
                                </p>
                                 <h6>Investing in commercial real estate:</h6>
                                <p class="text-1 text-color-2">often requires a significant amount of money, which can be a hurdle for individual retail investors. However, there are smart ways to get into commercial real estate that make it accessible to more people. One popular method is through real estate investment trusts or fractional ownership. These options allow you to invest in commercial real estate without needing a huge sum of money upfront. But remember, just because the investment is smaller doesn't mean it's not a good opportunity. Commercial real estate investments have some unique advantages over traditional investments. Unlike some investments that are heavily influenced by market fluctuations, commercial real estate tends to be more stable. It can provide a consistent rate of return over the long term. commercial investments often come with a lock-in period. This means your money is protected, and you can count on returns during this time. If you invest in special-purpose commercial real estate in a prime location, it can be like striking gold. These properties are highly sought after by specific types of tenants, ensuring a steady stream of passive income for you. In simple terms, commercial real estate investment offers a chance to get into the real estate game without needing a lot of money upfront. It's a stable, secure way to grow your wealth, and if you pick the right property, it can be a gold mine of income for years to come.
                                </p>
                                 <h6>Commercial and Retail Opportunities:</h6>
                                <p class="text-1 text-color-2">Noida's growth has led to a rising demand for shopping centers, malls, and entertainment facilities. Investing in commercial properties like retail spaces can offer steady rental income and potential for value appreciation.
                                </p>
                                <h6>Investment Potential:</h6>
                                <p class="text-1 text-color-2">Noida's real estate market has shown potential for capital appreciation over the years. As the city continues to develop and attract investments, property values may increase, offering opportunities for profitable resale.

                            </div>
    
                            <div class="box-text">
                                <h3>Commercial Investments In Noida</h3>
                                <br>
                                <div class="box flex ">
                                    <div class="relative flex-none ">
                                        <img src="https://sumiramsairealtors.com/assets/images/invest commercial/xconvert.com.webp" alt="invest in commercial">
                                    </div>
                                    <div class="content" style="padding: 5px;">
                                        
                                        <p class="text-1 text-color-2">Thriving Business Environment: Noida is a major hub for IT and other businesses, which creates a strong demand for office space.expand_more The city also has a growing population with rising spending power, making retail spaces attractive.expand_more
Government Incentives: The government offers various policies and tax benefits to encourage investment in Noida, making it more financially attractive for businesses to set up shop there. This can in turn benefit commercial property owners.
Infrastructure Development: Noida has good infrastructure with reliable power, water supply, 

                                            <br>
                                        </p>
                                        <p class="text-color-2">Evaluate the location of commercial properties in terms of accessibility, proximity to transportation hubs, and connectivity to major roads and highways. Noida's connectivity to Delhi through the Delhi Metro and road networks is a significant advantage.</p>
                                        </div>
                                </div>     
                               
                                <p class="text-1 text-color-2">and transportation facilities.expand_more This makes it a practical location for businesses to function smoothly.
Potential for Appreciation: The real estate market in Noida has been on an upswing, and commercial property prices are expected to rise further. This means you could potentially see good returns on your investment over time. Here are some things to consider before you invest:
Type of Property: Decide whether you want to invest in office space, retail space, or something else. Each type of property has its own risk-reward profile.
Location: Noida has different sectors, and some may be more suitable for business than others.expand_more Consider factors like proximity to major roads, public transport, and existing businesses.
Market Research: Do your research on current market trends, rental yields, and vacancy rates. This will help you understand the potential returns and risks involved.
Reputed Builder: Choose a reputable builder with a good track record for quality construction and timely delivery.
</p>
                                
                                <h6>Pre leased property for sale noida | Greater noida</h6>
                                <p class="text-1 text-color-2">if you looking the pre leased property for sale noida sumiram sai realtors has best project for you like galactic city and londonmart. both are projetc in greater noida.Find Preleased Property in Noida within your budget on sumiramsai realtors India's No.1 Real Estate company Get complete details of property specifications.

                            </div>
                            <div class="box flex ">
                                <div class="content ">
                                    <div class="titles fs-22 fw-7 lh-33">Unlocking Prosperity: Your Ultimate Guide to the Best Commercial Investments with Sumiram Sai Realtors-</div>
                                    <p class="text-1 text-color-2">In the dynamic landscape of real estate, the quest for the best commercial investment is a journey that demands careful consideration and strategic planning. This aims to be your compass in navigating the realm of commercial real estate investments, and why Sumiram Sai Realtors emerges as the guiding you towards financial success. Commercial real estate investments hold the promise of a robust financial future, offering a direct way of steady cash flow, property appreciation, and advantageous tax benefits. Whether you are a seasoned investor or a newcomer, making informed choices is paramount for sustained success in this competitive field.</p>
                                    <!-- <div class="sub-text flex"><p class="">Location:</p><span class="fw-7 font-2 text-color-2">Our commercial land parcels are strategically situated in some of the most sought-after areas, ensuring high visibility, easy access,
                                    and proximity to major transportation hubs. Whether you're looking to establish a retail store, office space, or a manufacturing facility, our properties are strategically located to cater to your specific business needs.</span></div> -->
                                </div>
                                <div class="images relative flex-none ">
                                    <img src="https://sumiramsairealtors.com/assets/images/img-box/agents-detail.jpg" alt="commercial space ">
                                </div>
                            </div>
                            <div class="box flex ">
                                <div class="images relative flex-none ">
                                    <img src="https://sumiramsairealtors.com/assets/images/img-box/REAL6.jpg" alt="commercial property noida">
                                </div>
                                <div class="content ">
                                    <!-- <div class="titles fs-22 fw-7 lh-33">Introducing the Perfect Opportunity: Commercial Land by Sumiram Sai Realtors</div> -->
                                    <p class="text-1 text-color-2">Sumiram Sai Realtors takes pride in offering a diverse portfolio of commercial properties, vary from retail spaces and offices to industrial units. This diversity allows investors to choose https://sumiramsairealtors.com/assets that align precisely with their goals and preferences.
                                        Understanding the growth potential and anticipating future trends are essential in the ever-evolving commercial real estate landscape. Sumiram Sai Realtors takes the lead in providing investors with insights into emerging markets. Begin Your Journey to Prosperity your path to financial success in commercial real estate begins with Sumiram Sai Realtors. With a commitment to excellence, a strategic approach, and a diverse portfolio, they stand as the epitome of the ideal partner for the best commercial investments. Propel yourself towards financial security and wealth-building with confidence in the dynamic world of commercial real estate, guided by the expertise of Sumiram Sai Realtors.</p>
                                    <!-- <div class="sub-text flex"><p class="">Location:</p><span class="fw-7 font-2 text-color-2">Our commercial land parcels are strategically situated in some of the most sought-after areas, ensuring high visibility, easy access,
                                    and proximity to major transportation hubs. Whether you're looking to establish a retail store, office space, or a manufacturing facility, our properties are strategically located to cater to your specific business needs.</span></div> -->
                                </div>
                            </div>
                        </div>                
                    </div>
                </div>
            </section>
            <div class="chat-button">
    <a href="tel:+917293100100">
  <img src="assets/images/phone.gif" alt="Chat">
  </a>
</div>
<section class="flat-contact2 relative" >
                    <div class="container">
                        <div class="row">                      
                            <div class="col-lg-12">
                                <div class="heading-section">
                                    <h2>Find for your dream commercial spaces and increase your investment opportunities</h2>
                                    <p class="text-color-2 font-2"> We strive to be different in the market and go the extra mile when it comes to personal and professional coustomer services.</p>
                                    <div class="button-footer">
                                        <a class="sc-button center btn-icon" href="#" data-toggle="modal" data-target="#popup_bid2">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2.25 6.75C2.25 15.034 8.966 21.75 17.25 21.75H19.5C20.0967 21.75 20.669 21.5129 21.091 21.091C21.5129 20.669 21.75 20.0967 21.75 19.5V18.128C21.75 17.612 21.399 17.162 20.898 17.037L16.475 15.931C16.035 15.821 15.573 15.986 15.302 16.348L14.332 17.641C14.05 18.017 13.563 18.183 13.122 18.021C11.4849 17.4191 9.99815 16.4686 8.76478 15.2352C7.53141 14.0018 6.58087 12.5151 5.979 10.878C5.817 10.437 5.983 9.95 6.359 9.668L7.652 8.698C8.015 8.427 8.179 7.964 8.069 7.525L6.963 3.102C6.90214 2.85869 6.76172 2.6427 6.56405 2.48834C6.36638 2.33397 6.1228 2.25008 5.872 2.25H4.5C3.90326 2.25 3.33097 2.48705 2.90901 2.90901C2.48705 3.33097 2.25 3.90326 2.25 4.5V6.75Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>                               
                                            <span>Contact Us...</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="mark-img">
                                    <img src="https://www.sumiramsairealtors.com/assets/images/mark/mark-contact4.png" alt="images">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

        <!-- Footer -->
        <footer id="footer" class="clearfix home">
                <div class="container">
                    <div class="row">
                        <!-- <div class="col-lg-6 col-md-12 col-12">
                            <div class="group-icon">
                                <div class="box-icons flex">
                                    <div class="images">
                                        <img src="assets/images/icon/footer-icons4.webp" alt="images">
                                    </div>
                                    <div class="content">
                                        <div class="title-icon fs-30 lh-45 fw-7 text-color-2">Buy Retail Shops</div>
                                        <p class="font-2 text-color-2">Tell us your needs, we will give you thousands of suggestions for the dream retail shops.</p>
                                    </div>
                                </div>
                                <div class="button-footer center">
                                    <a class="sc-button" href="contact-us">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2.25 6.75C2.25 15.034 8.966 21.75 17.25 21.75H19.5C20.0967 21.75 20.669 21.5129 21.091 21.091C21.5129 20.669 21.75 20.0967 21.75 19.5V18.128C21.75 17.612 21.399 17.162 20.898 17.037L16.475 15.931C16.035 15.821 15.573 15.986 15.302 16.348L14.332 17.641C14.05 18.017 13.563 18.183 13.122 18.021C11.4849 17.4191 9.99815 16.4686 8.76478 15.2352C7.53141 14.0018 6.58087 12.5151 5.979 10.878C5.817 10.437 5.983 9.95 6.359 9.668L7.652 8.698C8.015 8.427 8.179 7.964 8.069 7.525L6.963 3.102C6.90214 2.85869 6.76172 2.6427 6.56405 2.48834C6.36638 2.33397 6.1228 2.25008 5.872 2.25H4.5C3.90326 2.25 3.33097 2.48705 2.90901 2.90901C2.48705 3.33097 2.25 3.90326 2.25 4.5V6.75Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>                               
                                        <span>Contact Us...</span>
                                    </a>
                                </div>  
                            </div>
                        </div> -->
                        <!-- <div class="col-lg-6 col-md-12 col-12">
                            <div class="group-icon group-2">
                                <div class="box-icons flex">
                                    <div class="images">
                                        <img src="assets/images/icon/footer-icons3.webp" alt="images">
                                    </div>
                                    <div class="content">
                                        <div class="title-icon fs-30 lh-45 fw-7 text-color-2">Buy IT Offices</div>
                                        <p class="font-2 text-color-2">We will connect you to thousands of people who need to buy a commercial Spces.</p>
                                    </div>
                                </div>
                                <div class="button-footer center">
                                    <a class="sc-button" href="contact-us">
                                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M13.25 15.75V15H11.375C10.7547 15 10.25 14.4953 10.25 13.875V12.375C10.25 11.7547 10.7547 11.25 11.375 11.25H11.75V10.5H13.25V11.25H14C14.1989 11.25 14.3897 11.329 14.5303 11.4697C14.671 11.6103 14.75 11.8011 14.75 12C14.75 12.1989 14.671 12.3897 14.5303 12.5303C14.3897 12.671 14.1989 12.75 14 12.75H11.75V13.5H13.625C14.2453 13.5 14.75 14.0047 14.75 14.625V16.125C14.75 16.7453 14.2453 17.25 13.625 17.25H13.25V18H11.75V17.25H11C10.8011 17.25 10.6103 17.171 10.4697 17.0303C10.329 16.8897 10.25 16.6989 10.25 16.5C10.25 16.3011 10.329 16.1103 10.4697 15.9697C10.6103 15.829 10.8011 15.75 11 15.75H13.25Z" fill="white"/>
                                            <path d="M22.469 10.6447L14.315 2.96925C13.8234 2.50736 13.1742 2.25024 12.4996 2.25024C11.825 2.25024 11.1759 2.50736 10.6842 2.96925L8.74998 4.791V3C8.74998 2.80109 8.67096 2.61032 8.53031 2.46967C8.38966 2.32902 8.19889 2.25 7.99998 2.25H4.99998C4.80107 2.25 4.6103 2.32902 4.46965 2.46967C4.329 2.61032 4.24998 2.80109 4.24998 3V9.027L2.55273 10.6252C2.03748 11.0722 1.86348 11.784 2.10798 12.4387C2.34873 13.0837 2.93823 13.5 3.60948 13.5H4.24998V21C4.24998 21.1989 4.329 21.3897 4.46965 21.5303C4.6103 21.671 4.80107 21.75 4.99998 21.75H20C20.1989 21.75 20.3897 21.671 20.5303 21.5303C20.671 21.3897 20.75 21.1989 20.75 21V13.5H21.389C22.061 13.5 22.6512 13.083 22.892 12.438C23.1357 11.7832 22.961 11.0715 22.469 10.6447ZM5.74998 3.75H7.24998V6.2025L5.74998 7.61475V3.75ZM21.4865 11.9138C21.4542 12 21.4047 12 21.389 12H20C19.8011 12 19.6103 12.079 19.4697 12.2197C19.329 12.3603 19.25 12.5511 19.25 12.75V20.25H5.74998V12.75C5.74998 12.5511 5.67096 12.3603 5.53031 12.2197C5.38966 12.079 5.19889 12 4.99998 12H3.60948C3.59373 12 3.54498 12 3.51273 11.9138C3.50022 11.8834 3.49792 11.8498 3.50617 11.818C3.51442 11.7862 3.53278 11.7579 3.55848 11.7375L11.7125 4.062C11.9257 3.86178 12.2071 3.75032 12.4996 3.75032C12.7921 3.75032 13.0735 3.86178 13.2867 4.062L21.4625 11.7578C21.5187 11.8058 21.4977 11.883 21.4865 11.9138Z" fill="white"/>
                                        </svg>
                                        <span>Contact Us...</span>
                                    </a>
                                </div> 
                            </div>
                        </div> -->
                        <div class="col-lg-3 col-md-6 col-12">
                            <div class="widget widget-info">
                                <h3>Office Address</h3>
                                <p class="sub-title">Head office:</p>
                                <h5 class="text-color-1">G 192, G Block, Sector 63, Noida, Uttar Pradesh 201301</h5>
                                <p class="sub-title">Site:</p>
                                <p class="text-1 text-color-8">Plot No. C-3, Sector - 16B, Greater Noida West, (U.P) 201306</p>
                                <p class="text-2 text-color-8">Plot No-6, Knowledge Park-V, Greater Noida (West) 201306</p>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12">
                            <div class="widget widget-menu style-2">
                                <h3>Contact</h3>                       
                                <div class="box-icon flex align-center justify-space">
                                    <div class="img-group flex align-center">
                                        <div class="images flex-none">
                                            <img src="https://sumiramsairealtors.com/assets/images/author/avatar.webp" alt="sumiram sai realtors">
                                        </div>
                                        <div class="content">
                                            <p>HR Department:</p>
                                            <a href="tel:+91-9205190808"><h5>+91 9205190808</h5></a>
                                        </div>
                                    </div>
                                    <a href="#" class="button-author"><i class="far fa-chevron-right"></i></a>
                                </div>
                                <div class="box-icon flex align-center">
                                    <div class="icon flex-none">
                                        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g opacity="0.3">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M7.26135 17.3176L10.3744 14.2041C10.8085 13.7699 11.3522 13.5664 11.9646 13.6085C12.577 13.6507 13.0877 13.9271 13.4581 14.4166L18.0679 20.5097C18.6893 21.331 18.611 22.4676 17.8827 23.1959L15.7252 25.3537C19.0452 28.1764 21.8211 30.9536 24.6433 34.2735L26.8013 32.1152C27.5296 31.3868 28.666 31.3086 29.4872 31.9301L35.5794 36.5405C36.0689 36.9109 36.3452 37.4216 36.3874 38.0341C36.4296 38.6466 36.226 39.1904 35.7919 39.6245L32.6783 42.7385C25.5089 49.909 0.0917082 24.4882 7.26135 17.3176ZM33.8537 6C39.4572 6 43.9997 10.2467 43.9997 15.4854C43.9997 20.724 39.4572 24.9707 33.8537 24.9707C31.9295 24.9707 30.1305 24.4699 28.5975 23.6002C27.3492 24.1528 26.0098 24.3125 24.728 24.123C25.208 23.2144 25.5656 22.2462 25.7915 21.2437C24.4847 19.647 23.7077 17.6511 23.7077 15.4854C23.7077 10.2467 28.2502 6 33.8537 6Z" stroke="white" stroke-miterlimit="22.9256" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M33.8308 20.0552V14.4344H32.5506M32.4907 20.1123H35.171M33.8308 10.7305V10.7595" stroke="white" stroke-miterlimit="22.9256" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <p>Sales Department:</p>
                                        <a href="tel:+91-7293100100"><h5>+91 7293100100</h5></a>
                                    </div>
                                </div>
                                <div class="box-icon flex align-center">
                                    <div class="icon flex-none">
                                        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g opacity="0.3">
                                            <mask id="mask0_2290_9114" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="6" y="6" width="39" height="38">
                                            <path d="M43.5001 43.5V6.49987H6.5V43.5H43.5001Z" fill="white" stroke="white"/>
                                            </mask>
                                            <g mask="url(#mask0_2290_9114)">
                                            <path d="M27.1876 21.5002C27.1876 23.3585 26.0473 24.75 24.6819 24.75C23.3166 24.75 22.1093 23.3778 22.1093 21.5195C22.1093 19.6614 23.3837 18.4233 24.7491 18.4233C26.1143 18.4233 27.1876 19.6421 27.1876 21.5002Z" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M24.868 27.8945C22.1524 27.8194 19.6763 25.9815 18.9411 23.1859C18.0924 19.9591 19.9485 16.5889 23.1278 15.5769C26.4903 14.5065 30.0664 16.3982 31.0824 19.7644C31.4419 21.1114 31.2321 22.2832 30.7557 23.481C30.5668 23.956 29.9439 25.0679 28.5581 25.0679C27.8016 25.0679 27.1708 24.3429 27.175 23.5078L27.2024 17.9739" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M31.0829 19.7649C31.4424 21.1118 31.2326 22.2836 30.7562 23.4814" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M30.366 11.5664L24.9999 7.11327L19.6339 11.5664" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M12.3828 17.5839L7.11328 21.957V42.8867H42.8868V21.957L37.6173 17.5839" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M25 33.0898L37.6173 25.2368V11.5663H12.3828V25.2368L25 33.0898Z" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M42.8868 21.957L25.0001 33.0898L7.11328 21.957V42.8867H42.8868V21.957Z" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                            </g>
                                        </svg>                                     
                                    </div>
                                    <div class="content">
                                        <p>Email:</p>
                                        <a href="/cdn-cgi/l/email-protection#8be2e5ede4cbf8fee6e2f9eae6f8eae2f9eeeae7ffe4f9f8a5e8e4e6"><h5 class="fw-4 text-color-8"><span class="__cf_email__" data-cfemail="026b6c646d4271776f6b70636f71636b7067636e766d70712c616d6f">[email&#160;protected]</span></span></h5></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12">
                            <div class="widget widget-menu style-3 ">
                                <h3>Our Company</h3>   
                                <ul class="box-menu">
                                    <li><a href="home">Home</a></li>
                                    <li><a href="about">About Us</a></li>
                                    <li><a href="term-and-condition">Terms & Conditions</a></li>
                                    <li><a href="faq">FAQ</a></li>
                                    <li><a href="gallery">Gallery</a></li>  
                                    <li><a href="contact-us">Contact Us</a></li>               
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12">
                            <div class="widget widget-menu widget-form">
                                <h3>Newsletter</h3>  
                                <form method="post" class="comment-form form-submit" action="#" accept-charset="utf-8">
                                    <p class="font-2 text-color-8">Sign up to receive the latest articles</p>  
                                    <div class="text-wrap clearfix">
                                        <fieldset class="email-wrap style-text">
                                            <input type="email" class="tb-my-input" name="email" placeholder="Your email address" required="">
                                        </fieldset>                                 
                                    </div>
                                    <button name="submit" type="submit" class="button btn-submit-comment btn-1 btn-8">
                                        <span>Sign Up</span>
                                    </button>
                                    <label class="flex">
                                        <input type="checkbox">
                                        <span class="btn-checkbox flex-two"></span>
                                        <span class="fs-12 text-color-8 lh-18">I have read and agree to the terms & conditions</span>
                                    </label>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            

        <!-- /#footer -->
        <div class="widget-logo-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="wrap-logo flex align-center justify-space">
                                <div class="logo-footer style box-1" id="logo-footer">
                                    <a href="home">
                                    <img src="assets/images/logo/logo-footer@2x.webp" alt="img" width="197" height="48" alt="What is the galactic city project in Noida?">
                                    </a>
                                </div>
                                <div class="box-menu box-2">
                                    <ul class="menu-bottom flex align-center fs-16 fw-6">
                                        <li><a href="home">Home</a> </li>
                                        <!--<li><a href="project">project</a> </li>-->
                                        <li><a href="about">About</a> </li>
                                        <li><a href="faq">FAQ's</a> </li>
                                        <li><a href="contact-us">Contact</a> </li>
                                    </ul>
                                </div>
                                <div class="icon-social box-3 text-color-1">
                                    <a href="https://www.facebook.com/profile.php?id=61551759189538" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                    <a  href="https://twitter.com/sumiramsai" target="_blank"><i class="fab fa-twitter"></i></a>
                                    <a  href="https://www.linkedin.com/authwall?trk=bf&trkInfo=AQHvPZHSlwTpNwAAAYxnHLHY_4Ck5QYe5NmP0hBk75p-A4Gj05QzvS1Ge5YvTTcfOvDCRYH8gdsVxbxl0hmxN_Agy0pNZ3T5nfPh3O308-8oRZIlgmmpcYHiFpdZU49zqcsVNgE=&original_referer=&sessionRedirect=https%3A%2F%2Fwww.linkedin.com%2Fcompany%2Fsumiramsairealtor" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                    <a  href="https://www.instagram.com/sumiramsairealtor/" target="_blank"><i class="fab fa-instagram"></i></a>      
                                    <!--<a href="https://www.linkedin.com/company/sumiram-sai-realtors-official/" target="_blank"><i class="fab fa-google-plus-g"></i></a>                      -->
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 
            <div class="widget-bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="title-bottom center"> Copyright © 2023. Designed & Developed by <a href="terms-and-conditions" class="text-color-1">Sumiram Sai Realtors</a> </div>
                        </div>
                    </div>
                </div>
            </div>
           
        <!-- Bottom -->
        </div>
        <!-- /#page -->

    </div>
    <div class="modal fade popup" id="popup_bid" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body space-y-20 pd-40">
                    <div class="wrap-modal flex">
                        <div class="images flex-none">
                            <img src="https://www.sumiramsairealtors.com/assets/images/section/bg-login.webp" alt="what is the commercial property ">
                            <div class="mark-logo">
                                <img src="https://www.sumiramsairealtors.com/assets/images/logo/logo@2x.webp" alt="logo ">
                            </div>
                        </div>
                        <div class="content">
                            <div class="title-login fs-30 fw-7 lh-45">Login</div>
                            <div class="comments">
                                <div class="respond-comment">
                                    <form method="post" class="comment-form form-submit" action="#" accept-charset="utf-8">
                                        <fieldset class="">
                                            <label class="fw-6">Account</label>
                                            <input type="email" id="email" class="tb-my-input" name="email" placeholder="Email or user name" >
                                            <img class="img-icon img-email" src="https://www.sumiramsairealtors.com/assets/images/icon/icon-gmail.svg" alt="images">
                                        </fieldset>   
                                        <fieldset class="style-wrap">
                                            <label class="fw-6">Password</label>
                                            <input type="password" class="input-form password-input" placeholder="Your password" >
                                            <img class="img-icon" src="https://www.sumiramsairealtors.com/assets/images/icon/icon-password.svg" alt="images">
                                        </fieldset> 
                                        <div class="title-forgot"><a href="#" class="fs-13" >Forgot password</a> </div>                                    
                                        <button class="sc-button"  name="submit" type="submit">
                                            <span>Login</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="text-box text-center fs-13">Don’t you have an account?  <a href="#" class="font-2 fw-7 fs-13 color-popup text-color-3" data-toggle="modal" data-target="#popup_bid2" data-dismiss="modal" aria-label="Close">Register</a></div>
                            <p class="texts fs-13 text-center">or login with</p>
                            <div class="button-box flex">
                                <a href="#" class="flex align-center">
                                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4.43242 12.5863L3.73625 15.1852L1.19176 15.239C0.431328 13.8286 0 12.2149 0 10.5C0 8.84179 0.403281 7.27804 1.11812 5.90112H1.11867L3.38398 6.31644L4.37633 8.56815C4.16863 9.17366 4.05543 9.82366 4.05543 10.5C4.05551 11.2341 4.18848 11.9374 4.43242 12.5863Z" fill="#FBBB00"/>
                                        <path d="M19.8242 8.6319C19.939 9.23682 19.9989 9.86155 19.9989 10.5C19.9989 11.216 19.9236 11.9143 19.7802 12.588C19.2934 14.8803 18.0214 16.8819 16.2594 18.2984L16.2588 18.2978L13.4055 18.1522L13.0017 15.6314C14.1709 14.9456 15.0847 13.8726 15.566 12.588H10.2188V8.6319H19.8242Z" fill="#518EF8"/>
                                        <path d="M16.2595 18.2978L16.2601 18.2984C14.5464 19.6758 12.3694 20.5 9.99965 20.5C6.19141 20.5 2.88043 18.3715 1.19141 15.239L4.43207 12.5863C5.27656 14.8401 7.45074 16.4445 9.99965 16.4445C11.0952 16.4445 12.1216 16.1484 13.0024 15.6313L16.2595 18.2978Z" fill="#28B446"/>
                                        <path d="M16.382 2.80219L13.1425 5.45437C12.2309 4.88461 11.1534 4.55547 9.99906 4.55547C7.39246 4.55547 5.17762 6.23348 4.37543 8.56812L1.11773 5.90109H1.11719C2.78148 2.6923 6.13422 0.5 9.99906 0.5C12.4254 0.5 14.6502 1.3643 16.382 2.80219Z" fill="#F14336"/>
                                    </svg>
                                    <span class="fw-6">Google</span> 
                                </a>
                                <a href="#" class="flex align-center">
                                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20.5 10.5C20.5 15.4914 16.843 19.6285 12.0625 20.3785V13.3906H14.3926L14.8359 10.5H12.0625V8.62422C12.0625 7.8332 12.45 7.0625 13.6922 7.0625H14.9531V4.60156C14.9531 4.60156 13.8086 4.40625 12.7145 4.40625C10.4305 4.40625 8.9375 5.79063 8.9375 8.29688V10.5H6.39844V13.3906H8.9375V20.3785C4.15703 19.6285 0.5 15.4914 0.5 10.5C0.5 4.97734 4.97734 0.5 10.5 0.5C16.0227 0.5 20.5 4.97734 20.5 10.5Z" fill="#1877F2"/>
                                        <path d="M14.3926 13.3906L14.8359 10.5H12.0625V8.62418C12.0625 7.83336 12.4499 7.0625 13.6921 7.0625H14.9531V4.60156C14.9531 4.60156 13.8088 4.40625 12.7146 4.40625C10.4304 4.40625 8.9375 5.79063 8.9375 8.29688V10.5H6.39844V13.3906H8.9375V20.3785C9.44664 20.4584 9.96844 20.5 10.5 20.5C11.0316 20.5 11.5534 20.4584 12.0625 20.3785V13.3906H14.3926Z" fill="white"/>
                                    </svg>
                                    <span class="fw-6">Facebook</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>     
            </div>
        </div>
    </div>

    <div class="modal fade popup " id="popup_bid2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content ">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body space-y-20 pd-40 style2">
                    <div class="wrap-modal flex">
                        <div class="images flex-none relative">
                            <img src="https://sumiramsairealtors.com/assets/images/section/bg-register.webp" alt="images">
                            <!--<div class="mark-logo">-->
                            <!--    <img src="assets/images/logo/logo2.png" alt="images">-->
                            <!--</div>-->
                        </div>
                        <div class="content">
                            <div class="title-login fs-30 fw-7 lh-45">Get in touch with Us!</div>
                            <div class="comments">
                                <div class="respond-comment">
                                    <form method="post" class="comment-form form-submit" action="query.php" accept-charset="utf-8"  novalidate="novalidate" >
                                           <input type="hidden" class="tb-my-input" name="recipients" placeholder="Name" value="info@sumiramsairealtors.com,media@sumiramsairealtors.com,sumiramsairealtors2@gmail.com" >
                                        <fieldset class="">
                                            <label class="fw-6">Name</label>
                                            <input type="text" class="tb-my-input" name="name" placeholder="Name" >
                                            <img class="img-icon img-name" src="https://sumiramsairealtors.com/assets/images/icon/login-user.svg" alt="images">
                                        </fieldset>   
                                        <fieldset class="t">
                                            <label class="fw-6">Email</label>
                                            <input type="email"  class="tb-my-input" name="email" placeholder="Email" >
                                            <img class="img-icon" src="https://sumiramsairealtors.com/assets/images/icon/icon-gmail.svg" alt="images">
                                        </fieldset> 
                                        <fieldset class="">
                                            <label class="fw-6">Mobile</label>
                                            <input type="text" class="input-form password-input" name="mobile" placeholder="Mobile" >
                                            <img class="img-icon" src="https://sumiramsairealtors.com/assets/images/icon/icon-password.svg" alt="images">
                                        </fieldset> 
                                        <fieldset class="">
                                            <label class="fw-6">Query</label>
                                            <input type="text" class="input-form password-input" placeholder="Enter your query here..." name="special_note">
                                            <img class="img-icon" src="https://sumiramsairealtors.com/assets/images/icon/icon-password.svg" alt="images">
                                        </fieldset>                                   
                                        <button class="sc-button"  name="submit" type="submit">
                                            <span>Submit</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>     
            </div>
        </div>
    </div>
    <!-- Modal Popup Bid -->

    <a id="scroll-top" class="button-go"></a>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
        // Example: Lazy load images
        document.addEventListener('DOMContentLoaded', function () {
            var lazyImages = document.querySelectorAll('img.lazy');
            lazyImages.forEach(function (img) {
                img.src = img.dataset.src;
            });
        });
                        $(document).ready(function(){
  $('.toggle').click(function(){
    $('.sidebar-contact').toggleClass('active')
    $('.toggle').toggleClass('active')
  })
})
    </script>
    <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="app/js/jquery.min.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/jquery.easing.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/jquery.nice-select.min.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/bootstrap.min.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/owl.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/swiper-bundle.min.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/swiper.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/jquery-validate.js"></script>
    
    <script src="https://sumiramsairealtors.com/app/js/plugin.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/shortcodes.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/main.js"></script>
    <script src="https://sumiramsairealtors.com/app/js/price-ranger.js"></script>
</body>
